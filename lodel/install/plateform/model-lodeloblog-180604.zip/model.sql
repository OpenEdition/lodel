# <model>
# <lodelversion>0.7</lodelversion>
# <date>2004-06-06</date>
# <description>
# Version 1.0 de lodeloblog.
# Lodeloblog est un mod�le �ditorial simple pour cr�er un site de type journal ou carnet de bord (blog ou weblog).
# Il permet de cr�er des billets pr�sent�s dans l'ordre chronologique sur la page principale, et de g�rer un annuaire de liens affich� sur toutes les pages sous la forme d'une "blogroll". On peut y ajouter des documents de pr�sentation, tels que le profil ou le CV de l'auteur.
# L'acc�s aux billets se fait par les archives mensuelles, les cat�gories th�matiques et les index.
# </description>
# <author>
# Manue et Got
# </author>
# </model>
#  
#------------

DELETE FROM __LODELTP__champs;
DELETE FROM __LODELTP__groupesdechamps;
DELETE FROM __LODELTP__types;
DELETE FROM __LODELTP__typepersonnes;
DELETE FROM __LODELTP__typeentrees;
DELETE FROM __LODELTP__typeentites_typeentites;
DELETE FROM __LODELTP__typeentites_typeentrees;
DELETE FROM __LODELTP__typeentites_typepersonnes;
# # Database: 'lodel'# 
#
# Dumping data for table 'lodel_champs'
#

INSERT INTO __LODELTP__champs (id, nom, idgroupe, titre, style, type, condition, defaut, traitement, balises, filtrage, edition, commentaire, statut, ordre, maj) VALUES ('1', 'titre', '14', 'Titre du document', 'title', 'text', '+', 'Document sans titre', '', 'xhtml:fontstyle;xhtml:phrase;Lien', '', 'text', 'Titre du document.', '32', '1', '20040314155519');
INSERT INTO __LODELTP__champs (id, nom, idgroupe, titre, style, type, condition, defaut, traitement, balises, filtrage, edition, commentaire, statut, ordre, maj) VALUES ('7', 'texte', '2', 'Texte du document', 'texte', 'longtext', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note;texte Lodel;Sections', '', 'textarea30', 'Texte du document', '32', '2', '20040606165950');
INSERT INTO __LODELTP__champs (id, nom, idgroupe, titre, style, type, condition, defaut, traitement, balises, filtrage, edition, commentaire, statut, ordre, maj) VALUES ('14', 'erratum', '16', 'Erratum', '', 'text', '*', '', '', 'xhtml:phrase;xhtml:special;xhtml:block;Lien', '', 'textarea10', 'Erratum ou update', '32', '9', '20040606170005');
INSERT INTO __LODELTP__champs (id, nom, idgroupe, titre, style, type, condition, defaut, traitement, balises, filtrage, edition, commentaire, statut, ordre, maj) VALUES ('31', 'fichiersassocies', '3', 'Fichiers associés au document', '', 'fichier', '*', '', '', '', '', '', 'Ce champ est un champ utilisé en interne par Lodel. Ne pas le modifier.', '32', '1', '20040305160048');
INSERT INTO __LODELTP__champs (id, nom, idgroupe, titre, style, type, condition, defaut, traitement, balises, filtrage, edition, commentaire, statut, ordre, maj) VALUES ('32', 'datepubli', '1', 'Date de la publication électronique', 'datepubli', 'datetime', '*', 'today', '', '0', '', 'editable', 'Date de publication du texte intégral en ligne', '32', '2', '20040606170000');
INSERT INTO __LODELTP__champs (id, nom, idgroupe, titre, style, type, condition, defaut, traitement, balises, filtrage, edition, commentaire, statut, ordre, maj) VALUES ('51', 'titre', '10', 'Titre de la publication', 'title', 'text', '+', 'Publication sans titre', '', 'xhtml:fontstyle;xhtml:phrase;Lien', '', 'text', '', '32', '1', '20040305103053');
INSERT INTO __LODELTP__champs (id, nom, idgroupe, titre, style, type, condition, defaut, traitement, balises, filtrage, edition, commentaire, statut, ordre, maj) VALUES ('89', 'icone', '17', 'Icône de la publication', '', 'image', '*', '', '', '', '', '', '', '32', '1', '20040305100306');
INSERT INTO __LODELTP__champs (id, nom, idgroupe, titre, style, type, condition, defaut, traitement, balises, filtrage, edition, commentaire, statut, ordre, maj) VALUES ('66', 'fichiersource', '3', 'Fichier source', '', 'fichier', '*', '', '', '', '', '', '', '32', '5', '20040223174419');
INSERT INTO __LODELTP__champs (id, nom, idgroupe, titre, style, type, condition, defaut, traitement, balises, filtrage, edition, commentaire, statut, ordre, maj) VALUES ('67', 'introduction', '18', 'Introduction de la publication', '', 'text', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note;texte Lodel;Sections', '', '', '', '32', '1', '20040305100234');
INSERT INTO __LODELTP__champs (id, nom, idgroupe, titre, style, type, condition, defaut, traitement, balises, filtrage, edition, commentaire, statut, ordre, maj) VALUES ('74', 'importversion', '3', 'Version de l\'importation', '', 'tinytext', '*', '', '', '', '', '', '', '32', '6', '20040223174408');
INSERT INTO __LODELTP__champs (id, nom, idgroupe, titre, style, type, condition, defaut, traitement, balises, filtrage, edition, commentaire, statut, ordre, maj) VALUES ('83', 'langue', '1', 'Langue du document', 'langue', 'lang', '*', 'fr', '', '', '', 'editable', 'fr : français\ren : anglais\rit : italien\rru : russe\res : espagnol\rde : allemand', '32', '8', '20040305155702');
INSERT INTO __LODELTP__champs (id, nom, idgroupe, titre, style, type, condition, defaut, traitement, balises, filtrage, edition, commentaire, statut, ordre, maj) VALUES ('88', 'icone', '1', 'Icône du document', '', 'image', '*', '', '', '0', '', '', '', '32', '10', '20040416232524');
INSERT INTO __LODELTP__champs (id, nom, idgroupe, titre, style, type, condition, defaut, traitement, balises, filtrage, edition, commentaire, statut, ordre, maj) VALUES ('99', 'url', '2', 'url', '', 'url', '*', '', '', '0', '', 'editable', '', '32', '3', '20040606165954');
INSERT INTO __LODELTP__champs (id, nom, idgroupe, titre, style, type, condition, defaut, traitement, balises, filtrage, edition, commentaire, statut, ordre, maj) VALUES ('102', 'soutitre', '14', 'Sous-titre du document', 'subtitle', 'text', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;Lien;Appel de Note', '', 'text', '', '32', '2', '20040409104626');

#
# Dumping data for table 'lodel_groupesdechamps'
#

INSERT INTO __LODELTP__groupesdechamps (id, nom, classe, titre, commentaire, statut, ordre, maj) VALUES ('1', 'grmeta', 'documents', 'Groupe métadonnées', '', '32', '4', '20040303175835');
INSERT INTO __LODELTP__groupesdechamps (id, nom, classe, titre, commentaire, statut, ordre, maj) VALUES ('2', 'grtexte', 'documents', 'Groupe du texte', '', '32', '2', '20040606165945');
INSERT INTO __LODELTP__groupesdechamps (id, nom, classe, titre, commentaire, statut, ordre, maj) VALUES ('3', 'grgestion', 'documents', 'Groupe gestion des documents', '', '32', '6', '20040303170953');
INSERT INTO __LODELTP__groupesdechamps (id, nom, classe, titre, commentaire, statut, ordre, maj) VALUES ('10', 'grtitre', 'publications', 'Groupe titre', '', '32', '1', '20040305053528');
INSERT INTO __LODELTP__groupesdechamps (id, nom, classe, titre, commentaire, statut, ordre, maj) VALUES ('14', 'grtitre', 'documents', 'Groupe du titre', '', '1', '1', '20040223173058');
INSERT INTO __LODELTP__groupesdechamps (id, nom, classe, titre, commentaire, statut, ordre, maj) VALUES ('16', 'graddenda', 'documents', 'Groupe addenda', 'Ensemble de remarques additionnelles', '32', '5', '20040303175057');
INSERT INTO __LODELTP__groupesdechamps (id, nom, classe, titre, commentaire, statut, ordre, maj) VALUES ('17', 'grmetadonnees', 'publications', 'Groupe des métadonnées', '', '32', '3', '20040304133434');
INSERT INTO __LODELTP__groupesdechamps (id, nom, classe, titre, commentaire, statut, ordre, maj) VALUES ('18', 'graddenda', 'publications', 'Groupe addenda', '', '32', '4', '20040304135521');

#
# Dumping data for table 'lodel_types'
#

INSERT INTO __LODELTP__types (id, type, titre, classe, tpl, tplcreation, tpledition, import, ordre, statut, maj) VALUES ('1', 'categorie', 'Catégorie', 'publications', 'categorie', 'creation-serie', 'edition-hierarchique', '0', '1', '32', '20040606165933');
INSERT INTO __LODELTP__types (id, type, titre, classe, tpl, tplcreation, tpledition, import, ordre, statut, maj) VALUES ('10', 'lien', 'Lien', 'documents', 'lien', 'document', '', '0', '7', '32', '20040317005215');
INSERT INTO __LODELTP__types (id, type, titre, classe, tpl, tplcreation, tpledition, import, ordre, statut, maj) VALUES ('2', 'regroupement', 'Regroupement', 'publications', '', 'creation-regroupement', '', '0', '3', '32', '20040606165926');
INSERT INTO __LODELTP__types (id, type, titre, classe, tpl, tplcreation, tpledition, import, ordre, statut, maj) VALUES ('3', 'presentation', 'Présentation', 'documents', 'presentation', 'document', '', '1', '6', '32', '20040317005215');
INSERT INTO __LODELTP__types (id, type, titre, classe, tpl, tplcreation, tpledition, import, ordre, statut, maj) VALUES ('9', 'annuaire', 'Annuaire de liens', 'publications', 'annuaire', 'creation-rubrique', 'edition-rubrique', '0', '2', '32', '20040606165930');
INSERT INTO __LODELTP__types (id, type, titre, classe, tpl, tplcreation, tpledition, import, ordre, statut, maj) VALUES ('4', 'documentannexe-lienfichier', 'Vers un fichier', 'documents', '', 'documentannexe-lienfichier', '', '0', '8', '32', '20040317005215');
INSERT INTO __LODELTP__types (id, type, titre, classe, tpl, tplcreation, tpledition, import, ordre, statut, maj) VALUES ('5', 'documentannexe-liendocument', 'Vers un document interne au site', 'documents', '', 'documentannexe-liendocument', '', '0', '10', '32', '20040317005215');
INSERT INTO __LODELTP__types (id, type, titre, classe, tpl, tplcreation, tpledition, import, ordre, statut, maj) VALUES ('6', 'documentannexe-lienpublication', 'Vers une publication interne au site', 'documents', '', 'documentannexe-lienpublication', '', '0', '11', '32', '20040317005215');
INSERT INTO __LODELTP__types (id, type, titre, classe, tpl, tplcreation, tpledition, import, ordre, statut, maj) VALUES ('7', 'documentannexe-lienexterne', 'Vers un site externe', 'documents', '', 'documentannexe-lienexterne', '', '0', '9', '32', '20040317005215');
INSERT INTO __LODELTP__types (id, type, titre, classe, tpl, tplcreation, tpledition, import, ordre, statut, maj) VALUES ('8', 'billet', 'Billet', 'documents', 'billet', 'document', '', '0', '5', '32', '20040317005215');
INSERT INTO __LODELTP__types (id, type, titre, classe, tpl, tplcreation, tpledition, import, ordre, statut, maj) VALUES ('95', 'Commentaire', 'commentaire', 'documents', '', 'commentaire', '', '0', '12', '1', '20040331000536');

#
# Dumping data for table 'lodel_typepersonnes'
#

INSERT INTO __LODELTP__typepersonnes (id, type, titre, style, titredescription, styledescription, tpl, tplindex, ordre, statut, maj) VALUES ('11', 'auteur', 'Auteur', 'auteur', 'description de l\'auteur', 'descriptionauteur', 'auteur', 'auteurs', '1', '32', '20040317005215');

#
# Dumping data for table 'lodel_typeentrees'
#

INSERT INTO __LODELTP__typeentrees (id, type, titre, style, tpl, tplindex, ordre, statut, lineaire, nvimportable, utiliseabrev, tri, maj) VALUES ('12', 'motcle', 'Index par mots clés', '', 'mot', 'mots', '1', '32', '1', '1', '0', 'nom', '20040317005215');
INSERT INTO __LODELTP__typeentrees (id, type, titre, style, tpl, tplindex, ordre, statut, lineaire, nvimportable, utiliseabrev, tri, maj) VALUES ('13', 'mois', 'Mois', '', 'mois', 'moiss', '2', '32', '1', '1', '0', 'ordre', '20040606165839');

#
# Dumping data for table 'lodel_typeentites_typeentites'
#

INSERT INTO __LODELTP__typeentites_typeentites (idtypeentite, idtypeentite2, condition) VALUES ('9', '0', '*');
INSERT INTO __LODELTP__typeentites_typeentites (idtypeentite, idtypeentite2, condition) VALUES ('10', '2', '*');
INSERT INTO __LODELTP__typeentites_typeentites (idtypeentite, idtypeentite2, condition) VALUES ('10', '9', '*');
INSERT INTO __LODELTP__typeentites_typeentites (idtypeentite, idtypeentite2, condition) VALUES ('1', '0', '*');
INSERT INTO __LODELTP__typeentites_typeentites (idtypeentite, idtypeentite2, condition) VALUES ('10', '1', '*');
INSERT INTO __LODELTP__typeentites_typeentites (idtypeentite, idtypeentite2, condition) VALUES ('3', '0', '*');
INSERT INTO __LODELTP__typeentites_typeentites (idtypeentite, idtypeentite2, condition) VALUES ('3', '2', '*');
INSERT INTO __LODELTP__typeentites_typeentites (idtypeentite, idtypeentite2, condition) VALUES ('2', '1', '*');
INSERT INTO __LODELTP__typeentites_typeentites (idtypeentite, idtypeentite2, condition) VALUES ('2', '9', '*');
INSERT INTO __LODELTP__typeentites_typeentites (idtypeentite, idtypeentite2, condition) VALUES ('2', '0', '*');
INSERT INTO __LODELTP__typeentites_typeentites (idtypeentite, idtypeentite2, condition) VALUES ('10', '0', '*');
INSERT INTO __LODELTP__typeentites_typeentites (idtypeentite, idtypeentite2, condition) VALUES ('8', '1', '*');
INSERT INTO __LODELTP__typeentites_typeentites (idtypeentite, idtypeentite2, condition) VALUES ('8', '0', '*');
INSERT INTO __LODELTP__typeentites_typeentites (idtypeentite, idtypeentite2, condition) VALUES ('95', '8', '*');

#
# Dumping data for table 'lodel_typeentites_typeentrees'
#

INSERT INTO __LODELTP__typeentites_typeentrees (idtypeentite, idtypeentree, condition) VALUES ('3', '12', '*');
INSERT INTO __LODELTP__typeentites_typeentrees (idtypeentite, idtypeentree, condition) VALUES ('10', '12', '*');
INSERT INTO __LODELTP__typeentites_typeentrees (idtypeentite, idtypeentree, condition) VALUES ('8', '12', '*');
INSERT INTO __LODELTP__typeentites_typeentrees (idtypeentite, idtypeentree, condition) VALUES ('8', '13', '*');

#
# Dumping data for table 'lodel_typeentites_typepersonnes'
#

INSERT INTO __LODELTP__typeentites_typepersonnes (idtypeentite, idtypepersonne, condition) VALUES ('1', '11', '*');
INSERT INTO __LODELTP__typeentites_typepersonnes (idtypeentite, idtypepersonne, condition) VALUES ('10', '11', '*');
INSERT INTO __LODELTP__typeentites_typepersonnes (idtypeentite, idtypepersonne, condition) VALUES ('3', '11', '*');
INSERT INTO __LODELTP__typeentites_typepersonnes (idtypeentite, idtypepersonne, condition) VALUES ('9', '11', '*');
INSERT INTO __LODELTP__typeentites_typepersonnes (idtypeentite, idtypepersonne, condition) VALUES ('8', '11', '*');
# # Database: 'lodel'# 
# --------------------------------------------------------

#
# Table structure for table 'lodel_documents'
#

DROP TABLE IF EXISTS __LODELTP__documents;
CREATE TABLE __LODELTP__documents (
  identite int(10) unsigned NOT NULL default '0',
  titre text,
  intro text NOT NULL,
  langresume varchar(64) NOT NULL default '',
  lang varchar(64) NOT NULL default '',
  meta text,
  datepubli datetime default NULL,
  texte longtext,
  erratum text,
  fichiersassocies tinytext,
  fichiersource tinytext,
  importversion tinytext,
  langue char(2) default NULL,
  icone tinytext,
  url tinytext,
  soutitre text,
  PRIMARY KEY  (identite),
  UNIQUE KEY identite (identite)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table 'lodel_publications'
#

DROP TABLE IF EXISTS __LODELTP__publications;
CREATE TABLE __LODELTP__publications (
  identite int(10) unsigned NOT NULL default '0',
  titre text,
  introduction text,
  meta text,
  date date default NULL,
  image tinytext,
  introdution text,
  icone tinytext,
  PRIMARY KEY  (identite),
  UNIQUE KEY identite (identite)
) TYPE=MyISAM;
