# <model>
# <lodelversion>0.8</lodelversion>
# <date>2005-05-12</date>
# <title>
# ME blog
# </title>
# <description>
# Ce modèle éditorial permet de construire un blog avec lodel. Ce modèle est compatible avec la version 0.8 de lodel.
# </description>
# <author>
# Got, Manue et Jérôme Vogel
# </author>
# <modelversion>
# 1.2
# </modelversion>
# </model>
#  
#------------

DELETE FROM #_TP_classes;
DELETE FROM #_TP_tablefields;
DELETE FROM #_TP_tablefieldgroups;
DELETE FROM #_TP_types;
DELETE FROM #_TP_persontypes;
DELETE FROM #_TP_entrytypes;
DELETE FROM #_TP_entitytypes_entitytypes;
DELETE FROM #_TP_characterstyles;
DELETE FROM #_TP_internalstyles;
# # Database: 'lodeldevel_blog'# 
#
# Dumping data for table 'lodel_classes'
#

INSERT INTO #_TP_classes (id, class, title, classtype, comment, rank, status, upd) VALUES ('8', 'documents', 'Documents', 'entities', '', '1', '1', '20050512180157');
INSERT INTO #_TP_classes (id, class, title, classtype, comment, rank, status, upd) VALUES ('9', 'publications', 'Publications', 'entities', '', '2', '1', '20050512180157');
INSERT INTO #_TP_classes (id, class, title, classtype, comment, rank, status, upd) VALUES ('10', 'liens', 'Liens', 'entities', '', '3', '1', '20050512180157');
INSERT INTO #_TP_classes (id, class, title, classtype, comment, rank, status, upd) VALUES ('11', 'motscles', 'Index de mots-clés', 'entries', '', '4', '1', '20050512180157');
INSERT INTO #_TP_classes (id, class, title, classtype, comment, rank, status, upd) VALUES ('12', 'personnes', 'Personnes', 'persons', '', '5', '1', '20050512180157');
INSERT INTO #_TP_classes (id, class, title, classtype, comment, rank, status, upd) VALUES ('13', 'commentaires', 'Commentaires en ligne', 'entities', '', '6', '1', '20050512181010');

#
# Dumping data for table 'lodel_tablefields'
#

INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('1', 'prenom', '0', 'personnes', 'Prénom', '', 'text', 'firstname', '*', '', '', '', '', 'textarea', '', '0', '', '1', '1', '20050507001501');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('2', 'nom', '0', 'personnes', 'Nom de famille', '', 'text', 'familyname', '*', '', '', '', '', 'textarea', '', '0', '', '1', '2', '20050507001527');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('3', 'description', '0', 'entities_personnes', 'Description de l\'auteur', '', 'text', '', '*', '', '', '', '', 'textarea', '5', '0', '', '1', '3', '20050507001555');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('4', 'titre', '1', 'liens', 'Titre du site', '', 'text', 'dc.title', '*', '', '', 'xhtml:phrase;xhtml:special', '', 'textarea', '', '8', '', '1', '4', '20050507002426');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('5', 'lien', '1', 'liens', 'Lien', '', 'url', '', '*', '', '', '', '', 'textarea', '', '0', '', '1', '5', '20050507002327');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('6', 'rss', '1', 'liens', 'Lien vers le fil RSS du site', '', 'url', '', '*', '', '', '', '', 'editable', '', '0', '', '1', '6', '20050507002356');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('7', 'texte', '1', 'liens', 'Description du site', '', 'text', 'dc.description', '*', '', '', 'xhtml:phrase;xhtml:special;xhtml:block;Lien', '', 'textarea', '5', '4', '', '1', '7', '20050507002515');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('8', 'langue', '1', 'liens', 'Langue principale du site', '', 'lang', 'dc.language', '*', '', '', '', '', 'editable', '', '0', '', '1', '8', '20050507002603');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('9', 'titre', '2', 'publications', 'Titre de la publication', '', 'text', 'dc.title', '*', '', '', 'xhtml:phrase;xhtml:special', '', 'textarea', '1', '8', '', '1', '9', '20050507002714');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('10', 'icone', '2', 'publications', 'Icône de la publication', '', 'image', '', '*', '', '', '', '', 'editable', '', '0', '', '1', '10', '20050507002818');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('11', 'introduction', '2', 'publications', 'Introduction de la publication', '', 'text', '', '*', '', '', 'xhtml:phrase;xhtml:special;xhtml:block;Lien', '', 'textarea', '10', '2', '', '1', '11', '20050507011942');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('12', 'titre', '3', 'documents', 'Titre du document', 'title, titre, titleuser, heading', 'text', 'dc.title', '*', '', '', 'xhtml:phrase;xhtml:special;xhtml:block;Appel de Note', '', 'textarea', '1', '8', '', '1', '12', '20050507010930');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('13', 'soustitre', '3', 'documents', 'Sous-titre du document', 'soustitre, subtitle', 'text', '', '*', '', '', 'xhtml:phrase;xhtml:special;Appel de Note', '', 'textarea', '1', '8', '', '1', '13', '20050507010919');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('14', 'datepubli', '3', 'documents', 'Date de la publication électronique', 'datepubli', 'datetime', 'dc.date', '*', 'today', '', '', '', 'editable', '', '0', '', '1', '14', '20050507103804');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('15', 'langue', '3', 'documents', 'Langue du document', 'langue', 'lang', 'dc.language', '*', '', '', '', '', 'editable', '', '0', '', '1', '15', '20050507003532');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('16', 'icone', '3', 'documents', 'Icône du document', '', 'image', '', '*', '', '', '', '', 'editable', '', '0', '', '1', '16', '20050507003607');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('17', 'motcle', '3', 'documents', 'Index de mots-clés', '', 'entries', '', '', '', '', '', '', 'editable', '', '0', '', '1', '17', '20050507003622');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('18', 'auteur', '3', 'documents', 'Auteur du billet', '', 'persons', '', '', '', '', '', '', 'editable', '', '0', '', '1', '18', '20050507003633');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('19', 'nom', '0', 'motscles', 'Nom', '', 'text', 'index key', '*', '', '', '', '', 'editable', '', '8', '', '1', '19', '20050507014452');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('20', 'texte', '4', 'documents', 'Texte du document', 'texte, standard, normal', 'longtext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'textarea', '15 50', '4', '', '1', '20', '20050507012611');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('21', 'notebaspage', '4', 'documents', 'Note de bas de page', 'notebaspage, footnote, footnotetext', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', '', 'importable', '', '2', '', '1', '21', '20050507010402');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('22', 'erratum', '4', 'documents', 'Erratum', '', 'text', '', '*', '', '', 'xhtml:phrase;xhtml:special;xhtml:block;Lien', '', 'textarea', '10', '4', '', '1', '22', '20050507010526');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('23', 'resume', '3', 'documents', 'Résumé du document', 'resume:fr, abstract:en, riassunto:it, extracto:es, zusammenfassung:de', 'mltext', 'dc.description', '*', '', '', 'xhtml:phrase;xhtml:special;xhtml:block', '', 'editable', '', '8', '', '1', '23', '20050507011021');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('24', 'titre', '5', 'commentaires', 'titre', '', 'tinytext', 'dc.title', '*', '', '', '', '', 'textarea', '1', '0', '', '1', '24', '20050512181309');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('25', 'texte', '6', 'commentaires', 'Texte du commentaire', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', '', 'editable', '', '1', '', '1', '25', '20050512181448');

#
# Dumping data for table 'lodel_tablefieldgroups'
#

INSERT INTO #_TP_tablefieldgroups (id, name, class, title, comment, status, rank, upd) VALUES ('1', 'grliens', 'liens', 'Groupe de champs pour les liens', '', '1', '1', '20050507002223');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, comment, status, rank, upd) VALUES ('2', 'grpubli', 'publications', 'Groupe de champs pour les publications', '', '1', '2', '20050507002626');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, comment, status, rank, upd) VALUES ('3', 'grmeta', 'documents', 'Groupe de métadonnées', '', '1', '3', '20050507002950');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, comment, status, rank, upd) VALUES ('4', 'grtexte', 'documents', 'Groupe du texte', '', '1', '4', '20050507003708');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, comment, status, rank, upd) VALUES ('5', 'grMetadata', 'commentaires', 'Groupe des métadonnées', '', '1', '5', '20050512181224');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, comment, status, rank, upd) VALUES ('6', 'grTexte', 'commentaires', 'Groupe du texte', '', '1', '6', '20050512181358');

#
# Dumping data for table 'lodel_types'
#

INSERT INTO #_TP_types (id, type, title, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, rank, status, upd, public) VALUES ('1', 'billet', 'Billet', 'documents', 'billet', 'entities', 'edition', '0', '', '-1', '1', '1', '1', '20050512180156', '0');
INSERT INTO #_TP_types (id, type, title, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, rank, status, upd, public) VALUES ('2', 'categorie', 'Categorie', 'publications', 'categorie', 'entities', 'edition', '0', '', '-1', '1', '2', '1', '20050512180156', '0');
INSERT INTO #_TP_types (id, type, title, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, rank, status, upd, public) VALUES ('3', 'annuaire', 'Annuaire de liens', 'publications', 'annuaire', 'entities', 'edition', '0', '', '-1', '1', '3', '1', '20050512180156', '0');
INSERT INTO #_TP_types (id, type, title, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, rank, status, upd, public) VALUES ('4', 'lien', 'Lien', 'liens', 'lien', 'entities', 'edition', '0', '', '-1', '1', '4', '1', '20050512180156', '0');
INSERT INTO #_TP_types (id, type, title, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, rank, status, upd, public) VALUES ('5', 'rubriqueliens', 'Rubrique pour les liens', 'publications', 'rubrique', 'entities', 'edition', '0', 'unfolded', '-1', '1', '5', '1', '20050512180156', '0');
INSERT INTO #_TP_types (id, type, title, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, rank, status, upd, public) VALUES ('14', 'commentaire', 'Commentaire', 'commentaires', 'commentaire', 'entities', 'edition', '0', '', '1', '1', '6', '1', '20050512181115', '1');

#
# Dumping data for table 'lodel_persontypes'
#

INSERT INTO #_TP_persontypes (id, type, title, class, style, g_type, tpl, tplindex, rank, status, upd) VALUES ('6', 'auteur', 'Auteur du billet', 'personnes', 'auteur', 'dc.creator', 'auteur', 'auteurs', '1', '1', '20050512180157');

#
# Dumping data for table 'lodel_entrytypes'
#

INSERT INTO #_TP_entrytypes (id, type, class, title, style, g_type, tpl, tplindex, rank, status, flat, newbyimportallowed, edition, sort, upd) VALUES ('7', 'motcle', 'motscles', 'Index de mots-clés', 'motscles, .motscles', 'dc.subject', 'mot', 'mots', '1', '1', '0', '1', 'pool', 'sortkey', '20050512180157');

#
# Dumping data for table 'lodel_entitytypes_entitytypes'
#

INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('2', '0', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('4', '5', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('1', '2', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('4', '3', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('3', '0', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('5', '3', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('14', '1', '*');

#
# Dumping data for table 'lodel_characterstyles'
#


#
# Dumping data for table 'lodel_internalstyles'
#

INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('1', 'citation', '*-', '', '0', '1', '1', '20050507011206');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('2', 'quotations', '*-', '', '0', '2', '1', '20050507011308');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('3', 'code', '*-', '', '0', '3', '1', '20050507011311');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('4', 'legendeillustration', '*-', '', '0', '4', '1', '20050507011315');
DELETE FROM #_TP_optiongroups;
# # Database: 'lodeldevel_blog'# 
#
# Dumping data for table 'lodel_optiongroups'
#

INSERT INTO #_TP_optiongroups (id, idparent, name, title, comment, logic, exportpolicy, rank, status, upd) VALUES ('1', '0', 'servoo', 'servoo', '', 'servooconf', '1', '1', '32', '20050302224858');
INSERT INTO #_TP_optiongroups (id, idparent, name, title, comment, logic, exportpolicy, rank, status, upd) VALUES ('2', '0', 'metadonneessite', 'Métadonnées du site', '', '', '1', '2', '1', '20050507004445');
DELETE FROM #_TP_options;
# # Database: 'lodeldevel_blog'# 
#
# Dumping data for table 'lodel_options'
#

INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status) VALUES ('1', '1', 'url', 'url', 'tinytext', '', '', '40', '1', '32');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status) VALUES ('2', '1', 'username', 'username', 'tinytext', '', '', '40', '2', '32');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status) VALUES ('3', '1', 'passwd', 'password', 'passwd', '', '', '40', '3', '32');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status) VALUES ('4', '2', 'titresite', 'Titre du site', 'text', '', '', '40', '4', '1');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status) VALUES ('5', '2', 'mail', 'Courriel de l\'auteur du site', 'email', '', '', '40', '5', '1');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status) VALUES ('6', '2', 'descriptionsite', 'Description du site', 'text', '', '', '40', '6', '1');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status) VALUES ('7', '2', 'motcles', 'Mots-clés du site', 'text', '', '', '40', '7', '1');
# # Database: 'lodeldevel_blog'# 
# --------------------------------------------------------

#
# Table structure for table 'lodel_documents'
#

DROP TABLE IF EXISTS #_TP_documents;
CREATE TABLE #_TP_documents (
  identity int(10) unsigned default NULL,
  titre text,
  soustitre text,
  datepubli datetime default NULL,
  langue varchar(5) default NULL,
  icone tinytext,
  texte longtext,
  notebaspage text,
  erratum text,
  resume text,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table 'lodel_publications'
#

DROP TABLE IF EXISTS #_TP_publications;
CREATE TABLE #_TP_publications (
  identity int(10) unsigned default NULL,
  titre text,
  icone tinytext,
  introduction text,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table 'lodel_liens'
#

DROP TABLE IF EXISTS #_TP_liens;
CREATE TABLE #_TP_liens (
  identity int(10) unsigned default NULL,
  titre text,
  lien text,
  rss text,
  texte text,
  langue varchar(5) default NULL,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table 'lodel_motscles'
#

DROP TABLE IF EXISTS #_TP_motscles;
CREATE TABLE #_TP_motscles (
  identry int(10) unsigned default NULL,
  nom text,
  UNIQUE KEY identry (identry),
  KEY index_identry (identry)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table 'lodel_personnes'
#

DROP TABLE IF EXISTS #_TP_personnes;
CREATE TABLE #_TP_personnes (
  idperson int(10) unsigned default NULL,
  prenom text,
  nom text,
  UNIQUE KEY idperson (idperson),
  KEY index_idperson (idperson)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table 'lodel_entities_personnes'
#

DROP TABLE IF EXISTS #_TP_entities_personnes;
CREATE TABLE #_TP_entities_personnes (
  idrelation int(10) unsigned default NULL,
  description text,
  UNIQUE KEY idrelation (idrelation),
  KEY index_idrelation (idrelation)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table 'lodel_commentaires'
#

DROP TABLE IF EXISTS #_TP_commentaires;
CREATE TABLE #_TP_commentaires (
  identity int(10) unsigned default NULL,
  titre tinytext,
  texte text,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) TYPE=MyISAM;
