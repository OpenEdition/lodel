/* IE */
if (navigator.userAgent.indexOf('MSIE') >= 0) {
	
	/* Win */
	if (navigator.userAgent.indexOf('Win') >= 0) {
		
		document.write('<link href="iewin.css" rel="Stylesheet" media="all" />');

		/* IE 6x Win */
		if (navigator.userAgent.indexOf('MSIE 6') >= 0) {
			document.write('<style type="text/css"></style>');
			
		/* IE 5.5x Win */
		} else if (navigator.userAgent.indexOf('MSIE 5.5') >= 0) {
			document.write('<style type="text/css"></style>');
			
		/* IE 5.0x Win */
		} else if (navigator.userAgent.indexOf('MSIE 5.0') >= 0) {
			document.write('<style type="text/css">#naviguer{width:176px;top:153px;}</style>');
		}
		
	/* Mac */
	} else {
		/* IE Mac */
		if (navigator.userAgent.indexOf('MSIE') >= 0 && navigator.userAgent.indexOf('Mac') >= 0) {
			document.write('<link href="iemac.css" rel="Stylesheet" media="all" />');
		}
	}
} else {

	/* Netscape 7  */
	if (navigator.userAgent.indexOf('Netscape') >= 0) {
		document.write('<style type="text/css"></style>');
	}
		
	/* Mozilla... */
	if (navigator.userAgent.indexOf('Gecko') >= 0 && navigator.userAgent.indexOf('Netscape') < 0 && navigator.userAgent.indexOf('Safari') < 0) {
		document.write('<style type="text/css"></style>');
	}
	/* Safari... */
	if (navigator.userAgent.indexOf('Safari') >= 0) {
		document.write('<style type="text/css"></style>');
	}
	/* Opera */
	if (navigator.userAgent.indexOf('Opera') >= 0) {
		document.write('<style type="text/css"></style>');
	}
}