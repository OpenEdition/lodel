# <model>
# <lodelversion>0.8</lodelversion>
# <date>2005-05-17</date>
# <title>
# ME de base
# </title>
# <description>
# ME base est un modèle éditorial basique. Il ne comporte ni classes ni types ni champ. Seul sont définies les options pour l'utilisation de ServOO.
# </description>
# <author>
# Jean Lamy
# </author>
# <modelversion>
# 1.1
# </modelversion>
# </model>
#  
#------------

DELETE FROM #_TP_classes;
DELETE FROM #_TP_tablefields;
DELETE FROM #_TP_tablefieldgroups;
DELETE FROM #_TP_types;
DELETE FROM #_TP_persontypes;
DELETE FROM #_TP_entrytypes;
DELETE FROM #_TP_entitytypes_entitytypes;
DELETE FROM #_TP_characterstyles;
DELETE FROM #_TP_internalstyles;
# # Database: 'lodeldbtest'# 
#
# Dumping data for table 'lodel_classes'
#


#
# Dumping data for table 'lodel_tablefields'
#


#
# Dumping data for table 'lodel_tablefieldgroups'
#


#
# Dumping data for table 'lodel_types'
#


#
# Dumping data for table 'lodel_persontypes'
#


#
# Dumping data for table 'lodel_entrytypes'
#


#
# Dumping data for table 'lodel_entitytypes_entitytypes'
#


#
# Dumping data for table 'lodel_characterstyles'
#


#
# Dumping data for table 'lodel_internalstyles'
#

DELETE FROM #_TP_optiongroups;
# # Database: 'lodeldbtest'# 
#
# Dumping data for table 'lodel_optiongroups'
#

INSERT INTO #_TP_optiongroups (id, idparent, name, title, comment, logic, exportpolicy, rank, status, upd) VALUES ('1', '0', 'servoo', 'servoo', '', 'servooconf', '1', '1', '32', '20050302224858');
DELETE FROM #_TP_options;
# # Database: 'lodeldbtest'# 
#
# Dumping data for table 'lodel_options'
#

INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status) VALUES ('1', '1', 'url', 'url', 'tinytext', '', '', '40', '1', '32');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status) VALUES ('2', '1', 'username', 'username', 'tinytext', '', '', '40', '2', '32');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status) VALUES ('3', '1', 'passwd', 'password', 'passwd', '', '', '40', '3', '32');
