# <model>
# <lodelversion>0.8</lodelversion>
# <date>2005-03-02</date>
# <title>
# 
# </title>
# <description>
# 
# </description>
# <author>
# 
# </author>
# <modelversion>
# 
# </modelversion>
# </model>
#  
#------------

DELETE FROM #_TP_classes;
DELETE FROM #_TP_tablefields;
DELETE FROM #_TP_tablefieldgroups;
DELETE FROM #_TP_types;
DELETE FROM #_TP_persontypes;
DELETE FROM #_TP_entrytypes;
DELETE FROM #_TP_entitytypes_entitytypes;
# # Database: 'lodelinstall'# 
#
# Dumping data for table 'lodel_classes'
#


#
# Dumping data for table 'lodel_tablefields'
#


#
# Dumping data for table 'lodel_tablefieldgroups'
#

#
# Dumping data for table 'lodel_types'
#


#
# Dumping data for table 'lodel_persontypes'
#


#
# Dumping data for table 'lodel_entrytypes'
#


#
# Dumping data for table 'lodel_entitytypes_entitytypes'
#

DELETE FROM #_TP_optiongroups;
# # Database: 'lodelinstall'# 
#
# Dumping data for table 'lodel_optiongroups'
#

INSERT INTO #_TP_optiongroups (id, name, title, comment, logic, exportpolicy, rank, status, upd) VALUES ('1', 'servoo', 'servoo', '', 'servooconf', '1', '1', '32', '20050302224858');
DELETE FROM #_TP_options;
# # Database: 'lodelinstall'# 
#
# Dumping data for table 'lodel_options'
#

INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, userrights, rank, status) VALUES ('1', '1', 'url', 'url', 'tinytext', '',  '40', '1', '32');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, userrights, rank, status) VALUES ('2', '1', 'username', 'username', 'tinytext', '', '40', '2', '32');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, userrights, rank, status) VALUES ('3', '1', 'passwd', 'password', 'passwd',  '', '40', '3', '32');

