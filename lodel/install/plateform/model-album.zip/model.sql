# <model>
# <lodelversion>0.7</lodelversion>
# <date>2005-01-21</date>
# <title>
# Album photo
# </title>
# <description>
# Le modèle éditorial Album Photo permet de publier des photos de facon simple et esthétique. Les fonctionnalités de ce modèle sont volontairement réduites pour un publication rapide et un rendu épuré.
# </description>
# <author>
# Jennifer Pellenq
# </author>
# <modelversion>
# 1.0
# </modelversion>
# </model>
#  
#------------

DELETE FROM __LODELTP__champs;
DELETE FROM __LODELTP__groupesdechamps;
DELETE FROM __LODELTP__types;
DELETE FROM __LODELTP__typepersonnes;
DELETE FROM __LODELTP__typeentrees;
DELETE FROM __LODELTP__typeentites_typeentites;
DELETE FROM __LODELTP__typeentites_typeentrees;
DELETE FROM __LODELTP__typeentites_typepersonnes;
# # Database: 'lodelalbum'# 
#
# Dumping data for table 'lodel_champs'
#

INSERT INTO __LODELTP__champs (id, nom, idgroupe, titre, style, type, `condition`, defaut, traitement, balises, filtrage, edition, commentaire, statut, ordre, maj) VALUES ('1', 'titre', '14', 'Titre du document', 'title', 'text', '+', 'Document sans titre', '', 'xhtml:fontstyle;xhtml:phrase;Lien', '', 'text', 'Titre du document.', '32', '1', '2004-03-14 15:55:19');
INSERT INTO __LODELTP__champs (id, nom, idgroupe, titre, style, type, `condition`, defaut, traitement, balises, filtrage, edition, commentaire, statut, ordre, maj) VALUES ('7', 'texte', '2', 'Texte du document', 'texte', 'longtext', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note;texte Lodel;Sections', '', 'textarea30', 'Texte du document', '32', '2', '2004-06-06 16:59:50');
INSERT INTO __LODELTP__champs (id, nom, idgroupe, titre, style, type, `condition`, defaut, traitement, balises, filtrage, edition, commentaire, statut, ordre, maj) VALUES ('31', 'fichiersassocies', '3', 'Fichiers associés au document', '', 'fichier', '*', '', '', '', '', '', 'Ce champ est un champ utilisé en interne par Lodel. Ne pas le modifier.', '32', '1', '2004-03-05 16:00:48');
INSERT INTO __LODELTP__champs (id, nom, idgroupe, titre, style, type, `condition`, defaut, traitement, balises, filtrage, edition, commentaire, statut, ordre, maj) VALUES ('32', 'datepubli', '1', 'Date de la publication électronique', 'datepubli', 'datetime', '*', 'today', '', '0', '', 'editable', 'Date de publication du texte intégral en ligne', '32', '2', '2004-06-06 17:00:00');
INSERT INTO __LODELTP__champs (id, nom, idgroupe, titre, style, type, `condition`, defaut, traitement, balises, filtrage, edition, commentaire, statut, ordre, maj) VALUES ('51', 'titre', '10', 'Titre de la publication', 'title', 'text', '+', 'Publication sans titre', '', 'xhtml:fontstyle;xhtml:phrase;Lien', '', 'text', '', '32', '1', '2004-03-05 10:30:53');
INSERT INTO __LODELTP__champs (id, nom, idgroupe, titre, style, type, `condition`, defaut, traitement, balises, filtrage, edition, commentaire, statut, ordre, maj) VALUES ('89', 'icone', '17', 'Icône de la publication', '', 'image', '*', '', '', '', '', '', '', '32', '1', '2004-03-05 10:03:06');
INSERT INTO __LODELTP__champs (id, nom, idgroupe, titre, style, type, `condition`, defaut, traitement, balises, filtrage, edition, commentaire, statut, ordre, maj) VALUES ('66', 'fichiersource', '3', 'Fichier source', '', 'fichier', '*', '', '', '', '', '', '', '32', '5', '2004-02-23 17:44:19');
INSERT INTO __LODELTP__champs (id, nom, idgroupe, titre, style, type, `condition`, defaut, traitement, balises, filtrage, edition, commentaire, statut, ordre, maj) VALUES ('67', 'introduction', '18', 'Introduction de la publication', '', 'text', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note;texte Lodel;Sections', '', '', '', '32', '1', '2004-03-05 10:02:34');
INSERT INTO __LODELTP__champs (id, nom, idgroupe, titre, style, type, `condition`, defaut, traitement, balises, filtrage, edition, commentaire, statut, ordre, maj) VALUES ('74', 'importversion', '3', 'Version de l\'importation', '', 'tinytext', '*', '', '', '', '', '', '', '32', '6', '2004-02-23 17:44:08');
INSERT INTO __LODELTP__champs (id, nom, idgroupe, titre, style, type, `condition`, defaut, traitement, balises, filtrage, edition, commentaire, statut, ordre, maj) VALUES ('88', 'image', '1', 'Image', '', 'image', '*', '', '', '', '', 'editable', '', '32', '1', '2004-09-27 18:44:05');

#
# Dumping data for table 'lodel_groupesdechamps'
#

INSERT INTO __LODELTP__groupesdechamps (id, nom, classe, titre, commentaire, statut, ordre, maj) VALUES ('1', 'grmeta', 'documents', 'Groupe métadonnées', '', '32', '2', '2004-09-27 18:44:01');
INSERT INTO __LODELTP__groupesdechamps (id, nom, classe, titre, commentaire, statut, ordre, maj) VALUES ('2', 'grtexte', 'documents', 'Groupe du texte', '', '32', '3', '2004-09-27 18:44:01');
INSERT INTO __LODELTP__groupesdechamps (id, nom, classe, titre, commentaire, statut, ordre, maj) VALUES ('3', 'grgestion', 'documents', 'Groupe gestion des documents', '', '32', '4', '2004-09-27 18:44:01');
INSERT INTO __LODELTP__groupesdechamps (id, nom, classe, titre, commentaire, statut, ordre, maj) VALUES ('10', 'grtitre', 'publications', 'Groupe titre', '', '32', '1', '2004-03-05 05:35:28');
INSERT INTO __LODELTP__groupesdechamps (id, nom, classe, titre, commentaire, statut, ordre, maj) VALUES ('14', 'grtitre', 'documents', 'Groupe du titre', '', '1', '1', '2004-02-23 17:30:58');
INSERT INTO __LODELTP__groupesdechamps (id, nom, classe, titre, commentaire, statut, ordre, maj) VALUES ('17', 'grmetadonnees', 'publications', 'Groupe des métadonnées', '', '32', '3', '2004-03-04 13:34:34');
INSERT INTO __LODELTP__groupesdechamps (id, nom, classe, titre, commentaire, statut, ordre, maj) VALUES ('18', 'graddenda', 'publications', 'Groupe addenda', '', '32', '4', '2004-03-04 13:55:21');

#
# Dumping data for table 'lodel_types'
#

INSERT INTO __LODELTP__types (id, type, titre, classe, tpl, tplcreation, tpledition, import, ordre, statut, maj) VALUES ('1', 'categorie', 'Catégorie', 'publications', 'categorie', 'creation-serie', 'edition-hierarchique', '0', '1', '32', '2005-01-08 00:20:50');
INSERT INTO __LODELTP__types (id, type, titre, classe, tpl, tplcreation, tpledition, import, ordre, statut, maj) VALUES ('2', 'documentannexe-lienfichier', 'Vers un fichier', 'documents', '', 'documentannexe-lienfichier', '', '0', '8', '32', '2005-01-08 00:20:50');
INSERT INTO __LODELTP__types (id, type, titre, classe, tpl, tplcreation, tpledition, import, ordre, statut, maj) VALUES ('3', 'documentannexe-liendocument', 'Vers un document interne au site', 'documents', '', 'documentannexe-liendocument', '', '0', '10', '32', '2005-01-08 00:20:50');
INSERT INTO __LODELTP__types (id, type, titre, classe, tpl, tplcreation, tpledition, import, ordre, statut, maj) VALUES ('4', 'documentannexe-lienpublication', 'Vers une publication interne au site', 'documents', '', 'documentannexe-lienpublication', '', '0', '11', '32', '2005-01-08 00:20:50');
INSERT INTO __LODELTP__types (id, type, titre, classe, tpl, tplcreation, tpledition, import, ordre, statut, maj) VALUES ('5', 'documentannexe-lienexterne', 'Vers un site externe', 'documents', '', 'documentannexe-lienexterne', '', '0', '9', '32', '2005-01-08 00:20:50');
INSERT INTO __LODELTP__types (id, type, titre, classe, tpl, tplcreation, tpledition, import, ordre, statut, maj) VALUES ('6', 'Photo', 'Photo', 'documents', 'photo', 'document', '', '0', '5', '32', '2005-01-08 00:20:50');

#
# Dumping data for table 'lodel_typepersonnes'
#

INSERT INTO __LODELTP__typepersonnes (id, type, titre, style, titredescription, styledescription, tpl, tplindex, ordre, statut, maj) VALUES ('7', 'auteur', 'Auteur', 'auteur', 'description de l\'auteur', 'descriptionauteur', 'auteur', 'auteurs', '1', '32', '2005-01-08 00:20:50');

#
# Dumping data for table 'lodel_typeentrees'
#

INSERT INTO __LODELTP__typeentrees (id, type, titre, style, tpl, tplindex, ordre, statut, lineaire, nvimportable, utiliseabrev, tri, maj) VALUES ('8', 'motcle', 'Index par mots clés', '', 'mot', 'mots', '1', '32', '1', '1', '0', 'nom', '2005-01-08 00:20:50');

#
# Dumping data for table 'lodel_typeentites_typeentites'
#

INSERT INTO __LODELTP__typeentites_typeentites (idtypeentite, idtypeentite2, `condition`) VALUES ('1', '0', '*');
INSERT INTO __LODELTP__typeentites_typeentites (idtypeentite, idtypeentite2, `condition`) VALUES ('6', '1', '*');

#
# Dumping data for table 'lodel_typeentites_typeentrees'
#


#
# Dumping data for table 'lodel_typeentites_typepersonnes'
#

# # Database: 'lodelalbum'# 
# --------------------------------------------------------

#
# Table structure for table 'lodel_documents'
#

DROP TABLE IF EXISTS __LODELTP__documents;
CREATE TABLE __LODELTP__documents (
  identite int(10) unsigned NOT NULL default '0',
  titre text,
  intro text NOT NULL,
  langresume varchar(64) NOT NULL default '',
  lang varchar(64) NOT NULL default '',
  meta text,
  datepubli datetime default NULL,
  texte longtext,
  fichiersassocies tinytext,
  fichiersource tinytext,
  importversion tinytext,
  image tinytext,
  PRIMARY KEY  (identite),
  UNIQUE KEY identite (identite)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table 'lodel_publications'
#

DROP TABLE IF EXISTS __LODELTP__publications;
CREATE TABLE __LODELTP__publications (
  identite int(10) unsigned NOT NULL default '0',
  titre text,
  introduction text,
  meta text,
  date date default NULL,
  image tinytext,
  introdution text,
  icone tinytext,
  PRIMARY KEY  (identite),
  UNIQUE KEY identite (identite)
) TYPE=MyISAM;
