# <model>
# 			<lodelversion></lodelversion>
# 			<date>2008-05-30</date>
# 			<title>
# 			Modèle éditorial de Revues.org
# 			</title>
# 			<description>
# 			Modèle éditorial de Revues.org
# 			</description>
# 			<author>
# 			Revues.org
# 			</author>
# 			<modelversion>
# 			20080530
# 			</modelversion>
# 			</model>
# 			
#------------

DELETE FROM #_TP_classes;
DELETE FROM #_TP_tablefields;
DELETE FROM #_TP_tablefieldgroups;
DELETE FROM #_TP_types;
DELETE FROM #_TP_persontypes;
DELETE FROM #_TP_entrytypes;
DELETE FROM #_TP_entitytypes_entitytypes;
DELETE FROM #_TP_characterstyles;
DELETE FROM #_TP_internalstyles;
# # Database: ''# 
#
# Dumping data for table 'classes'
#

INSERT INTO #_TP_classes (id, icon, class, title, altertitle, classtype, comment, rank, status, upd) VALUES ('40', 'lodel/icons/texte.gif', 'textes', 'Textes', '', 'entities', '', '2', '32', '2006-09-28 11:40:39'),
('41', 'lodel/icons/collection.gif', 'publications', 'Publications', '', 'entities', '', '1', '1', '2006-09-28 11:40:39'),
('42', 'lodel/icons/doc_annexe.gif', 'fichiers', 'Fichiers', '', 'entities', '', '5', '32', '2006-09-28 11:40:39'),
('43', 'lodel/icons/lien.gif', 'liens', 'Sites', '', 'entities', '', '6', '32', '2006-09-28 11:40:39'),
('44', 'lodel/icons/texte_simple.gif', 'textessimples', 'Textes simples', '', 'entities', '', '3', '32', '2006-09-28 11:40:39'),
('45', 'lodel/icons/personne.gif', 'auteurs', 'Auteurs', '', 'persons', '', '8', '32', '2006-12-20 16:23:01'),
('46', 'lodel/icons/index.gif', 'indexes', 'Index', '', 'entries', '', '9', '1', '2006-09-28 11:40:39'),
('47', 'lodel/icons/individu.gif', 'individus', 'Personnes', '', 'entities', '', '4', '1', '2006-09-28 11:40:39'),
('48', 'lodel/icons/index_avance.gif', 'indexavances', 'Index avancés', '', 'entries', '', '10', '1', '2006-09-28 11:40:39');

#
# Dumping data for table 'tablefields'
#

INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, gui_user_complexity, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('1', 'titre', '1', 'textes', 'Titre du document', '', 'title, titre, titleuser, heading', 'text', 'dc.title', '+', 'Document sans titre', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Lien;Appel de Note', '16', '', 'editable', '', '8', '', '32', '3', '2006-03-01 19:10:00'),
('2', 'surtitre', '1', 'textes', 'Surtitre du document', '', 'surtitre', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Lien;Appel de Note', '32', '', 'importable', '', '8', '', '32', '2', '2006-03-01 19:09:47'),
('3', 'soustitre', '1', 'textes', 'Sous-titre du document', '', 'subtitle, soustitre', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Lien;Appel de Note', '32', '', 'editable', '', '8', '', '32', '5', '2006-07-13 10:25:47'),
('4', 'texte', '2', 'textes', 'Texte du document', '', 'texte, standard, normal, textbody', 'longtext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '16', '', 'display', '', '4', '', '32', '1', '2006-12-06 19:56:09'),
('5', 'notesbaspage', '2', 'textes', 'Notes de bas de page', '', 'notebaspage, footnote, footnotetext', 'longtext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', '32', '', 'importable', '', '4', '', '32', '2', '2007-12-13 12:18:36'),
('7', 'annexe', '2', 'textes', 'Annexes du document', '', 'annexe', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '32', '', 'importable', '', '4', '', '32', '4', '2006-12-18 11:28:37'),
('8', 'bibliographie', '2', 'textes', 'Bibliographie du document', '', 'bibliographie', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '32', '', 'importable', '', '4', '', '32', '5', '2006-12-18 11:28:52'),
('9', 'datepubli', '3', 'textes', 'Date de la publication électronique', '', 'datepubli', 'date', 'dc.date', '*', 'today', '', '', '16', '', 'editable', '', '0', '', '32', '1', '2006-06-19 08:28:07'),
('10', 'datepublipapier', '3', 'textes', 'Date de la publication sur papier', '', 'datepublipapier', 'date', '', '*', '', '', '', '32', '', 'editable', '', '0', '', '32', '2', '2006-03-01 18:26:08'),
('11', 'noticebiblio', '3', 'textes', 'Notice bibliographique du document', '', 'noticebiblio', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special', '64', '', 'importable', '', '0', '', '32', '3', '2007-10-05 16:48:30'),
('12', 'pagination', '3', 'textes', 'Pagination du document sur le papier', '', 'pagination', 'tinytext', '', '*', '', '', '', '64', '', 'editable', '', '0', '', '32', '4', '2005-06-19 16:00:22'),
('130', 'editeurscientifique', '14', 'textes', 'Éditeur scientifique', '', '', 'persons', '', '', '', '', '', '64', '', 'editable', '', '0', '', '1', '109', '2006-03-01 19:03:00'),
('14', 'langue', '3', 'textes', 'Langue du document', '', 'langue', 'lang', 'dc.language', '*', 'fr', '', '', '32', '', 'editable', '', '0', '', '1', '6', '2007-10-18 17:06:51'),
('15', 'prioritaire', '16', 'textes', 'Document prioritaire', '', '', 'boolean', '', '*', '', '', '', '64', '', 'editable', '', '0', '', '32', '7', '2005-06-19 16:00:22'),
('17', 'addendum', '4', 'textes', 'Addendum', '', 'erratum, addendum', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '64', '', 'importable', '', '2', '', '32', '3', '2006-03-08 17:48:24'),
('18', 'ndlr', '4', 'textes', 'Note de la rédaction', '', 'ndlr', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '64', '', 'importable', '', '2', '', '32', '1', '2006-03-08 17:48:20'),
('20', 'commentaireinterne', '16', 'textes', 'Commentaire interne sur le document', '', 'commentaire', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', '64', '', 'importable', '', '0', '', '32', '4', '2005-06-19 16:00:22'),
('21', 'dedicace', '4', 'textes', 'Dédicace', '', 'dedicace', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '64', '', 'importable', '', '2', '', '32', '4', '2006-03-08 17:48:20'),
('23', 'ocr', '16', 'textes', 'Document issu d\'une numérisation dite OCR', '', '', 'boolean', '', '*', '', '', '', '64', '', 'importable', '', '0', '', '32', '9', '2005-06-19 16:00:22'),
('24', 'documentcliquable', '16', 'textes', 'Document cliquable dans les sommaires', '', '', 'boolean', '', '*', 'true', '', '', '64', '', 'editable', '', '0', '', '32', '10', '2005-06-19 16:00:22'),
('25', 'nom', '0', 'indexes', 'Dénomination de l\'entrée d\'index', '', '', 'text', 'index key', '*', 'Tous droits réservés', '', '', '16', '', 'editable', '', '4', '', '32', '25', '2006-06-19 12:43:13'),
('26', 'motsclesfr', '15', 'textes', 'Index de mots-clés', '', '', 'entries', '', '', '', '', '', '64', '', 'editable', '', '0', '', '32', '2', '2008-01-23 12:06:56'),
('27', 'definition', '0', 'indexes', 'Définition', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', '16', '', 'fckeditor', 'Basic', '1', '', '32', '27', '2006-07-10 17:15:19'),
('28', 'nomfamille', '0', 'auteurs', 'Nom de famille', '', '', 'tinytext', 'familyname', '*', '', '', '', '32', '', 'editable', '', '4', '', '32', '28', '2006-12-18 11:35:36'),
('29', 'prenom', '0', 'auteurs', 'Prénom', '', '', 'tinytext', 'firstname', '*', '', '', '', '32', '', 'editable', '', '4', '', '32', '29', '2006-12-18 11:39:26'),
('30', 'prefix', '0', 'entities_auteurs', 'Préfixe', '', 'prefixe, .prefixe', 'tinytext', '', '*', '', '', '', '64', '', 'editable', '', '0', '', '1', '2', '2007-01-15 13:03:35'),
('31', 'affiliation', '0', 'entities_auteurs', 'Affiliation', '', 'affiliation, .affiliation', 'tinytext', '', '*', '', '', '', '32', '', 'editable', '', '4', '', '1', '3', '2007-01-15 13:03:33'),
('32', 'fonction', '0', 'entities_auteurs', 'Fonction', '', 'fonction, .fonction', 'tinytext', '', '*', '', '', '', '32', '', 'editable', '', '0', '', '1', '4', '2007-01-15 13:05:00'),
('33', 'description', '0', 'entities_auteurs', 'Description de l\'auteur', '', 'descriptionauteur', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Lien', '16', '', 'fckeditor', '5', '4', '', '1', '1', '2007-09-13 14:43:38'),
('34', 'courriel', '0', 'entities_auteurs', 'Courriel', '', 'courriel, .courriel', 'email', '', '*', '', '', '', '32', '', 'editable', '', '4', '', '1', '5', '2007-01-15 13:05:15'),
('35', 'auteur', '14', 'textes', 'Auteur du document', '', '', 'persons', '', '', '', '', '', '64', '', 'editable', '', '0', '', '32', '11', '2005-06-19 16:00:22'),
('36', 'traducteur', '14', 'textes', 'Traducteur du document', '', '', 'persons', '', '', '', '', '', '64', '', 'editable', '', '0', '', '32', '12', '2006-03-01 18:51:45'),
('142', 'alias', '16', 'textes', 'Alias', '', '', 'entities', '', '*', '', '', '', '64', '', 'editable', '', '0', '', '1', '119', '2006-12-18 12:50:12'),
('117', 'date', '19', 'textessimples', 'Date de publication en ligne', '', '', 'datetime', '', '*', 'now', '', '', '16', '', 'editable', '', '0', '', '1', '100', '2006-06-27 23:51:45'),
('116', 'url', '19', 'textessimples', 'Lien', '', '', 'url', '', '*', '', '', '', '16', '', 'editable', '', '2', '', '1', '99', '2006-06-27 23:50:37'),
('140', 'licence', '24', 'fichiers', 'Licence', '', '', 'entries', '', '', '', '', '', '64', '', 'editable', '', '0', '', '1', '118', '2006-03-07 17:09:58'),
('43', 'titre', '5', 'liens', 'Titre du site', '', '', 'text', 'dc.title', '*', 'Site sans titre', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', '16', '', 'editable', '', '8', '', '32', '43', '2006-06-22 17:54:35'),
('44', 'url', '6', 'liens', 'URL du site', '', '', 'url', '', '*', '', '', '', '16', '', 'editable', '', '0', '', '32', '1', '2006-06-22 17:57:52'),
('45', 'urlfil', '6', 'liens', 'URL du fil de syndication du site', '', '', 'url', '', '*', '', '', '', '16', '', 'editable', '', '0', '', '32', '4', '2006-06-22 17:55:41'),
('46', 'texte', '6', 'liens', 'Description du site', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '16', '', 'fckeditor', 'Simple', '2', '', '32', '2', '2006-07-10 17:16:44'),
('47', 'titre', '7', 'fichiers', 'Titre', '', '', 'text', 'dc.title', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', '16', '', 'editable', '', '4', '', '32', '47', '2006-06-22 22:53:15'),
('48', 'document', '8', 'fichiers', 'Document', '', '', 'file', '', '*', '', '', '', '16', '', 'editable', '', '0', '', '32', '1', '2006-06-22 22:53:31'),
('74', 'altertitre', '1', 'textes', 'Titre alternatif du document (dans une autre langue)', '', 'titretraduitfr:fr,titrefr:fr,titretraduiten:en,titleen:en,titreen:en,titretraduites:es,tituloes:es,titrees:es,titretraduitit:it,titoloit:it,titreit:it,titretraduitde:de,titelde:de,titrede:de,titretraduitpt:pt,titrept:pt,titretraduitru:ru,titreru:ru', 'mltext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Lien;Appel de Note', '16', '', 'editable', '', '8', '', '32', '4', '2008-02-20 14:07:08'),
('50', 'resume', '9', 'textes', 'Résumé', '', 'rsum:fr,resume:fr,resumefr:fr,abstract:en,resumeen:en,extracto:es,resumen:es, resumees:es,resumo:pt,resumept:pt,riassunto:it,resumeit:it,zusammenfassung:de,resumede:de,resumeru:ru', 'mltext', 'dc.description', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '16', '', 'display', '5', '8', '', '32', '50', '2008-04-08 14:29:18'),
('51', 'titre', '10', 'publications', 'Titre de la publication', '', 'title, titre, titleuser, heading', 'text', 'dc.title', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', '16', '', 'editable', '', '8', '', '32', '2', '2006-07-05 18:07:28'),
('52', 'surtitre', '10', 'publications', 'Surtitre de la publication', '', 'surtitre', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', '16', '', 'importable', '', '8', '', '32', '1', '2006-07-10 16:08:07'),
('53', 'soustitre', '10', 'publications', 'Sous-titre de la publication', '', 'soustitre', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', '16', '', 'editable', '', '8', '', '32', '3', '2006-07-10 16:08:22'),
('54', 'commentaireinterne', '11', 'publications', 'Commentaire interne sur la publication', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', '64', '', 'editable', '4', '0', '', '32', '54', '2006-07-10 16:17:37'),
('55', 'prioritaire', '11', 'publications', 'Cette publication est-elle prioritaire ?', '', '', 'boolean', '', '*', '', '', '', '16', '', 'editable', '', '0', '', '32', '55', '2006-07-10 16:17:49'),
('57', 'datepubli', '12', 'publications', 'Date de publication électronique', '', '', 'date', 'dc.date', '*', 'today', '', '', '16', '', 'editable', '', '0', '', '32', '2', '2006-07-10 16:16:10'),
('58', 'datepublipapier', '12', 'publications', 'Date de publication papier', '', '', 'date', '', '*', '', '', '', '16', '', 'editable', '', '0', '', '32', '3', '2006-07-10 16:16:18'),
('59', 'noticebiblio', '12', 'publications', 'Notice bibliographique décrivant la publication', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special', '64', '', 'importable', '', '0', '', '32', '4', '2007-10-18 17:03:43'),
('60', 'introduction', '13', 'publications', 'Introduction de la publication', '<r2r:ml lang="fr">Introduction de la publication</r2r:ml>', 'texte, standard, normal', 'mltext', 'dc.description', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '16', '', 'fckeditor', 'Simple,550,400', '8', '', '32', '60', '2008-01-30 12:24:49'),
('131', 'geographie', '15', 'textes', 'Index géographique', '', '', 'entries', '', '', '', '', '', '64', '', 'editable', '', '0', '', '1', '110', '2006-03-02 02:00:04'),
('132', 'chrono', '15', 'textes', 'Index chronologique', '', '', 'entries', '', '', '', '', '', '64', '', 'editable', '', '0', '', '1', '111', '2006-03-02 02:00:25'),
('62', 'ndlr', '13', 'publications', 'Note de la rédaction au sujet de la publication', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '64', '', 'fckeditor', '', '2', '', '32', '62', '2006-07-10 16:15:06'),
('63', 'historique', '13', 'publications', 'Historique de la publication', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '64', '', 'importable', '', '0', '', '32', '63', '2007-05-04 06:59:30'),
('64', 'periode', '12', 'publications', 'Période de publication', '', '', 'tinytext', '', '*', '', '', '', '16', '', 'importable', '', '0', '', '1', '5', '2007-10-11 10:35:59'),
('65', 'isbn', '12', 'publications', 'ISBN', '', '', 'tinytext', '', '*', '', '', '', '16', '', 'editable', '', '0', '', '1', '7', '2007-10-15 14:47:17'),
('66', 'paraitre', '11', 'publications', 'Cette publication est-elle à paraitre ?', '', '', 'boolean', '', '*', '', '', '', '32', '', 'editable', '', '0', '', '32', '66', '2006-07-10 16:18:03'),
('67', 'integralite', '11', 'publications', 'Cette publication en ligne est-elle intégrale ?', '', '', 'boolean', '', '*', '', '', '', '32', '', 'editable', '', '0', '', '32', '67', '2006-07-10 16:18:15'),
('68', 'numero', '12', 'publications', 'Numéro de la publication', '', '', 'tinytext', '', '*', '', '', '', '16', '', 'editable', '', '0', '', '32', '6', '2006-07-10 16:16:47'),
('69', 'motsclesen', '15', 'textes', 'Keywords index', '', '', 'entries', '', '', '', '', '', '64', '', 'editable', '', '0', '', '32', '3', '2006-07-13 14:57:59'),
('70', 'role', '0', 'entities_auteurs', 'Role dans l\'élaboration du document', '', 'role,.role', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special', '64', '', 'editable', '', '0', '', '1', '7', '2007-11-23 10:24:41'),
('119', 'email', '30', 'individus', 'Courriel', '', '', 'email', '', '*', '', '', '', '16', '', 'editable', '', '4', '', '1', '3', '2006-06-22 18:11:49'),
('120', 'siteweb', '30', 'individus', 'Site web', '', '', 'url', '', '*', '', '', '', '16', '', 'editable', '', '0', '', '1', '4', '2006-07-13 14:09:52'),
('121', 'description', '30', 'individus', 'Description', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '16', '', 'fckeditor', 'Simple', '4', '', '1', '2', '2006-07-10 16:34:39'),
('76', 'titreoeuvre', '17', 'textes', 'Titre de l\'oeuvre commentée', '', 'titreoeuvre', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', '64', '', 'display', '', '4', '', '32', '2', '2007-10-05 16:51:39'),
('77', 'noticebibliooeuvre', '17', 'textes', 'Notice bibliographique de l\'oeuvre commentée', '', 'noticebibliooeuvre', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Appel de Note', '64', '', 'display', '', '4', '', '32', '1', '2007-10-05 16:52:02'),
('78', 'datepublicationoeuvre', '17', 'textes', 'Date de publication de l\'oeuvre commentée', '', 'datepublioeuvre', 'tinytext', '', '*', '', '', '', '64', '', 'display', '', '4', '', '32', '70', '2007-10-05 16:52:13'),
('79', 'auteuroeuvre', '17', 'textes', 'Auteur de l\'oeuvre commentée', '', '', 'persons', '', '', '', '', '', '64', '', 'editable', '', '0', '', '32', '71', '2007-11-23 11:03:26'),
('81', 'titre', '18', 'textessimples', 'Titre', '', '', 'tinytext', 'dc.title', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '16', '', 'editable', '', '4', '', '32', '72', '2006-06-27 23:50:07'),
('82', 'texte', '19', 'textessimples', 'Texte', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '16', '', 'fckeditor', 'Simple', '4', '', '1', '73', '2006-11-09 10:24:32'),
('83', 'ndla', '4', 'textes', 'Note de l\'auteur', '', 'ndla', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '64', '', 'importable', '', '2', '', '32', '2', '2006-03-08 17:48:24'),
('96', 'icone', '12', 'publications', 'Icône de la publication', '', '', 'image', '', '*', '', '', '', '16', '', 'none', '', '0', '', '32', '1', '2007-10-11 12:03:48'),
('97', 'icone', '3', 'textes', 'Icône du document', '', '', 'image', '', '*', '', '', '', '64', '', 'none', '', '0', '', '32', '88', '2007-10-11 12:04:21'),
('98', 'description', '8', 'fichiers', 'Description', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '16', '', 'fckeditor', 'Simple', '4', '', '32', '2', '2006-07-10 16:35:55'),
('99', 'alterfichier', '2', 'textes', 'Texte au format PDF', '', '', 'file', '', '*', '', '', '', '32', '', 'editable', '', '0', '', '32', '6', '2006-07-13 11:52:01'),
('104', 'langue', '12', 'publications', 'Langue de la publication', '', '', 'lang', 'dc.language', '*', 'fr', '', '', '64', '', 'editable', '', '0', '', '32', '8', '2006-03-06 11:52:49'),
('100', 'auteur', '24', 'fichiers', 'Auteur', '', '', 'persons', '', '', '', '', '', '64', '', 'editable', '', '0', '', '32', '91', '2006-03-07 17:09:58'),
('101', 'auteur', '25', 'liens', 'Auteur de la notice décrivant ce site', '', '', 'persons', '', '', '', '', '', '64', '', 'editable', '', '0', '', '32', '92', '2005-06-16 12:01:32'),
('102', 'capturedecran', '6', 'liens', 'Capture d\'écran du site', '', '', 'image', '', '*', '', '', '', '16', '', 'editable', '', '0', '', '32', '3', '2006-06-22 17:57:46'),
('103', 'auteur', '26', 'textessimples', 'Auteur', '', '', 'persons', '', '', '', '', '', '64', '', 'editable', '', '0', '', '32', '93', '2006-02-21 23:58:53'),
('105', 'numerodocument', '1', 'textes', 'Numéro du document', '', 'numerodocument,numrodudocument', 'number', '', '*', '', '', '', '64', '', 'editable', '', '0', '', '32', '1', '2006-12-05 16:09:34'),
('112', 'nom', '28', 'individus', 'Nom', '', '', 'tinytext', 'dc.title', '*', '', '', '', '16', '', 'editable', '', '4', '', '1', '1', '2006-06-22 18:00:21'),
('113', 'prenom', '28', 'individus', 'Prénom', '', '', 'tinytext', '', '*', '', '', '', '16', '', 'editable', '', '4', '', '1', '2', '2006-06-22 18:00:32'),
('122', 'accroche', '28', 'individus', 'Accroche', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '16', '', 'fckeditor', 'Simple', '4', '', '1', '3', '2006-07-10 16:34:23'),
('123', 'adresse', '30', 'individus', 'Adresse', '', '', 'text', '', '*', '', '', '', '16', '', 'editable', '3', '4', '', '1', '102', '2006-07-10 16:35:02'),
('124', 'telephone', '30', 'individus', 'Téléphone', '', '', 'tinytext', '', '*', '', '', '', '16', '', 'editable', '', '4', '', '1', '103', '2006-07-10 16:35:10'),
('125', 'photographie', '28', 'individus', 'Photographie', '', '', 'image', '', '*', '', '', '', '16', '', 'editable', '', '0', '', '1', '104', '2006-06-22 18:00:58'),
('141', 'vignette', '8', 'fichiers', 'Vignette', '', '', 'image', '', '*', '', '', '', '16', '', 'editable', '', '0', '', '32', '3', '2006-06-22 22:53:54'),
('127', 'directeurdelapublication', '12', 'publications', 'Directeur de la publication', '', '', 'persons', '', '', '', '', '', '64', '', 'editable', '', '0', '', '1', '10', '2006-03-06 11:52:49'),
('128', 'legende', '8', 'fichiers', 'Légende', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', '16', '', 'fckeditor', 'Basic', '4', '', '1', '4', '2007-10-18 17:12:43'),
('129', 'credits', '24', 'fichiers', 'Crédits', '', '', 'tinytext', '', '*', '', '', '', '16', '', 'editable', '', '4', '', '1', '108', '2006-06-22 22:54:27'),
('133', 'theme', '15', 'textes', 'Index thématique', '', '', 'entries', '', '', '', '', '', '64', '', 'editable', '', '0', '', '1', '112', '2006-03-02 02:00:43'),
('139', 'licence', '12', 'publications', 'Licence portant sur la publication', '', '', 'entries', '', '', '', '', '', '64', '', 'editable', '', '0', '', '1', '9', '2006-03-06 11:52:49'),
('134', 'nom', '0', 'indexavances', 'Dénomination de l\'entrée d\'index', '', '', 'tinytext', 'index key', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block', '16', '', 'editable', '', '4', '', '1', '113', '2006-07-10 17:19:09'),
('135', 'description', '0', 'indexavances', 'Description de l\'entrée d\'index', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '16', '', 'fckeditor', 'Basic', '4', '', '1', '114', '2006-07-10 17:17:29'),
('136', 'url', '0', 'indexavances', 'URL', '', '', 'url', '', '*', '', '', '', '16', '', 'editable', '', '0', '', '1', '115', '2006-07-10 17:17:43'),
('137', 'icone', '0', 'indexavances', 'Icône', '', '', 'image', '', '*', '', '', '', '16', '', 'editable', '', '0', '', '1', '116', '2006-07-10 17:17:52'),
('138', 'licence', '3', 'textes', 'Licence portant sur le document', '', '', 'entries', '', '', '', '', '', '64', '', 'editable', '', '0', '', '1', '117', '2006-03-06 11:37:12'),
('143', 'notefin', '2', 'textes', 'Notes de fin de document', '', 'notefin', 'longtext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', '32', '', 'importable', '', '4', '', '32', '3', '2007-12-13 12:18:54'),
('144', 'altertitre', '10', 'publications', 'Titre alternatif de la publication (dans une autre langue)', '', 'titretraduitfr:fr,titretraduiten:en,titretraduites:es,titretraduitpt:pt,titretraduitit:it,titretraduitde:de,titretraduitru:ru,titleen:en', 'mltext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Appel de Note', '32', '', 'editable', '', '4', '', '1', '120', '2006-12-05 16:38:54'),
('147', 'motscleses', '15', 'textes', 'Palabras claves', '', '', 'entries', '', '', '', '', '', '64', '', 'editable', '', '0', '', '1', '121', '2007-09-28 11:43:37'),
('148', 'motsclesde', '15', 'textes', 'Schlagwortindex', '', '', 'entries', '', '', '', '', '', '64', '', 'editable', '', '0', '', '1', '122', '2008-01-28 10:01:28'),
('149', 'urlpublicationediteur', '13', 'publications', 'Voir sur le site de l\'éditeur', '', '', 'url', '', '*', '', '', '', '32', '', 'editable', '', '0', '', '1', '123', '2007-10-11 11:00:55'),
('150', 'nombremaxitems', '6', 'liens', 'Nombre maximum d\'items du flux', '', '', 'int', '', '*', '', '', '', '16', '', 'editable', '', '0', '', '32', '124', '2007-10-11 11:14:13'),
('151', 'descriptionouvrage', '12', 'publications', 'Description physique de l\'ouvrage', '', '', 'text', '', '*', '', '', '', '64', '', 'editable', '', '0', '', '32', '125', '2007-10-18 17:05:20'),
('152', 'site', '0', 'entities_auteurs', 'Site', '', 'site, .site', 'url', '', '*', '', '', '', '32', '', 'editable', '', '4', '', '1', '6', '2007-11-23 10:24:41');

#
# Dumping data for table 'tablefieldgroups'
#

INSERT INTO #_TP_tablefieldgroups (id, name, class, title, altertitle, comment, status, rank, upd) VALUES ('1', 'grtitre', 'textes', 'Titres', '', '', '1', '1', '2006-03-01 19:12:59'),
('2', 'grtexte', 'textes', 'Texte', '', '', '1', '3', '2006-03-01 19:13:36'),
('3', 'grmeta', 'textes', 'Métadonnées', '', '', '1', '4', '2006-03-01 19:15:52'),
('4', 'graddenda', 'textes', 'Addenda', '', '', '1', '5', '2006-03-01 19:16:00'),
('5', 'grtitre', 'liens', 'Titre', '', '', '1', '5', '2006-02-21 22:33:20'),
('6', 'grsite', 'liens', 'Définition du site', '', '', '1', '6', '2006-02-21 22:40:34'),
('7', 'grtitre', 'fichiers', 'Titre', '', '', '1', '7', '2006-03-07 17:09:58'),
('8', 'grmultimedia', 'fichiers', 'Définition', '', '', '1', '8', '2006-03-07 17:09:58'),
('9', 'grresumes', 'textes', 'Résumés', '', '', '1', '2', '2006-03-01 19:12:46'),
('10', 'grtitre', 'publications', 'Groupe de titre', '', '', '32', '1', '2005-06-16 11:50:10'),
('11', 'grgestion', 'publications', 'Gestion des publications', '', '', '1', '4', '2006-02-27 22:47:22'),
('12', 'grmetadonnees', 'publications', 'Groupe des métadonnées', '', '', '32', '3', '2006-02-27 22:47:22'),
('13', 'graddenda', 'publications', 'Groupe des addenda', '', '', '32', '2', '2006-02-27 22:47:17'),
('14', 'grpersonnes', 'textes', 'Auteurs', '', '', '1', '7', '2006-03-01 19:16:28'),
('15', 'grindex', 'textes', 'Index', '', '', '1', '6', '2006-03-01 19:16:09'),
('16', 'grgestion', 'textes', 'Gestion du document', '', '', '1', '9', '2006-03-01 19:16:42'),
('17', 'grrecension', 'textes', 'Oeuvre commentée (si ce document est un compte-rendu d\'oeuvre ou d\'ouvrage...)', '', '', '1', '8', '2005-06-19 16:00:22'),
('18', 'grtitre', 'textessimples', 'Titre', '', '', '1', '10', '2006-02-21 23:58:18'),
('19', 'grtexte', 'textessimples', 'Texte', '', '', '1', '11', '2006-02-21 23:58:18'),
('24', 'grdroits', 'fichiers', 'Droits', '', '', '32', '16', '2006-03-07 17:09:58'),
('25', 'grauteurs', 'liens', 'Auteurs', '', '', '32', '17', '2006-02-21 22:33:36'),
('26', 'grauteurs', 'textessimples', 'Auteurs', '', '', '32', '18', '2006-02-21 23:58:18'),
('28', 'grtitre', 'individus', 'Titre', '', '', '1', '20', '2006-02-22 09:54:12'),
('30', 'grdescription', 'individus', 'Description', '', '', '1', '21', '2006-02-22 09:54:12');

#
# Dumping data for table 'types'
#

INSERT INTO #_TP_types (id, icon, type, title, altertitle, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, public, gui_user_complexity, oaireferenced, rank, status, upd) VALUES ('1', '', 'editorial', 'Editorial', '', 'textes', 'article', 'entities', '', '1', '', '-1', '1', '0', '32', '1', '1', '32', '2006-09-28 11:40:39'),
('2', '', 'article', 'Article', '', 'textes', 'article', 'entities', '', '1', '', '-1', '1', '0', '16', '1', '2', '1', '2006-09-28 11:40:39'),
('3', '', 'actualite', 'Annonce et actualité', '', 'textes', 'article', 'entities', '', '1', '', '-1', '1', '0', '32', '0', '3', '32', '2006-09-28 11:40:39'),
('4', '', 'compterendu', 'Compte-rendu', '', 'textes', 'article', 'entities', '', '1', '', '-1', '1', '0', '32', '1', '5', '32', '2008-04-01 19:26:18'),
('5', '', 'notedelecture', 'Note de lecture', '', 'textes', 'article', 'entities', '', '1', '', '-1', '1', '0', '64', '1', '6', '32', '2008-04-01 19:26:32'),
('6', '', 'informations', 'Informations pratiques', '', 'textes', 'article', 'entities', '', '1', '', '-1', '1', '0', '32', '0', '7', '32', '2006-09-28 11:40:39'),
('7', '', 'chronique', 'Chronique', '', 'textes', 'article', 'entities', '', '1', '', '-1', '1', '0', '64', '0', '8', '32', '2006-09-28 11:40:39'),
('8', '', 'collection', 'Collection', '', 'publications', 'sommaire', 'entities', 'edition', '0', '', '-1', '1', '0', '16', '0', '1', '32', '2006-09-28 11:40:39'),
('9', 'lodel/icons/volume.gif', 'numero', 'Numéro de revue', '', 'publications', 'sommaire', 'entities', 'edition', '0', '', '-1', '1', '0', '32', '0', '3', '32', '2006-09-28 11:40:39'),
('10', 'lodel/icons/rubrique.gif', 'rubrique', 'Rubrique', '', 'publications', 'sommaire', 'entities', 'edition', '0', '', '-1', '1', '0', '16', '0', '5', '32', '2006-09-28 11:40:39'),
('11', 'lodel/icons/rubrique_plat.gif', 'souspartie', 'Sous-partie', '', 'publications', '', 'entities', 'edition', '0', 'unfolded', '-1', '1', '0', '16', '0', '6', '32', '2008-01-10 17:16:55'),
('12', '', 'image', 'Image', '', 'fichiers', 'image', 'entities', '', '0', '', '-1', '1', '0', '64', '1', '1', '1', '2006-09-28 11:40:39'),
('13', '', 'noticedesite', 'Notice de site', '', 'liens', 'lien', 'entities', '', '0', '', '-1', '1', '0', '64', '0', '16', '1', '2006-09-28 11:40:39'),
('14', 'lodel/icons/commentaire.gif', 'commentaire', 'Commentaire du document', '', 'textessimples', '', 'entities', '', '0', 'advanced', '-1', '1', '1', '16', '0', '2', '1', '2006-11-08 08:12:28'),
('25', '', 'videoannexe', 'Vidéo placée en annexe', '', 'fichiers', '', 'entities', 'edition', '0', 'advanced', '-1', '1', '0', '64', '0', '4', '1', '2006-09-28 11:40:39'),
('20', '', 'annuairedequipe', 'Équipe', '', 'publications', 'sommaire', 'entities', 'edition', '0', '', '-1', '1', '0', '16', '0', '8', '32', '2008-01-28 10:16:32'),
('21', '', 'annuairemedias', 'Médiathèque', '', 'publications', 'sommaire', 'entities', 'edition', '0', '', '-1', '1', '0', '16', '0', '9', '32', '2006-09-28 11:40:39'),
('15', '', 'image_annexe', 'Image placée en annexe', '', 'fichiers', '', 'entities', '', '0', 'advanced', '-1', '1', '0', '64', '0', '2', '1', '2006-09-28 11:40:39'),
('16', '', 'lienannexe', 'Lien placé en annexe', '', 'liens', 'lien', 'entities', '', '0', 'advanced', '-1', '1', '0', '64', '0', '24', '1', '2006-09-28 11:40:39'),
('17', '', 'individu', 'Notice biographique de membre', '', 'individus', 'individu', 'entities', '', '0', '', '-1', '1', '0', '16', '0', '25', '1', '2007-10-04 10:23:21'),
('18', '', 'billet', 'Billet', '', 'textessimples', 'article', 'entities', '', '0', '', '-1', '1', '0', '16', '0', '1', '1', '2006-11-09 03:52:00'),
('19', '', 'annuairedesites', 'Annuaire de sites', '', 'publications', 'sommaire', 'entities', 'edition', '0', '', '-1', '1', '0', '16', '0', '7', '32', '2006-09-28 11:40:39'),
('22', 'lodel/icons/rss.gif', 'fluxdesyndication', 'Flux de syndication', '', 'liens', 'lien', 'entities', '', '0', '', '-1', '1', '0', '64', '0', '30', '1', '2006-09-28 11:40:39'),
('23', '', 'video', 'Vidéo', '', 'fichiers', '', 'entities', '', '0', '', '-1', '1', '0', '64', '0', '3', '1', '2006-09-28 11:40:39'),
('24', '', 'son', 'Document sonore', '', 'fichiers', '', 'entities', '', '0', '', '-1', '1', '0', '32', '0', '5', '1', '2006-09-28 11:40:39'),
('26', '', 'fichierannexe', 'Fichier placé en annexe', '', 'fichiers', 'image', 'entities', '', '0', 'advanced', '-1', '1', '0', '32', '0', '7', '1', '2006-09-28 11:40:39'),
('27', '', 'sonannexe', 'Document sonore placé en annexe', '', 'fichiers', '', 'entities', '', '0', 'advanced', '-1', '1', '0', '32', '0', '6', '1', '2006-09-28 11:40:39'),
('326', '', 'imageaccroche', 'Image d\'accroche', '', 'fichiers', 'image', 'entities', '', '0', 'advanced', '-1', '1', '0', '16', '0', '31', '32', '2007-10-11 10:48:28'),
('327', 'lodel/icons/rubrique.gif', 'rubriqueannuaire', 'Rubrique (d\'annuaire de site)', '', 'publications', 'sommaire', 'entities', 'edition', '0', '', '-1', '1', '0', '16', '0', '32', '32', '2007-10-11 11:58:32'),
('328', '', 'rubriquemediatheque', 'Rubrique (de médiathèque)', '', 'publications', 'sommaire', 'entities', 'edition', '0', '', '-1', '1', '0', '16', '0', '33', '32', '2007-10-11 12:02:26'),
('329', 'lodel/icons/rubrique.gif', 'rubriqueequipe', 'Rubrique (d\'équipe)', '', 'publications', 'sommaire', 'entities', 'edition', '0', 'unfolded', '-1', '1', '0', '16', '0', '34', '32', '2007-10-11 12:00:43'),
('81', 'lodel/icons/rubrique.gif', 'rubriqueactualites', 'Rubrique (d\'actualités)', '', 'publications', 'sommaire', 'entities', 'edition', '0', '', '-1', '1', '0', '16', '0', '35', '32', '2007-10-18 17:26:45');

#
# Dumping data for table 'persontypes'
#

INSERT INTO #_TP_persontypes (id, icon, type, title, altertitle, class, style, g_type, tpl, tplindex, gui_user_complexity, rank, status, upd) VALUES ('28', 'lodel/icons/auteur.gif', 'auteur', 'Auteur', '', 'auteurs', 'auteur', 'dc.creator', 'personne', 'personnes', '32', '1', '1', '2006-12-18 11:36:47'),
('29', '', 'traducteur', 'Traducteur', '', 'auteurs', 'traducteur', 'dc.contributor', 'personne', 'personnes', '64', '2', '1', '2006-09-28 11:40:39'),
('30', '', 'directeurdelapublication', 'Directeur de la publication', '', 'auteurs', 'directeur', '', 'personne', 'personnes', '32', '3', '32', '2006-12-18 11:37:03'),
('31', '', 'auteuroeuvre', 'Auteur d\'une oeuvre commentée', '', 'auteurs', 'auteuroeuvre', '', 'personne', 'personnes', '64', '4', '32', '2006-09-28 11:40:39'),
('32', '', 'editeurscientifique', 'Éditeur scientifique', '', 'auteurs', 'editeurscientifique', '', 'personne', 'personnes', '64', '5', '1', '2008-01-28 10:21:10');

#
# Dumping data for table 'entrytypes'
#

INSERT INTO #_TP_entrytypes (id, icon, type, class, title, altertitle, style, g_type, tpl, tplindex, gui_user_complexity, rank, status, flat, newbyimportallowed, edition, sort, upd, lang) VALUES ('33', '', 'motsclesfr', 'indexes', 'Index de mots-clés', '', 'motscles, .motcles,motscls,motsclesfr', 'dc.subject', 'entree', 'entrees', '32', '1', '1', '1', '1', 'pool', 'sortkey', '2008-01-23 12:06:56', 'fr'),
('34', '', 'motsclesen', 'indexes', 'Index by keyword', '', 'keywords,motclesen', '', 'entree', 'entrees', '64', '2', '1', '1', '1', 'pool', 'sortkey', '2006-12-18 13:01:00', 'fr'),
('36', '', 'chrono', 'indexes', 'Index chronologique', '', 'periode, .periode, priode', '', 'entree', 'entrees', '64', '5', '1', '0', '1', 'pool', 'sortkey', '2006-09-28 11:40:39', 'fr'),
('37', '', 'theme', 'indexes', 'Index thématique', '', 'themes,thmes,.themes', '', 'entree', 'entrees', '16', '6', '1', '0', '1', 'pool', 'sortkey', '2006-09-28 11:40:39', 'fr'),
('35', '', 'geographie', 'indexes', 'Index géographique', '', 'geographie, gographie,.geographie', '', 'entree', 'entrees', '64', '4', '1', '0', '1', 'pool', 'sortkey', '2006-09-28 11:40:39', 'fr'),
('313', '', 'motscleses', 'indexes', 'Indice de palabras clave', '', 'palabrasclaves, .palabrasclaves, motscleses', '', 'entree', 'entrees', '64', '9', '1', '1', '1', 'pool', 'sortkey', '2007-12-10 16:03:52', 'fr'),
('38', '', 'licence', 'indexavances', 'Licence portant sur le document', '', 'licence, droitsauteur', 'dc.rights', 'entree', 'entrees', '16', '7', '1', '1', '1', 'select', 'rank', '2007-11-23 10:21:38', 'fr'),
('312', '', 'motsclesde', 'indexes', 'Schlagwortindex', '', 'schlusselworter, .schlusselworter, motsclesde, schlagworter, .schlagworter', '', 'entree', 'entrees', '32', '8', '1', '1', '1', 'pool', 'sortkey', '2008-01-28 10:01:28', 'fr');

#
# Dumping data for table 'entitytypes_entitytypes'
#

INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('8', '0', '*'),
('11', '11', '*'),
('11', '9', '*'),
('1', '10', '*'),
('2', '327', '*'),
('2', '10', '*'),
('3', '328', '*'),
('20', '8', '*'),
('3', '11', '*'),
('3', '327', '*'),
('3', '81', '*'),
('3', '10', '*'),
('21', '10', '*'),
('4', '11', '*'),
('4', '328', '*'),
('4', '327', '*'),
('5', '11', '*'),
('6', '8', '*'),
('6', '21', '*'),
('6', '19', '*'),
('6', '20', '*'),
('7', '9', '*'),
('7', '8', '*'),
('7', '21', '*'),
('7', '19', '*'),
('26', '6', '*'),
('14', '5', '*'),
('13', '11', '*'),
('13', '327', '*'),
('13', '10', '*'),
('20', '0', '*'),
('14', '6', '*'),
('14', '1', '*'),
('14', '4', '*'),
('14', '7', '*'),
('26', '1', '*'),
('1', '9', '*'),
('9', '8', '*'),
('1', '8', '*'),
('1', '21', '*'),
('2', '9', '*'),
('14', '2', '*'),
('14', '3', '*'),
('14', '13', '*'),
('12', '11', '*'),
('12', '10', '*'),
('19', '10', '*'),
('19', '8', '*'),
('14', '12', '*'),
('26', '4', '*'),
('25', '18', '*'),
('25', '6', '*'),
('25', '5', '*'),
('25', '1', '*'),
('25', '4', '*'),
('25', '7', '*'),
('25', '2', '*'),
('25', '3', '*'),
('2', '8', '*'),
('5', '328', '*'),
('19', '0', '*'),
('12', '9', '*'),
('13', '9', '*'),
('15', '5', '*'),
('15', '6', '*'),
('15', '1', '*'),
('15', '4', '*'),
('15', '7', '*'),
('15', '2', '*'),
('15', '3', '*'),
('16', '6', '*'),
('16', '1', '*'),
('16', '4', '*'),
('16', '7', '*'),
('16', '2', '*'),
('16', '3', '*'),
('16', '11', '*'),
('21', '8', '*'),
('18', '328', '*'),
('21', '0', '*'),
('22', '11', '*'),
('22', '327', '*'),
('22', '10', '*'),
('22', '9', '*'),
('22', '8', '*'),
('17', '10', '*'),
('23', '11', '*'),
('23', '10', '*'),
('24', '11', '*'),
('24', '10', '*'),
('24', '9', '*'),
('26', '7', '*'),
('26', '2', '*'),
('26', '3', '*'),
('26', '10', '*'),
('26', '9', '*'),
('27', '18', '*'),
('27', '5', '*'),
('27', '6', '*'),
('27', '1', '*'),
('27', '4', '*'),
('27', '7', '*'),
('27', '2', '*'),
('27', '3', '*'),
('17', '20', '*'),
('22', '328', '*'),
('13', '328', '*'),
('24', '328', '*'),
('10', '10', '*'),
('10', '8', '*'),
('18', '327', '*'),
('23', '9', '*'),
('23', '21', '*'),
('24', '21', '*'),
('12', '8', '*'),
('12', '21', '*'),
('18', '10', '*'),
('18', '9', '*'),
('13', '8', '*'),
('13', '21', '*'),
('22', '21', '*'),
('22', '19', '*'),
('18', '8', '*'),
('18', '21', '*'),
('18', '19', '*'),
('4', '10', '*'),
('5', '327', '*'),
('16', '10', '*'),
('16', '9', '*'),
('26', '5', '*'),
('26', '18', '*'),
('326', '6', '*'),
('326', '1', '*'),
('326', '4', '*'),
('326', '7', '*'),
('326', '2', '*'),
('326', '3', '*'),
('326', '328', '*'),
('326', '329', '*'),
('326', '11', '*'),
('326', '327', '*'),
('326', '10', '*'),
('326', '9', '*'),
('326', '8', '*'),
('326', '21', '*'),
('326', '19', '*'),
('326', '20', '*'),
('326', '13', '*'),
('326', '22', '*'),
('22', '20', '*'),
('327', '19', '*'),
('327', '327', '*'),
('328', '328', '*'),
('328', '21', '*'),
('329', '20', '*'),
('329', '329', '*'),
('13', '19', '*'),
('22', '0', '*'),
('1', '19', '*'),
('2', '21', '*'),
('2', '19', '*'),
('3', '9', '*'),
('3', '8', '*'),
('3', '21', '*'),
('3', '19', '*'),
('1', '327', '*'),
('1', '11', '*'),
('1', '328', '*'),
('2', '11', '*'),
('2', '328', '*'),
('4', '9', '*'),
('4', '8', '*'),
('4', '21', '*'),
('4', '19', '*'),
('5', '10', '*'),
('5', '9', '*'),
('5', '8', '*'),
('5', '21', '*'),
('5', '19', '*'),
('7', '10', '*'),
('7', '327', '*'),
('7', '11', '*'),
('7', '328', '*'),
('12', '328', '*'),
('23', '328', '*'),
('18', '20', '*'),
('18', '0', '*'),
('17', '329', '*'),
('326', '5', '*'),
('326', '18', '*'),
('326', '14', '*'),
('81', '8', '*'),
('18', '11', '*'),
('16', '5', '*');

#
# Dumping data for table 'characterstyles'
#


#
# Dumping data for table 'internalstyles'
#

INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('1', 'citation', '*-', '<blockquote>', '0', '1', '1', '2005-09-01 15:12:36'),
('2', 'quotations', '*-', '<blockquote>', '0', '2', '1', '2005-09-01 15:12:41'),
('3', 'citationbis', '*-', '<blockquote class="citationbis">', '0', '3', '1', '2005-03-10 18:49:50'),
('4', 'citationter', '*-', '<blockquote class="citationter">', '0', '4', '1', '2005-03-10 18:50:12'),
('5', 'titreillustration', '*-', '', '0', '5', '1', '2005-03-10 18:51:50'),
('6', 'legendeillustration', '*-', '', '0', '6', '1', '2005-03-10 18:52:07'),
('7', 'titredoc', '*-', '', '0', '7', '1', '2005-03-10 18:52:25'),
('8', 'legendedoc', '*-', '', '0', '8', '1', '2005-03-10 18:52:34'),
('9', 'puces', '*-', '<ul><li>', '0', '9', '1', '2005-03-10 18:53:04'),
('10', 'code', '*-', '', '0', '10', '1', '2005-03-10 18:53:41'),
('11', 'question', '*-', '', '0', '11', '1', '2005-03-10 18:54:17'),
('12', 'reponse', '*-', '', '0', '12', '1', '2005-04-29 17:12:51'),
('20', 'separateur', '*-', '<hr style="style">', '0', '19', '1', '2005-09-01 15:13:07'),
('19', 'section1', '-*', '<h1>', '0', '13', '1', '2006-03-02 09:51:26'),
('15', 'section3', '*-', '<h3>', '0', '15', '1', '2005-04-29 17:13:02'),
('16', 'section4', '*-', '<h4>', '0', '16', '1', '2005-04-29 17:13:00'),
('17', 'section5', '*-', '<h5>', '0', '17', '1', '2005-04-29 17:12:42'),
('18', 'section6', '*-', '<h6>', '0', '18', '1', '2005-04-29 17:12:37'),
('21', 'paragraphesansretrait', '*-', '', '0', '20', '1', '2005-05-24 22:24:39'),
('22', 'epigraphe', '*-', '', '0', '21', '1', '2005-05-24 22:24:28'),
('23', 'section2', '-*', '<h2>', '0', '14', '1', '2006-03-02 09:51:32'),
('24', 'pigraphe', '-*', '', '0', '22', '1', '2005-05-24 22:24:50'),
('25', 'sparateur', '-*', '', '0', '23', '1', '2005-05-24 22:25:07'),
('26', 'quotation', '-*', '<blockquote>', '0', '24', '1', '2005-09-01 15:12:53'),
('27', 'terme', '-*', '', '0', '25', '1', '2006-03-02 09:52:27'),
('28', 'definitiondeterme', '-*', '', '0', '26', '1', '2006-03-02 09:52:37'),
('29', 'bibliographieannee', '-*', '', '0', '27', '1', '2006-03-05 14:50:25'),
('30', 'bibliographieauteur', 'bibliographie', '', '0', '28', '1', '2006-03-02 09:55:15'),
('31', 'bibliographiereference', 'bibliographie', '', '0', '29', '1', '2006-03-02 09:55:37'),
('32', 'creditillustration,crditillustration,creditsillustration,crditsillustration', '-*', '', '0', '30', '1', '2006-12-05 16:36:15'),
('33', 'remerciements', '-*', '', '0', '31', '1', '2006-12-05 16:14:33');
DELETE FROM #_TP_optiongroups;
# # Database: ''# 
#
# Dumping data for table 'optiongroups'
#

INSERT INTO #_TP_optiongroups (id, idparent, name, title, altertitle, comment, logic, exportpolicy, rank, status, upd) VALUES ('1', '0', 'servoo', 'Servoo', '', '', 'servooconf', '1', '1', '32', '2006-12-08 09:50:17'),
('2', '0', 'metadonneessite', 'Métadonnées du site', '', '', '', '1', '2', '1', '2005-03-12 11:28:15'),
('5', '0', 'oai', 'OAI', '', '', '', '1', '5', '1', '2006-12-08 09:50:40');
DELETE FROM #_TP_options;
# # Database: ''# 
#
# Dumping data for table 'options'
#

INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status, upd, edition, editionparams) VALUES ('1', '1', 'url', 'url', 'tinytext', '', '', '40', '1', '32', '2007-10-16 15:00:08', 'editable', ''),
('2', '1', 'username', 'username', 'username', '', '', '40', '2', '32', '2007-10-16 14:51:20', 'editable', ''),
('3', '1', 'passwd', 'password', 'passwd', '', '', '40', '3', '32', '2007-10-16 15:00:18', '', ''),
('4', '2', 'titresite', 'Titre du site', 'tinytext', 'Titresite', '', '40', '1', '1', '2007-10-18 16:54:56', '', ''),
('5', '2', 'titresiteabrege', 'Titre abrégé du site', 'tinytext', 'Titre abrégé du site', '', '40', '3', '1', '2007-11-13 12:43:18', '', ''),
('6', '2', 'descriptionsite', 'Description du site', 'text', '', '', '40', '4', '1', '2007-11-13 12:43:15', 'textarea', ''),
('7', '2', 'urldusite', 'URL officielle du site', 'url', '', '', '40', '5', '1', '2007-11-13 12:43:13', 'editable', ''),
('9', '2', 'issn', 'ISSN', 'tinytext', '', '', '30', '6', '1', '2007-11-13 12:43:12', 'editable', ''),
('10', '2', 'editeur', 'Nom de l\'éditeur du site', 'tinytext', '', '', '30', '8', '1', '2007-11-13 12:43:07', '', ''),
('11', '2', 'adresseediteur', 'Adresse postale de l\'éditeur', 'text', '', '', '30', '9', '1', '2007-11-13 12:43:04', '', ''),
('12', '2', 'producteursite', 'Nom du producteur du site', 'tinytext', '', '', '30', '10', '1', '2007-11-13 12:43:01', '', ''),
('13', '2', 'diffuseursite', 'Nom du diffuseur du site', 'tinytext', '', '', '30', '11', '1', '2007-11-13 12:42:54', '', ''),
('14', '2', 'droitsauteur', 'Droits d\'auteur par défaut', 'tinytext', '', '', '30', '12', '1', '2007-11-13 12:42:48', '', ''),
('15', '2', 'directeurpublication', 'Nom du directeur de la publication', 'tinytext', '', '', '30', '13', '1', '2007-11-13 12:42:45', '', ''),
('16', '2', 'redacteurenchef', 'Nom du Rédacteur en chef', 'tinytext', '', '', '30', '14', '1', '2007-11-13 12:42:40', '', ''),
('17', '2', 'courrielwebmaster', 'Courriel du webmaster', 'email', '', '', '30', '15', '1', '2007-11-13 12:42:36', '', ''),
('18', '2', 'courrielabuse', 'Courriel abuse', 'tinytext', '', '', '40', '16', '1', '2007-11-13 12:42:30', 'editable', ''),
('19', '2', 'motsclesdusite', 'Mots clés décrivant le site (entre virgules)', 'text', '', '', '30', '17', '1', '2007-11-13 12:42:26', '', ''),
('23', '5', 'oai_allow', 'oai_allow', 'tinytext', '*', '', '40', '23', '1', '2006-07-13 15:29:01', 'editable', ''),
('24', '5', 'oai_deny', 'oai_deny', 'tinytext', '', '', '40', '24', '1', '2006-07-13 15:29:35', 'editable', ''),
('25', '5', 'oai_email', 'Email de l\'administrateur du dépôt', 'email', '', '', '40', '25', '32', '2006-12-08 10:02:06', 'editable', ''),
('26', '2', 'issn_electronique', 'ISSN électronique', 'tinytext', '', '', '30', '7', '32', '2008-01-10 15:37:09', 'editable', ''),
('27', '2', 'langueprincipale', 'Langue principale du site', 'lang', 'fr', '', '40', '18', '1', '2007-11-13 12:42:22', 'editable', ''),
('28', '2', 'soustitresite', 'Sous titre du site', 'tinytext', '', '', '40', '2', '1', '2007-11-13 12:43:18', 'editable', '');
# # Database: ''# 
# --------------------------------------------------------

#
# Table structure for table 'textes'
#

DROP TABLE IF EXISTS #_TP_textes;
CREATE TABLE #_TP_textes (
  identity int(10) unsigned default NULL,
  titre text,
  surtitre text,
  soustitre text,
  texte longtext,
  notesbaspage longtext,
  annexe text,
  bibliographie text,
  datepubli date default NULL,
  datepublipapier date default NULL,
  noticebiblio text,
  pagination tinytext,
  langue char(5) default NULL,
  prioritaire tinyint(4) default NULL,
  addendum text,
  ndlr text,
  commentaireinterne text,
  dedicace text,
  ocr tinyint(4) default NULL,
  documentcliquable tinyint(4) default NULL,
  `resume` text,
  altertitre text,
  titreoeuvre text,
  noticebibliooeuvre text,
  datepublicationoeuvre tinytext,
  ndla text,
  icone tinytext,
  alterfichier tinytext,
  numerodocument double default NULL,
  notefin longtext,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'publications'
#

DROP TABLE IF EXISTS #_TP_publications;
CREATE TABLE #_TP_publications (
  identity int(10) unsigned default NULL,
  titre text,
  surtitre text,
  soustitre text,
  commentaireinterne text,
  prioritaire tinyint(4) default NULL,
  datepubli date default NULL,
  datepublipapier date default NULL,
  noticebiblio text,
  introduction text,
  ndlr text,
  historique text,
  periode tinytext,
  isbn tinytext,
  paraitre tinyint(4) default NULL,
  integralite tinyint(4) default NULL,
  numero tinytext,
  icone tinytext,
  langue varchar(5) default NULL,
  altertitre text,
  urlpublicationediteur text,
  descriptionouvrage text,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'fichiers'
#

DROP TABLE IF EXISTS #_TP_fichiers;
CREATE TABLE #_TP_fichiers (
  identity int(10) unsigned default NULL,
  titre text,
  document tinytext,
  description text,
  legende text,
  credits tinytext,
  vignette tinytext,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'liens'
#

DROP TABLE IF EXISTS #_TP_liens;
CREATE TABLE #_TP_liens (
  identity int(10) unsigned default NULL,
  titre text,
  url text,
  urlfil text,
  texte text,
  capturedecran tinytext,
  nombremaxitems int(11) default NULL,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'textessimples'
#

DROP TABLE IF EXISTS #_TP_textessimples;
CREATE TABLE #_TP_textessimples (
  identity int(10) unsigned default NULL,
  titre tinytext,
  texte text,
  url text,
  `date` datetime default NULL,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'auteurs'
#

DROP TABLE IF EXISTS #_TP_auteurs;
CREATE TABLE #_TP_auteurs (
  idperson int(10) unsigned default NULL,
  nomfamille tinytext,
  prenom tinytext,
  UNIQUE KEY idperson (idperson),
  KEY index_idperson (idperson)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'entities_auteurs'
#

DROP TABLE IF EXISTS #_TP_entities_auteurs;
CREATE TABLE #_TP_entities_auteurs (
  idrelation int(10) unsigned default NULL,
  prefix tinytext,
  affiliation tinytext,
  fonction tinytext,
  description text,
  courriel text,
  role text,
  site text,
  UNIQUE KEY idrelation (idrelation),
  KEY index_idrelation (idrelation)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'indexes'
#

DROP TABLE IF EXISTS #_TP_indexes;
CREATE TABLE #_TP_indexes (
  identry int(10) unsigned default NULL,
  nom text,
  definition text,
  UNIQUE KEY identry (identry),
  KEY index_identry (identry)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'individus'
#

DROP TABLE IF EXISTS #_TP_individus;
CREATE TABLE #_TP_individus (
  identity int(10) unsigned default NULL,
  nom tinytext,
  prenom tinytext,
  email text,
  siteweb text,
  description text,
  accroche text,
  adresse text,
  telephone tinytext,
  photographie tinytext,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'indexavances'
#

DROP TABLE IF EXISTS #_TP_indexavances;
CREATE TABLE #_TP_indexavances (
  identry int(10) unsigned default NULL,
  nom tinytext,
  description text,
  url text,
  icone tinytext,
  UNIQUE KEY identry (identry),
  KEY index_identry (identry)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
