# <model>
# <lodelversion>0.8</lodelversion>
# <date>2006-02-28</date>
# <title>
# Modèle éditorial de Revues.org
# </title>
# <description>
# Le modèle éditorial de Revues.org est destiné à la mise en ligne de revues en sciences humaines et sociales. La complexité de ce modèle lui permet de couvrir d'autres besoins, comme la mise en ligne de colloques par exemple. Le modèle distingue notamment le texte, la bibliographie, les annexes, les notes de bas de page (six niveaux différents), les résumés (six langues disponibles pour l'instant). Le modèle repose sur le stylage de documents Word qui sont importés par Lodel. Il faut donc utiliser un modèle de document word. L'ensemble des styles est décrit ici : http://www.lodel.org/document126.html. Ce modèle est compatible avec la version 0.8 de Lodel.
# </description>
# <author>
# Revues.org
# </author>
# <modelversion>
# 1.6
# </modelversion>
# </model>
# 
#------------

DELETE FROM #_TP_classes;
DELETE FROM #_TP_tablefields;
DELETE FROM #_TP_tablefieldgroups;
DELETE FROM #_TP_types;
DELETE FROM #_TP_persontypes;
DELETE FROM #_TP_entrytypes;
DELETE FROM #_TP_entitytypes_entitytypes;
DELETE FROM #_TP_characterstyles;
DELETE FROM #_TP_internalstyles;
# # Database: 'lodeldevelunstable_revorg08'# 
#
# Dumping data for table 'classes'
#

INSERT INTO #_TP_classes (id, class, title, altertitle, classtype, comment, rank, status, upd) VALUES ('35', 'textes', 'Textes', '', 'entities', '', '2', '32', '20060227150155');
INSERT INTO #_TP_classes (id, class, title, altertitle, classtype, comment, rank, status, upd) VALUES ('36', 'publications', 'Publications', '<r2r:ml lang="es">Publicaciones</r2r:ml>', 'entities', '', '1', '32', '20060227150155');
INSERT INTO #_TP_classes (id, class, title, altertitle, classtype, comment, rank, status, upd) VALUES ('37', 'images', 'Images', '', 'entities', '', '5', '32', '20060227150155');
INSERT INTO #_TP_classes (id, class, title, altertitle, classtype, comment, rank, status, upd) VALUES ('38', 'liens', 'Sites', '', 'entities', '', '6', '32', '20060228001615');
INSERT INTO #_TP_classes (id, class, title, altertitle, classtype, comment, rank, status, upd) VALUES ('39', 'textessimples', 'Textes simples', '', 'entities', '', '3', '32', '20060227150155');
INSERT INTO #_TP_classes (id, class, title, altertitle, classtype, comment, rank, status, upd) VALUES ('40', 'auteurs', 'Auteurs', '', 'persons', '', '8', '32', '20060227150155');
INSERT INTO #_TP_classes (id, class, title, altertitle, classtype, comment, rank, status, upd) VALUES ('41', 'indexes', 'Index', '', 'entries', '', '9', '1', '20060227150155');
INSERT INTO #_TP_classes (id, class, title, altertitle, classtype, comment, rank, status, upd) VALUES ('45', 'fichiers_annexes', 'Fichiers annexes', '', 'entities', '', '7', '32', '20060227150155');
INSERT INTO #_TP_classes (id, class, title, altertitle, classtype, comment, rank, status, upd) VALUES ('46', 'individus', 'Personnes', '', 'entities', '', '4', '1', '20060227150155');

#
# Dumping data for table 'tablefields'
#

INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('1', 'titre', '1', 'textes', 'Titre du document', '', 'title, titre, titleuser, heading', 'text', 'dc.title', '+', 'Document sans titre', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Lien;Appel de Note', '', 'editable', '', '64', '8', '', '32', '3', '20051010120229');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('2', 'surtitre', '1', 'textes', 'Surtitre du document', '', 'surtitre', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Lien;Appel de Note', '', 'importable', '', '64', '8', '', '32', '2', '20051010120252');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('3', 'soustitre', '1', 'textes', 'Sous-titre du document', '', 'subtitle', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Lien;Appel de Note', '', 'editable', '', '64', '8', '', '32', '5', '20051010120218');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('4', 'texte', '2', 'textes', 'Texte du document', '', 'texte, standard, normal', 'longtext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'importable', '', '64', '4', '', '32', '4', '20060125145119');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('5', 'notebaspage', '2', 'textes', 'Notes de bas de page', '', 'notebaspage, footnote, footnotetext', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', '', 'importable', '', '64', '4', '', '32', '5', '20050619160022');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('7', 'annexe', '2', 'textes', 'Annexes du document', '', 'annexe', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'importable', '', '64', '4', '', '32', '7', '20050619160022');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('8', 'bibliographie', '2', 'textes', 'Bibliographie du document', '', 'bibliographie', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'importable', '', '64', '4', '', '32', '8', '20050619160022');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('9', 'datepubli', '3', 'textes', 'Date de la publication électronique', '', 'datepubli', 'date', 'dc.date', '*', 'today', '', '', '', 'editable', '', '64', '0', '', '32', '1', '20050619160022');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('10', 'datepublipapier', '3', 'textes', 'Date de la publication sur papier', '', 'datepublipapier', 'date', '', '*', '', '', '', '', 'editable', '', '64', '0', '', '32', '2', '20050619160022');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('11', 'noticebiblio', '3', 'textes', 'Notice bibliographique du document', '', 'noticebiblio', 'tinytext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special', '', 'importable', '', '64', '0', '', '32', '3', '20050619160022');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('12', 'pagination', '3', 'textes', 'Pagination du document sur le papier', '', 'pagination', 'tinytext', '', '*', '', '', '', '', 'editable', '', '64', '0', '', '32', '4', '20050619160022');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('13', 'droitsauteur', '3', 'textes', 'Droits d\'auteur', '', 'droitsauteur', 'tinytext', 'dc.rights', '*', 'Propriété intellectuelle', '', '', '', 'editable', '', '64', '0', '', '1', '5', '20060227231917');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('14', 'langue', '3', 'textes', 'Langue du document', '', 'langue', 'lang', 'dc.language', '*', '', '', '', '', 'editable', '', '64', '0', '', '32', '6', '20050619160022');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('15', 'prioritaire', '16', 'textes', 'Document prioritaire', '', '', 'boolean', '', '*', '', '', '', '', 'editable', '', '64', '0', '', '32', '7', '20050619160022');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('17', 'erratum', '4', 'textes', 'Erratum', '', 'erratum', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'importable', '', '64', '2', '', '32', '1', '20050619160022');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('18', 'ndlr', '4', 'textes', 'Note de la rédaction', '', 'ndlr', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'importable', '', '64', '2', '', '32', '2', '20050619160022');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('19', 'historique', '4', 'textes', 'Historique du document', '', 'historique', 'history', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', '', 'textarea', '20', '64', '0', '', '32', '3', '20050922124139');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('20', 'commentaireinterne', '16', 'textes', 'Commentaire interne sur le document', '', 'commentaire', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', '', 'importable', '', '64', '0', '', '32', '4', '20050619160022');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('21', 'dedicace', '4', 'textes', 'Dédicace', '', 'dedicace', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'importable', '', '64', '2', '', '32', '5', '20050619160022');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('22', 'remerciements', '4', 'textes', 'Remerciements', '', 'remerciements', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'importable', '', '64', '2', '', '32', '22', '20050619160022');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('23', 'ocr', '16', 'textes', 'Document issu d\'une numérisation dite OCR', '', '', 'boolean', '', '*', '', '', '', '', 'importable', '', '64', '0', '', '32', '9', '20050619160022');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('24', 'documentcliquable', '16', 'textes', 'Document cliquable dans les sommaires', '', '', 'boolean', '', '*', 'true', '', '', '', 'editable', '', '64', '0', '', '32', '10', '20050619160022');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('25', 'nom', '0', 'indexes', 'Dénomination de l\'entrée d\'index', '', '', 'text', 'index key', '*', '', '', '', '', 'editable', '', '64', '4', '', '32', '25', '20060223161834');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('26', 'motcle', '15', 'textes', 'Index de mots-clés', '', '', 'entries', '', '', '', '', '', '', 'importable', '', '64', '0', '', '32', '2', '20050619160022');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('27', 'definition', '0', 'indexes', 'Définition', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', '', 'editable', '', '64', '1', '', '32', '27', '20060223161834');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('28', 'nomfamille', '0', 'auteurs', 'Nom de famille', '', '', 'tinytext', 'familyname', '*', '', '', '', '', 'editable', '', '64', '4', '', '32', '28', '20060222095723');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('29', 'prenom', '0', 'auteurs', 'Prénom', '', '', 'tinytext', 'firstname', '*', '', '', '', '', 'editable', '', '64', '4', '', '32', '29', '20060222095723');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('30', 'prefix', '0', 'entities_personnes', 'Préfixe', '', 'prefixe, .prefixe', 'tinytext', '', '*', '', '', '', '', 'editable', '', '64', '0', '', '1', '30', '20050320113011');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('31', 'affiliation', '0', 'entities_personnes', 'Affiliation', '', 'affiliation, .affiliation', 'tinytext', '', '*', '', '', '', '', 'editable', '', '64', '4', '', '1', '31', '20050325172923');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('32', 'fonction', '0', 'entities_personnes', 'Fonction', '', 'fonction, .fonction', 'tinytext', '', '*', '', '', '', '', 'editable', '', '64', '0', '', '1', '32', '20050311173133');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('33', 'description', '0', 'entities_personnes', 'Description', '', 'descriptionauteur, description', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Lien', '', 'editable', '5', '64', '4', '', '1', '33', '20050325172933');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('34', 'courriel', '0', 'entities_personnes', 'Courriel', '', 'courriel, .courriel', 'email', '', '*', '', '', '', '', 'editable', '', '64', '4', '', '1', '34', '20050325172943');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('35', 'auteur', '14', 'textes', 'Auteur du document', '', '', 'persons', '', '', '', '', '', '', 'editable', '', '64', '0', '', '32', '11', '20050619160022');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('36', 'traducteur', '14', 'textes', 'Traducteur du document', '', '', 'persons', '', '', '', '', '', '', 'importable', '', '64', '0', '', '32', '12', '20050619160022');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('118', 'licence', '19', 'textessimples', 'Licence portant sur le document', '', '', 'entries', '', '', '', '', '', '', 'editable', '', '64', '0', '', '1', '101', '20060227233154');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('117', 'date', '19', 'textessimples', 'Date de publication en ligne', '', '', 'datetime', '', '*', 'now', '', '', '', 'editable', '', '64', '0', '', '1', '100', '20060227233020');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('116', 'url', '19', 'textessimples', 'Lien', '', '', 'url', '', '*', '', '', '', '', 'editable', '', '64', '2', '', '1', '99', '20060227232629');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('115', 'licence', '12', 'publications', 'Licence portant sur la publication', '', '', 'entries', '', '', '', '', '', '', 'editable', '', '64', '0', '', '1', '98', '20060227232211');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('114', 'licence', '3', 'textes', 'Licence portant sur le document', '', '', 'entries', '', '', '', '', '', '', 'editable', '', '64', '0', '', '1', '97', '20060227231301');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('43', 'titre', '5', 'liens', 'Titre du site', '', '', 'text', 'dc.title', '*', 'Site sans titre', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', '', 'editable', '', '64', '8', '', '32', '43', '20050921154344');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('44', 'url', '6', 'liens', 'URL du site', '', '', 'url', '', '*', '', '', '', '', 'editable', '', '64', '0', '', '32', '3', '20060221223507');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('45', 'urlfil', '6', 'liens', 'URL du fil de syndication du site', '', '', 'url', '', '*', '', '', '', '', 'editable', '', '64', '0', '', '32', '4', '20050616121630');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('46', 'texte', '6', 'liens', 'Description du site', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'fckeditor', 'Advanced', '64', '2', '', '32', '1', '20060221223504');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('47', 'titre', '7', 'images', 'Titre de l\'image', '', '', 'text', 'dc.title', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', '', 'editable', '', '64', '4', '', '32', '47', '20050616115715');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('48', 'image', '8', 'images', 'Image', '', '', 'image', '', '*', '', '', '', '', 'editable', '', '64', '0', '', '32', '48', '20050616115724');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('74', 'altertitre', '1', 'textes', 'Titre alternatif du document (dans une autre langue)', '', 'englishtitle:en, titolo:it, titulo:es,titel:de', 'mltext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Lien;Appel de Note', '', 'editable', '', '64', '8', '', '32', '4', '20051010120225');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('50', 'resume', '9', 'textes', 'Résumé', '', 'rsum,resume:fr, abstract:en, riassunto:it, extracto:es, zusammenfassung:de', 'mltext', 'dc.description', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'display', '5', '64', '8', '', '32', '50', '20051031232658');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('51', 'titre', '10', 'publications', 'Titre de la publication', '', 'title, titre, titleuser, heading', 'text', 'dc.title', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', '', 'editable', '', '64', '8', '', '32', '51', '20050616113746');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('52', 'surtitre', '10', 'publications', 'Surtitre de la publication', '', 'surtitre', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', '', 'importable', '', '64', '8', '', '32', '52', '20050616113801');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('53', 'soustitre', '10', 'publications', 'Sous-titre de la publication', '', 'soustitre', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', '', 'editable', '', '64', '8', '', '32', '53', '20050616113832');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('54', 'commentaireinterne', '11', 'publications', 'Commentaire interne sur la publication', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', '', 'importable', '', '64', '0', '', '32', '54', '20050616113849');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('55', 'prioritaire', '11', 'publications', 'Cette publication est-elle prioritaire ?', '', '', 'boolean', '', '*', '', '', '', '', 'editable', '', '64', '0', '', '32', '55', '20050616114451');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('57', 'datepubli', '12', 'publications', 'Date de publication électronique', '', '', 'date', 'dc.date', '*', 'today', '', '', '', 'editable', '', '64', '0', '', '32', '2', '20050616114952');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('58', 'datepublipapier', '12', 'publications', 'Date de publication papier', '', '', 'date', '', '*', '', '', '', '', 'editable', '', '64', '0', '', '32', '3', '20050616114947');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('59', 'noticebiblio', '12', 'publications', 'Notice bibliographique décrivant la publication', '', '', 'tinytext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special', '', 'importable', '', '64', '0', '', '32', '4', '20050616114909');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('60', 'introduction', '13', 'publications', 'Introduction de la publication', '<r2r:ml lang="fr">Introduction de la publication</r2r:ml>', 'texte, standard, normal', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'fckeditor', 'Advanced,550,400', '64', '8', '', '32', '60', '20060126172636');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('61', 'erratum', '13', 'publications', 'Erratum au sujet de la publication', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'importable', '', '64', '2', '', '32', '61', '20050616114626');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('62', 'ndlr', '13', 'publications', 'Note de la rédaction au sujet de la publication', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'importable', '', '64', '2', '', '32', '62', '20050616114636');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('63', 'historique', '13', 'publications', 'Historique de la publication', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'importable', '', '64', '0', '', '32', '63', '20050616114649');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('64', 'periode', '12', 'publications', 'Période de publication', '', '', 'tinytext', '', '*', '', '', '', '', 'importable', '', '64', '0', '', '32', '5', '20050616114925');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('65', 'isbn', '12', 'publications', 'ISBN', '', '', 'tinytext', '', '*', '', '', '', '', 'importable', '', '64', '0', '', '32', '7', '20050616114845');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('66', 'paraitre', '11', 'publications', 'Cette publication est-elle à paraitre ?', '', '', 'boolean', '', '*', '', '', '', '', 'editable', '', '64', '0', '', '32', '66', '20050616114514');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('67', 'integralite', '11', 'publications', 'Cette publication en ligne est-elle intégrale ?', '', '', 'boolean', '', '*', '', '', '', '', 'editable', '', '64', '0', '', '32', '67', '20060227225358');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('68', 'numero', '12', 'publications', 'Numéro de la publication', '', '', 'tinytext', '', '*', '', '', '', '', 'editable', '', '64', '0', '', '32', '6', '20050616114940');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('69', 'keywords', '15', 'textes', 'Keywords index', '', '', 'entries', '', '', '', '', '', '', 'importable', '', '64', '0', '', '32', '3', '20050619160022');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('70', 'role', '0', 'entities_personnes', 'Role dans l\'élaboration du document', '', 'role,.role', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special', '', 'editable', '', '64', '0', '', '1', '68', '20050320113031');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('119', 'email', '30', 'individus', 'Courriel', '', '', 'email', '', '*', '', '', '', '', 'editable', '', '64', '4', '', '1', '3', '20060227233651');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('120', 'site', '30', 'individus', 'Site web', '', '', 'url', '', '*', '', '', '', '', 'editable', '', '64', '0', '', '1', '4', '20060227233648');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('121', 'description', '30', 'individus', 'Description', '', '', 'text', '', '*', '', '', '', '', 'fckeditor', '', '64', '4', '', '1', '2', '20060227233654');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('76', 'titreoeuvre', '17', 'textes', 'Titre de l\'oeuvre commentée', '', 'titreoeuvre', 'tinytext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', '', 'importable', '', '64', '4', '', '32', '2', '20050619160022');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('77', 'noticebibliooeuvre', '17', 'textes', 'Notice bibliographique de l\'oeuvre commentée', '', 'noticebibliooeuvre', 'tinytext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Appel de Note', '', 'importable', '', '64', '4', '', '32', '1', '20050619160022');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('78', 'datepublicationoeuvre', '17', 'textes', 'Date de publication de l\'oeuvre commentée', '', 'datepublioeuvre', 'tinytext', '', '*', '', '', '', '', 'importable', '', '64', '4', '', '32', '70', '20050619160022');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('79', 'auteuroeuvre', '17', 'textes', 'Auteur de l\'oeuvre commentée', '', '', 'persons', '', '', '', '', '', '', 'importable', '', '64', '0', '', '32', '71', '20050619160022');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('81', 'titre', '18', 'textessimples', 'Titre', '', '', 'tinytext', 'dc.title', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'editable', '', '64', '4', '', '1', '72', '20060221235835');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('82', 'texte', '19', 'textessimples', 'Texte', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'fckeditor', '6', '64', '4', '', '1', '73', '20060227232638');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('83', 'ndla', '4', 'textes', 'Note de l\'auteur', '', 'ndla', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'importable', '', '64', '2', '', '32', '74', '20050619160022');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('84', 'titre', '29', 'fichiers_annexes', 'Titre du document', '', '', 'text', 'dc.title', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special', '', 'editable', '', '64', '2', '', '32', '1', '20060222001119');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('86', 'descirption', '20', 'fichiers_annexes', 'Description du fichier', '', '', 'text', 'dc.description', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', '', 'fckeditor', '', '64', '2', '', '32', '2', '20060222001034');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('96', 'icone', '12', 'publications', 'Icône de la publication', '', '', 'image', '', '*', '', '', '', '', 'editable', '', '64', '0', '', '32', '1', '20050616114957');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('97', 'icone', '3', 'textes', 'Icône du document', '', '', 'image', '', '*', '', '', '', '', 'editable', '', '64', '0', '', '32', '88', '20050619160022');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('98', 'description', '8', 'images', 'Description de l\'image', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'fckeditor', 'Advanced,600,600,fr,true,default', '64', '4', '', '32', '89', '20050616151111');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('99', 'alterfichier', '2', 'textes', 'Fichier source alternatif (souvent en PDF)', '', '', 'file', '', '*', '', '', '', '', 'editable', '', '64', '0', '', '32', '90', '20050619160022');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('104', 'langue', '12', 'publications', 'Langue de la publication', '', '', 'lang', 'dc.language', '*', 'fr', '', '', '', 'editable', '', '64', '0', '', '32', '94', '20050708094505');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('100', 'auteur', '24', 'images', 'Auteur de l\'image', '', '', 'persons', '', '', '', '', '', '', 'editable', '', '64', '0', '', '32', '91', '20050616115915');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('101', 'auteur', '25', 'liens', 'Auteur de la notice décrivant ce site', '', '', 'persons', '', '', '', '', '', '', 'editable', '', '64', '0', '', '32', '92', '20050616120132');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('102', 'capturedecran', '6', 'liens', 'Capture d\'écran du site', '', '', 'image', '', '*', '', '', '', '', 'editable', '', '64', '0', '', '32', '2', '20060221223507');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('103', 'auteur', '26', 'textessimples', 'Auteur', '', '', 'persons', '', '', '', '', '', '', 'editable', '', '64', '0', '', '32', '93', '20060221235853');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('105', 'numerodocument', '1', 'textes', 'Numéro du document', '', '', 'number', '', '*', '', '', '', '', 'editable', '', '64', '0', '', '32', '1', '20051010120444');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('107', 'fichier', '20', 'fichiers_annexes', 'Fichier à télécharger', '', '', 'file', '', '*', '', '', '', '', 'editable', '', '64', '0', '', '32', '4', '20060222000715');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('112', 'nom', '28', 'individus', 'Nom de l\'individu', '', '', 'tinytext', 'dc.title', '*', '', '', '', '', 'editable', '', '64', '4', '', '1', '1', '20060227233715');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('113', 'prenom', '28', 'individus', 'Prénom de l\'individu', '', '', 'tinytext', '', '*', '', '', '', '', 'editable', '', '64', '4', '', '1', '2', '20060227233718');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('122', 'accroche', '28', 'individus', 'Accroche', '', '', 'tinytext', '', '*', '', '', '', '', 'editable', '', '64', '4', '', '1', '3', '20060227233718');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('123', 'adresse', '30', 'individus', 'Adresse', '', '', 'text', '', '*', '', '', '', '', 'editable', '3', '64', '4', '', '1', '102', '20060227234156');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('124', 'telephone', '30', 'individus', 'Téléphone', '', '', 'tinytext', '', '*', '', '', '', '', 'editable', '', '64', '4', '', '1', '103', '20060227233803');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('125', 'photographie', '28', 'individus', 'Photographie', '', '', 'image', '', '*', '', '', '', '', 'editable', '', '64', '0', '', '1', '104', '20060227233834');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('126', 'licence', '24', 'images', 'Licence portant sur l\'image', '', '', 'entries', '', '', '', '', '', '', 'editable', '', '64', '0', '', '1', '105', '20060228001554');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('127', 'directeurdelapublication', '12', 'publications', 'Directeur de la publication', '', '', 'persons', '', '', '', '', '', '', 'editable', '', '64', '0', '', '1', '106', '20060228111452');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('128', 'legende', '8', 'images', 'Légende de l\'image', '', '', 'tinytext', '', '*', '', '', '', '', 'editable', '', '64', '4', '', '1', '107', '20060228115520');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, filtering, edition, editionparams, gui_user_complexity, weight, comment, status, rank, upd) VALUES ('129', 'credits', '24', 'images', 'Crédits', '', '', 'tinytext', '', '*', '', '', '', '', 'editable', '', '64', '4', '', '1', '108', '20060228115912');

#
# Dumping data for table 'tablefieldgroups'
#

INSERT INTO #_TP_tablefieldgroups (id, name, class, title, altertitle, comment, status, rank, upd) VALUES ('1', 'grtitre', 'textes', 'Groupe du titre', '', '', '1', '1', '20050619160022');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, altertitle, comment, status, rank, upd) VALUES ('2', 'grtexte', 'textes', 'Groupe du texte', '', '', '1', '3', '20050619160022');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, altertitle, comment, status, rank, upd) VALUES ('3', 'grmeta', 'textes', 'Groupe des métadonnées', '', '', '1', '4', '20050619160022');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, altertitle, comment, status, rank, upd) VALUES ('4', 'graddenda', 'textes', 'Groupe des addenda', '', '', '1', '5', '20050619160022');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, altertitle, comment, status, rank, upd) VALUES ('5', 'grtitre', 'liens', 'Titre', '', '', '1', '5', '20060221223320');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, altertitle, comment, status, rank, upd) VALUES ('6', 'grsite', 'liens', 'Définition du site', '', '', '1', '6', '20060221224034');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, altertitle, comment, status, rank, upd) VALUES ('7', 'grtitre', 'images', 'Titre', '', '', '1', '7', '20060221223117');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, altertitle, comment, status, rank, upd) VALUES ('8', 'grimage', 'images', 'Définition de l\'image', '', '', '1', '8', '20060221223109');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, altertitle, comment, status, rank, upd) VALUES ('9', 'grresumes', 'textes', 'Groupe des résumés', '', '', '1', '2', '20050619160022');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, altertitle, comment, status, rank, upd) VALUES ('10', 'grtitre', 'publications', 'Groupe de titre', '', '', '32', '1', '20050616115010');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, altertitle, comment, status, rank, upd) VALUES ('11', 'grgestion', 'publications', 'Gestion des publications', '', '', '1', '4', '20060227224722');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, altertitle, comment, status, rank, upd) VALUES ('12', 'grmetadonnees', 'publications', 'Groupe des métadonnées', '', '', '32', '3', '20060227224722');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, altertitle, comment, status, rank, upd) VALUES ('13', 'graddenda', 'publications', 'Groupe des addenda', '', '', '32', '2', '20060227224717');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, altertitle, comment, status, rank, upd) VALUES ('14', 'grpersonnes', 'textes', 'Groupe des personnes', '', '', '1', '7', '20050619160022');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, altertitle, comment, status, rank, upd) VALUES ('15', 'grindex', 'textes', 'Groupe des index', '', '', '1', '6', '20050619160022');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, altertitle, comment, status, rank, upd) VALUES ('16', 'grgestion', 'textes', 'Groupe de gestion du document', '', '', '1', '9', '20050619160022');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, altertitle, comment, status, rank, upd) VALUES ('17', 'grrecension', 'textes', 'Oeuvre commentée (si ce document est un compte-rendu d\'oeuvre ou d\'ouvrage...)', '', '', '1', '8', '20050619160022');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, altertitle, comment, status, rank, upd) VALUES ('18', 'grtitre', 'textessimples', 'Titre', '', '', '1', '10', '20060221235818');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, altertitle, comment, status, rank, upd) VALUES ('19', 'grtexte', 'textessimples', 'Texte', '', '', '1', '11', '20060221235818');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, altertitle, comment, status, rank, upd) VALUES ('20', 'grdescription', 'fichiers_annexes', 'Description', '', '', '32', '2', '20060222001136');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, altertitle, comment, status, rank, upd) VALUES ('24', 'grdroits', 'images', 'Droits', '', '', '32', '16', '20060228115827');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, altertitle, comment, status, rank, upd) VALUES ('25', 'grauteurs', 'liens', 'Auteurs', '', '', '32', '17', '20060221223336');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, altertitle, comment, status, rank, upd) VALUES ('26', 'grauteurs', 'textessimples', 'Auteurs', '', '', '32', '18', '20060221235818');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, altertitle, comment, status, rank, upd) VALUES ('28', 'grtitre', 'individus', 'Titre', '', '', '1', '20', '20060222095412');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, altertitle, comment, status, rank, upd) VALUES ('30', 'grdescription', 'individus', 'Description', '', '', '1', '21', '20060222095412');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, altertitle, comment, status, rank, upd) VALUES ('29', 'grtitre', 'fichiers_annexes', 'Titre', '', '', '1', '1', '20060222001110');

#
# Dumping data for table 'types'
#

INSERT INTO #_TP_types (id, type, title, altertitle, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, public, gui_user_complexity, oaireferenced, rank, status, upd) VALUES ('1', 'editorial', 'Editorial', '', 'textes', 'editorial', 'entities', '', '1', '', '-1', '1', '0', '64', '1', '1', '32', '20060227150155');
INSERT INTO #_TP_types (id, type, title, altertitle, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, public, gui_user_complexity, oaireferenced, rank, status, upd) VALUES ('2', 'article', 'Article', '', 'textes', 'article', 'entities', '', '1', '', '-1', '1', '0', '64', '1', '2', '1', '20060227150155');
INSERT INTO #_TP_types (id, type, title, altertitle, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, public, gui_user_complexity, oaireferenced, rank, status, upd) VALUES ('3', 'actualite', 'Annonce et actualité', '', 'textes', 'actualite', 'entities', '', '1', '', '-1', '1', '0', '64', '0', '3', '32', '20060227150155');
INSERT INTO #_TP_types (id, type, title, altertitle, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, public, gui_user_complexity, oaireferenced, rank, status, upd) VALUES ('5', 'compte rendu', 'Compte-rendu', '', 'textes', 'compterendu', 'entities', '', '1', '', '-1', '1', '0', '64', '1', '5', '32', '20060227150155');
INSERT INTO #_TP_types (id, type, title, altertitle, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, public, gui_user_complexity, oaireferenced, rank, status, upd) VALUES ('6', 'note de lecture', 'Note de lecture', '', 'textes', 'notedelecture', 'entities', '', '1', '', '-1', '1', '0', '64', '1', '6', '32', '20060227150155');
INSERT INTO #_TP_types (id, type, title, altertitle, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, public, gui_user_complexity, oaireferenced, rank, status, upd) VALUES ('7', 'presentation', 'Présentation', '', 'textes', 'presentation', 'entities', '', '1', '', '-1', '1', '0', '64', '0', '7', '32', '20060227150155');
INSERT INTO #_TP_types (id, type, title, altertitle, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, public, gui_user_complexity, oaireferenced, rank, status, upd) VALUES ('8', 'chronique', 'Chronique', '', 'textes', 'article', 'entities', '', '1', '', '-1', '1', '0', '64', '0', '8', '32', '20060227150155');
INSERT INTO #_TP_types (id, type, title, altertitle, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, public, gui_user_complexity, oaireferenced, rank, status, upd) VALUES ('9', 'collection', 'Collection', '', 'publications', 'sommaire', 'entities', 'edition', '0', '', '-1', '1', '0', '64', '0', '9', '32', '20060227150155');
INSERT INTO #_TP_types (id, type, title, altertitle, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, public, gui_user_complexity, oaireferenced, rank, status, upd) VALUES ('10', 'volume', 'Volume', '', 'publications', 'sommaire', 'entities', 'edition', '0', '', '-1', '1', '0', '64', '0', '10', '1', '20060227150155');
INSERT INTO #_TP_types (id, type, title, altertitle, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, public, gui_user_complexity, oaireferenced, rank, status, upd) VALUES ('11', 'numero', 'Numéro', '', 'publications', 'sommaire', 'entities', 'edition', '0', '', '-1', '1', '0', '64', '0', '11', '32', '20060227150155');
INSERT INTO #_TP_types (id, type, title, altertitle, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, public, gui_user_complexity, oaireferenced, rank, status, upd) VALUES ('12', 'rubrique', 'Rubrique', '', 'publications', 'sommaire', 'entities', 'edition', '0', '', '-1', '1', '0', '64', '0', '12', '32', '20060227150155');
INSERT INTO #_TP_types (id, type, title, altertitle, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, public, gui_user_complexity, oaireferenced, rank, status, upd) VALUES ('13', 'regroupement', 'Regroupement', '', 'publications', '', 'entities', 'edition', '0', 'unfolded', '-1', '1', '0', '64', '0', '14', '32', '20060227150155');
INSERT INTO #_TP_types (id, type, title, altertitle, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, public, gui_user_complexity, oaireferenced, rank, status, upd) VALUES ('14', 'image', 'Image', '', 'images', 'image', 'entities', '', '0', '', '-1', '1', '0', '64', '0', '15', '1', '20060227150155');
INSERT INTO #_TP_types (id, type, title, altertitle, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, public, gui_user_complexity, oaireferenced, rank, status, upd) VALUES ('15', 'noticedesite', 'Notice de site', '', 'liens', 'lien', 'entities', 'edition', '0', '', '-1', '1', '0', '64', '0', '16', '1', '20060228112826');
INSERT INTO #_TP_types (id, type, title, altertitle, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, public, gui_user_complexity, oaireferenced, rank, status, upd) VALUES ('16', 'commentaire', 'Commentaire du document', '', 'textessimples', '', 'entities', '', '0', 'advanced', '-1', '1', '1', '64', '0', '2', '1', '20060227150155');
INSERT INTO #_TP_types (id, type, title, altertitle, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, public, gui_user_complexity, oaireferenced, rank, status, upd) VALUES ('17', 'docannexe_fichier', 'Fichier placé en annexe', '', 'fichiers_annexes', '', 'entities', '', '0', 'advanced', '-1', '1', '0', '64', '0', '19', '32', '20060227150155');
INSERT INTO #_TP_types (id, type, title, altertitle, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, public, gui_user_complexity, oaireferenced, rank, status, upd) VALUES ('23', 'annuairedepersonnes', 'Annuaire de personnes', '', 'publications', 'sommaire', 'entities', 'edition', '0', '', '-1', '1', '0', '64', '0', '28', '32', '20060227150155');
INSERT INTO #_TP_types (id, type, title, altertitle, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, public, gui_user_complexity, oaireferenced, rank, status, upd) VALUES ('24', 'annuairedimages', 'Iconothèque', '', 'publications', 'sommaire', 'entities', 'edition', '0', '', '-1', '1', '0', '64', '0', '29', '32', '20060227150155');
INSERT INTO #_TP_types (id, type, title, altertitle, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, public, gui_user_complexity, oaireferenced, rank, status, upd) VALUES ('18', 'image_annexe', 'Image placée en annexe', '', 'images', '', 'entities', 'edition', '0', 'advanced', '-1', '1', '0', '64', '0', '23', '1', '20060227150155');
INSERT INTO #_TP_types (id, type, title, altertitle, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, public, gui_user_complexity, oaireferenced, rank, status, upd) VALUES ('19', 'lienannexe', 'Lien placé en annexe', '', 'liens', 'lien', 'entities', 'edition', '0', 'advanced', '-1', '1', '0', '64', '0', '24', '1', '20060228112819');
INSERT INTO #_TP_types (id, type, title, altertitle, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, public, gui_user_complexity, oaireferenced, rank, status, upd) VALUES ('20', 'individu', 'Personne', '', 'individus', '', 'entities', 'edition', '0', '', '-1', '1', '0', '64', '0', '25', '1', '20060227150155');
INSERT INTO #_TP_types (id, type, title, altertitle, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, public, gui_user_complexity, oaireferenced, rank, status, upd) VALUES ('21', 'billet', 'Billet', '', 'textessimples', '', 'entities', 'edition', '0', '', '-1', '1', '0', '64', '0', '1', '1', '20060227150155');
INSERT INTO #_TP_types (id, type, title, altertitle, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, public, gui_user_complexity, oaireferenced, rank, status, upd) VALUES ('22', 'annuairedesites', 'Annuaire de sites', '', 'publications', 'sommaire', 'entities', 'edition', '0', '', '-1', '1', '0', '64', '0', '27', '32', '20060227150155');
INSERT INTO #_TP_types (id, type, title, altertitle, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, public, gui_user_complexity, oaireferenced, rank, status, upd) VALUES ('25', 'fluxdesyndication', 'Flux de syndication', '', 'liens', 'lien', 'entities', 'edition', '0', '', '-1', '1', '0', '64', '0', '30', '1', '20060227150155');

#
# Dumping data for table 'persontypes'
#

INSERT INTO #_TP_persontypes (id, type, title, altertitle, class, style, g_type, tpl, tplindex, rank, status, upd, gui_user_complexity) VALUES ('26', 'auteur', 'Auteur', '', 'auteurs', 'auteur', 'dc.creator', 'personne', 'personnes', '1', '1', '20060227150155', '64');
INSERT INTO #_TP_persontypes (id, type, title, altertitle, class, style, g_type, tpl, tplindex, rank, status, upd, gui_user_complexity) VALUES ('27', 'traducteur', 'Traducteur', '', 'auteurs', 'traducteur', 'dc.contributor', 'personne', 'personnes', '2', '1', '20060227150155', '64');
INSERT INTO #_TP_persontypes (id, type, title, altertitle, class, style, g_type, tpl, tplindex, rank, status, upd, gui_user_complexity) VALUES ('28', 'directeurdelapublication', 'Directeur de la publication', '', 'auteurs', 'directeur', '', 'personne', 'personnes', '3', '32', '20060228111502', '64');
INSERT INTO #_TP_persontypes (id, type, title, altertitle, class, style, g_type, tpl, tplindex, rank, status, upd, gui_user_complexity) VALUES ('29', 'auteuroeuvre', 'Auteur d\'une oeuvre commentée', '', 'auteurs', 'auteuroeuvre', '', 'personne', 'personnes', '4', '32', '20060227150155', '64');

#
# Dumping data for table 'entrytypes'
#

INSERT INTO #_TP_entrytypes (id, type, class, title, altertitle, style, g_type, tpl, tplindex, rank, status, flat, newbyimportallowed, edition, sort, upd, gui_user_complexity) VALUES ('30', 'motcle', 'indexes', 'Index de mots-clés', '', 'motscles, .motcles,motscls', 'dc.subject', 'entree', 'entrees', '1', '1', '1', '1', 'pool', 'sortkey', '20060227150155', '64');
INSERT INTO #_TP_entrytypes (id, type, class, title, altertitle, style, g_type, tpl, tplindex, rank, status, flat, newbyimportallowed, edition, sort, upd, gui_user_complexity) VALUES ('31', 'keywords', 'indexes', 'Keywords index', '', 'keywords', '', 'entree', 'entrees', '2', '1', '1', '1', 'pool', 'sortkey', '20060227150155', '64');
INSERT INTO #_TP_entrytypes (id, type, class, title, altertitle, style, g_type, tpl, tplindex, rank, status, flat, newbyimportallowed, edition, sort, upd, gui_user_complexity) VALUES ('77', 'chrono', 'indexes', 'Index chronologique', '', 'periode, .periode, priode', '', 'entree', 'entrees', '6', '1', '0', '0', 'pool', 'sortkey', '20060227230547', '64');
INSERT INTO #_TP_entrytypes (id, type, class, title, altertitle, style, g_type, tpl, tplindex, rank, status, flat, newbyimportallowed, edition, sort, upd, gui_user_complexity) VALUES ('78', 'theme', 'indexes', 'Index thématique', '', 'themes,thmes,.themes', '', 'entree', 'entrees', '7', '1', '0', '0', 'pool', 'sortkey', '20060227230731', '64');
INSERT INTO #_TP_entrytypes (id, type, class, title, altertitle, style, g_type, tpl, tplindex, rank, status, flat, newbyimportallowed, edition, sort, upd, gui_user_complexity) VALUES ('76', 'geographie', 'indexes', 'Index géographique', '', 'geographie, gographie,.geographie', '', 'entree', 'entrees', '5', '1', '0', '0', 'pool', 'sortkey', '20060227230501', '64');
INSERT INTO #_TP_entrytypes (id, type, class, title, altertitle, style, g_type, tpl, tplindex, rank, status, flat, newbyimportallowed, edition, sort, upd, gui_user_complexity) VALUES ('79', 'licence', 'indexes', 'Licence portant sur le document', '', 'licence', '', 'entree', 'entrees', '8', '1', '1', '0', 'select', 'sortkey', '20060227231124', '64');

#
# Dumping data for table 'entitytypes_entitytypes'
#

INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('9', '0', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('10', '9', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('11', '10', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('12', '12', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('12', '9', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('13', '12', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('13', '13', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('13', '11', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('1', '11', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('1', '9', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('24', '12', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('2', '11', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('2', '9', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('23', '12', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('23', '9', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('3', '10', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('3', '12', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('3', '13', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('3', '11', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('3', '9', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('24', '9', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('5', '10', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('5', '12', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('5', '13', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('5', '11', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('6', '10', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('6', '12', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('6', '13', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('7', '10', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('7', '12', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('7', '13', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('7', '11', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('7', '9', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('8', '10', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('8', '12', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('8', '13', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('8', '11', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('8', '9', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('14', '12', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('14', '13', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('16', '7', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('15', '10', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('15', '12', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('15', '13', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('15', '11', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('23', '0', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('16', '6', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('16', '1', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('16', '5', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('16', '8', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('17', '16', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('1', '10', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('11', '9', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('1', '12', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('1', '13', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('2', '12', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('2', '10', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('16', '2', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('16', '3', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('16', '15', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('14', '11', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('14', '9', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('22', '12', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('22', '9', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('16', '14', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('17', '7', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('17', '6', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('17', '1', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('17', '5', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('17', '8', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('17', '2', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('17', '14', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('17', '15', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('17', '3', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('2', '13', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('6', '11', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('22', '0', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('14', '10', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('15', '9', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('18', '7', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('18', '6', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('18', '1', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('18', '5', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('18', '8', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('18', '2', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('18', '3', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('19', '7', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('19', '6', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('19', '1', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('19', '5', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('19', '8', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('19', '2', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('19', '3', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('24', '0', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('21', '12', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('22', '10', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('23', '10', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('24', '10', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('25', '10', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('25', '12', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('25', '13', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('25', '11', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('25', '9', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('25', '24', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES ('20', '12', '*');

#
# Dumping data for table 'characterstyles'
#


#
# Dumping data for table 'internalstyles'
#

INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('1', 'citation', '*-', '<blockquote>', '0', '1', '1', '20050901151236');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('2', 'quotations', '*-', '<blockquote>', '0', '2', '1', '20050901151241');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('3', 'citationbis', '*-', '<blockquote class="citationbis">', '0', '3', '1', '20050310184950');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('4', 'citationter', '*-', '<blockquote class="citationter">', '0', '4', '1', '20050310185012');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('5', 'titreillustration', '*-', '', '0', '5', '1', '20050310185150');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('6', 'legendeillustration', '*-', '', '0', '6', '1', '20050310185207');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('7', 'titredoc', '*-', '', '0', '7', '1', '20050310185225');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('8', 'legendedoc', '*-', '', '0', '8', '1', '20050310185234');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('9', 'puces', '*-', '<ul><li>', '0', '9', '1', '20050310185304');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('10', 'code', '*-', '', '0', '10', '1', '20050310185341');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('11', 'question', '*-', '', '0', '11', '1', '20050310185417');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('12', 'reponse', '*-', '', '0', '12', '1', '20050429171251');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('20', 'separateur', '*-', '<hr style="style">', '0', '19', '1', '20050901151307');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('19', 'section1', '-*', '', '0', '13', '1', '20050429171303');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('15', 'section3', '*-', '<h3>', '0', '15', '1', '20050429171302');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('16', 'section4', '*-', '<h4>', '0', '16', '1', '20050429171300');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('17', 'section5', '*-', '<h5>', '0', '17', '1', '20050429171242');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('18', 'section6', '*-', '<h6>', '0', '18', '1', '20050429171237');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('21', 'paragraphesansretrait', '*-', '', '0', '20', '1', '20050524222439');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('22', 'epigraphe', '*-', '', '0', '21', '1', '20050524222428');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('23', 'section2', '-*', '', '0', '14', '1', '20050429171303');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('24', 'pigraphe', '-*', '', '0', '22', '1', '20050524222450');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('25', 'sparateur', '-*', '', '0', '23', '1', '20050524222507');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('26', 'quotation', '-*', '<blockquote>', '0', '24', '1', '20050901151253');
DELETE FROM #_TP_optiongroups;
# # Database: 'lodeldevelunstable_revorg08'# 
#
# Dumping data for table 'optiongroups'
#

INSERT INTO #_TP_optiongroups (id, idparent, name, title, altertitle, comment, logic, exportpolicy, rank, status, upd) VALUES ('1', '0', 'servoo', 'servoo', '', '', 'servooconf', '1', '1', '32', '20050511150438');
INSERT INTO #_TP_optiongroups (id, idparent, name, title, altertitle, comment, logic, exportpolicy, rank, status, upd) VALUES ('2', '0', 'metadonneessite', 'Métadonnées du site', '', '', '', '1', '2', '1', '20050312112815');
INSERT INTO #_TP_optiongroups (id, idparent, name, title, altertitle, comment, logic, exportpolicy, rank, status, upd) VALUES ('3', '0', 'optionsvisuelles', 'Options visuelles', '', '', '', '1', '3', '32', '20050526172943');
DELETE FROM #_TP_options;
# # Database: 'lodeldevelunstable_revorg08'# 
#
# Dumping data for table 'options'
#

INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status, upd, edition, editionparams) VALUES ('1', '1', 'url', 'url', 'tinytext', '', '', '40', '1', '32', '20060227151009', '', '');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status, upd, edition, editionparams) VALUES ('2', '1', 'username', 'username', 'tinytext', '', '', '40', '2', '32', '20060227151009', '', '');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status, upd, edition, editionparams) VALUES ('3', '1', 'passwd', 'password', 'passwd', '', '', '40', '3', '32', '20060227151009', '', '');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status, upd, edition, editionparams) VALUES ('4', '2', 'titresite', 'Titre du site', 'tinytext', 'Titresite', '', '40', '4', '1', '20050511165930', '', '');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status, upd, edition, editionparams) VALUES ('5', '2', 'titresiteabrege', 'Titre abrégé du site', 'tinytext', 'Titre abrégé du site', '', '40', '5', '1', '20050411204853', '', '');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status, upd, edition, editionparams) VALUES ('6', '2', 'descriptionsite', 'Description du site', 'text', '', '', '10', '6', '1', '20050511165930', '', '');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status, upd, edition, editionparams) VALUES ('7', '2', 'urldusite', 'URL officielle du site', 'url', '', '', '30', '7', '1', '20050312113446', '', '');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status, upd, edition, editionparams) VALUES ('8', '2', 'urlcomlementaire', 'URL en lien avec le site', 'url', '', '', '30', '8', '1', '20050312113519', '', '');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status, upd, edition, editionparams) VALUES ('9', '2', 'ISSN', 'ISSN', 'tinytext', '', '', '30', '9', '1', '20050312113548', '', '');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status, upd, edition, editionparams) VALUES ('10', '2', 'editeur', 'Nom de l\'éditeur du site', 'tinytext', '', '', '30', '10', '1', '20050312113601', '', '');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status, upd, edition, editionparams) VALUES ('11', '2', 'adresseediteur', 'Adresse postale de l\'éditeur', 'text', '', '', '30', '11', '1', '20050312113615', '', '');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status, upd, edition, editionparams) VALUES ('12', '2', 'producteursite', 'Nom du producteur du site', 'tinytext', '', '', '30', '12', '1', '20050312113636', '', '');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status, upd, edition, editionparams) VALUES ('13', '2', 'diffuseursite', 'Nom du diffuseur du site', 'tinytext', '', '', '30', '13', '1', '20050312113703', '', '');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status, upd, edition, editionparams) VALUES ('14', '2', 'droitsauteur', 'Droits d\'auteur par défaut', 'tinytext', '', '', '30', '14', '1', '20050312113731', '', '');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status, upd, edition, editionparams) VALUES ('15', '2', 'directeurpublication', 'Nom du directeur de la publication', 'tinytext', '', '', '30', '15', '1', '20050312113749', '', '');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status, upd, edition, editionparams) VALUES ('16', '2', 'redacteurenchef', 'Nom du Rédacteur en chef', 'tinytext', '', '', '30', '16', '1', '20050312113806', '', '');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status, upd, edition, editionparams) VALUES ('17', '2', 'courrielwebmaster', 'Courriel du webmaster', 'email', '', '', '30', '17', '1', '20050504121912', '', '');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status, upd, edition, editionparams) VALUES ('18', '2', 'courrielabuse', 'Courriel abuse', 'tinytext', '', '', '30', '18', '1', '20050312113903', '', '');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status, upd, edition, editionparams) VALUES ('19', '2', 'motsclesdusite', 'Mots clés décrivant le site (entre virgules)', 'text', '', '', '30', '19', '1', '20050312113948', '', '');
# # Database: 'lodeldevelunstable_revorg08'# 
# --------------------------------------------------------

#
# Table structure for table 'textes'
#

DROP TABLE IF EXISTS #_TP_textes;
CREATE TABLE #_TP_textes (
  identity int(10) unsigned default NULL,
  titre text,
  surtitre text,
  soustitre text,
  texte longtext,
  notebaspage text,
  annexe text,
  bibliographie text,
  datepubli date default NULL,
  datepublipapier date default NULL,
  noticebiblio tinytext,
  pagination tinytext,
  droitsauteur tinytext,
  langue varchar(5) default NULL,
  prioritaire tinyint(4) default NULL,
  erratum text,
  ndlr text,
  historique text,
  commentaireinterne text,
  dedicace text,
  remerciements text,
  ocr tinyint(4) default NULL,
  documentcliquable tinyint(4) default NULL,
  resume text,
  altertitre text,
  titreoeuvre tinytext,
  noticebibliooeuvre tinytext,
  datepublicationoeuvre tinytext,
  ndla text,
  icone tinytext,
  alterfichier tinytext,
  numerodocument double default NULL,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table 'publications'
#

DROP TABLE IF EXISTS #_TP_publications;
CREATE TABLE #_TP_publications (
  identity int(10) unsigned default NULL,
  titre text,
  surtitre text,
  soustitre text,
  commentaireinterne text,
  prioritaire tinyint(4) default NULL,
  datepubli date default NULL,
  datepublipapier date default NULL,
  noticebiblio tinytext,
  introduction text,
  erratum text,
  ndlr text,
  historique text,
  periode tinytext,
  isbn tinytext,
  paraitre tinyint(4) default NULL,
  integralite tinyint(4) default NULL,
  numero tinytext,
  icone tinytext,
  langue varchar(5) default NULL,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table 'images'
#

DROP TABLE IF EXISTS #_TP_images;
CREATE TABLE #_TP_images (
  identity int(10) unsigned default NULL,
  titre text,
  image tinytext,
  description text,
  legende tinytext,
  credits tinytext,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table 'liens'
#

DROP TABLE IF EXISTS #_TP_liens;
CREATE TABLE #_TP_liens (
  identity int(10) unsigned default NULL,
  titre text,
  url text,
  urlfil text,
  texte text,
  capturedecran tinytext,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table 'textessimples'
#

DROP TABLE IF EXISTS #_TP_textessimples;
CREATE TABLE #_TP_textessimples (
  identity int(10) unsigned default NULL,
  titre tinytext,
  texte text,
  url text,
  date datetime default NULL,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table 'auteurs'
#

DROP TABLE IF EXISTS #_TP_auteurs;
CREATE TABLE #_TP_auteurs (
  idperson int(10) unsigned default NULL,
  nomfamille tinytext,
  prenom tinytext,
  UNIQUE KEY idperson (idperson),
  KEY index_idperson (idperson)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table 'entities_auteurs'
#

DROP TABLE IF EXISTS #_TP_entities_auteurs;
CREATE TABLE #_TP_entities_auteurs (
  idrelation int(10) unsigned default NULL,
  prefix tinytext,
  affiliation tinytext,
  fonction tinytext,
  description text,
  courriel text,
  role text,
  UNIQUE KEY idrelation (idrelation),
  KEY index_idrelation (idrelation)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table 'indexes'
#

DROP TABLE IF EXISTS #_TP_indexes;
CREATE TABLE #_TP_indexes (
  identry int(10) unsigned default NULL,
  nom text,
  definition text,
  UNIQUE KEY identry (identry),
  KEY index_identry (identry)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table 'fichiers_annexes'
#

DROP TABLE IF EXISTS #_TP_fichiers_annexes;
CREATE TABLE #_TP_fichiers_annexes (
  identity int(10) unsigned default NULL,
  titre text,
  descirption text,
  fichier tinytext,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table 'individus'
#

DROP TABLE IF EXISTS #_TP_individus;
CREATE TABLE #_TP_individus (
  identity int(10) unsigned default NULL,
  nom tinytext,
  prenom tinytext,
  email text,
  site text,
  description text,
  accroche tinytext,
  adresse text,
  telephone tinytext,
  photographie tinytext,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) TYPE=MyISAM;
