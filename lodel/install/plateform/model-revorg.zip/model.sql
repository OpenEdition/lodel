# <model>
# 			<lodelversion>0.9</lodelversion>
# 			<date>2009-11-18</date>
# 			<title>
# 			Modèle éditorial de Revues.org
# 			</title>
# 			<description>
# 			Modèle éditorial de Revues.org
# 			</description>
# 			<author>
# 			Revues.org
# 			</author>
# 			<modelversion>
# 			20091007
# 			</modelversion>
# 			</model>
# 			
#------------

DELETE FROM #_TP_classes;
DELETE FROM #_TP_tablefields;
DELETE FROM #_TP_tablefieldgroups;
DELETE FROM #_TP_types;
DELETE FROM #_TP_persontypes;
DELETE FROM #_TP_entrytypes;
DELETE FROM #_TP_entitytypes_entitytypes;
DELETE FROM #_TP_characterstyles;
DELETE FROM #_TP_internalstyles;
# # Database: 'lodelmignot09_test-maquette-bleue'# 
#
# Dumping data for table 'classes'
#

INSERT INTO #_TP_classes (id, icon, class, title, altertitle, classtype, comment, rank, status, upd) VALUES (7254, 'lodel/icons/texte.gif', 'textes', 'Textes', '', 'entities', '', 2, 32, '2009-07-06 17:08:48'),
(7255, 'lodel/icons/collection.gif', 'publications', 'Publications', '', 'entities', '', 1, 1, '2009-07-06 17:08:48'),
(7256, 'lodel/icons/doc_annexe.gif', 'fichiers', 'Fichiers', '', 'entities', '', 5, 32, '2009-07-06 17:08:48'),
(7257, 'lodel/icons/lien.gif', 'liens', 'Sites', '', 'entities', '', 6, 32, '2009-07-06 17:08:48'),
(7258, 'lodel/icons/texte_simple.gif', 'textessimples', 'Textes simples', '', 'entities', '', 3, 32, '2009-07-06 17:08:48'),
(7259, 'lodel/icons/personne.gif', 'auteurs', 'Auteurs', '', 'persons', '', 8, 32, '2009-07-06 17:08:48'),
(7260, 'lodel/icons/index.gif', 'indexes', 'Index', '', 'entries', '', 9, 1, '2009-07-06 17:08:48'),
(7261, 'lodel/icons/individu.gif', 'individus', 'Personnes', '', 'entities', '', 4, 1, '2009-07-06 17:08:48'),
(7262, 'lodel/icons/index_avance.gif', 'indexavances', 'Index avancés', '', 'entries', '', 10, 1, '2009-07-06 17:08:48');

#
# Dumping data for table 'tablefields'
#

INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, gui_user_complexity, filtering, edition, editionparams, weight, comment, status, rank, upd, mask) VALUES (1, 'titre', 31, 'textes', 'Titre du document', '', 'title, titre, titleuser, heading', 'text', 'dc.title', '+', 'Document sans titre', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Lien;Appel de Note', 16, '', 'editable', '', 8, '', 32, 3, '2006-03-01 19:10:00', ''),
(2, 'surtitre', 31, 'textes', 'Surtitre du document', '', 'surtitre', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Lien;Appel de Note', 32, '', 'importable', '', 8, '', 32, 2, '2006-03-01 19:09:47', ''),
(3, 'soustitre', 31, 'textes', 'Sous-titre du document', '', 'subtitle, soustitre', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Lien;Appel de Note', 32, '', 'editable', '', 8, '', 32, 5, '2006-07-13 10:25:47', ''),
(4, 'texte', 32, 'textes', 'Texte du document', '', 'texte, standard, normal, textbody', 'longtext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 16, '', 'display', '', 4, '', 32, 1, '2006-12-06 19:56:09', ''),
(5, 'notesbaspage', 32, 'textes', 'Notes de bas de page', '', 'notebaspage, footnote, footnotetext', 'longtext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', 32, '', 'importable', '', 4, '', 32, 2, '2007-12-13 12:18:36', ''),
(7, 'annexe', 32, 'textes', 'Annexes du document', '', 'annexe', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 32, '', 'importable', '', 4, '', 32, 4, '2006-12-18 11:28:37', ''),
(8, 'bibliographie', 32, 'textes', 'Bibliographie du document', '', 'bibliographie', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 32, '', 'importable', '', 4, '', 32, 5, '2006-12-18 11:28:52', ''),
(9, 'datepubli', 33, 'textes', 'Date de la publication électronique', '', 'datepubli', 'date', 'dc.date', '*', 'today', '', '', 16, '', 'editable', '', 0, '', 32, 1, '2006-06-19 08:28:07', ''),
(10, 'datepublipapier', 33, 'textes', 'Date de la publication sur papier', '', 'datepublipapier', 'date', '', '*', '', '', '', 32, '', 'editable', '', 0, '', 32, 2, '2006-03-01 18:26:08', ''),
(11, 'noticebiblio', 33, 'textes', 'Notice bibliographique du document', '', 'noticebiblio', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special', 64, '', 'importable', '', 0, '', 32, 3, '2007-10-05 16:48:30', ''),
(12, 'pagination', 33, 'textes', 'Pagination du document sur le papier', '', 'pagination', 'tinytext', '', '*', '', '', '', 64, '', 'editable', '', 0, '', 32, 4, '2005-06-19 16:00:22', ''),
(130, 'editeurscientifique', 14, 'textes', 'Éditeur scientifique', '', '', 'persons', '', '', '', '', '', 64, '', 'editable', '', 0, '', 1, 109, '2006-03-01 19:03:00', ''),
(14, 'langue', 33, 'textes', 'Langue du document', '', 'langue', 'lang', 'dc.language', '*', 'fr', '', '', 32, '', 'editable', '', 0, '', 1, 6, '2007-10-18 17:06:51', ''),
(15, 'prioritaire', 16, 'textes', 'Document prioritaire', '', '', 'boolean', '', '*', '', '', '', 64, '', 'editable', '', 0, '', 32, 7, '2005-06-19 16:00:22', ''),
(17, 'addendum', 34, 'textes', 'Addendum', '', 'erratum, addendum', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 64, '', 'importable', '', 2, '', 32, 3, '2006-03-08 17:48:24', ''),
(18, 'ndlr', 34, 'textes', 'Note de la rédaction', '', 'ndlr', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 64, '', 'importable', '', 2, '', 32, 1, '2006-03-08 17:48:20', ''),
(20, 'commentaireinterne', 16, 'textes', 'Commentaire interne sur le document', '', 'commentaire', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', 64, '', 'importable', '', 0, '', 32, 4, '2005-06-19 16:00:22', ''),
(21, 'dedicace', 34, 'textes', 'Dédicace', '', 'dedicace', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 64, '', 'importable', '', 2, '', 32, 4, '2006-03-08 17:48:20', ''),
(23, 'ocr', 16, 'textes', 'Document issu d\'une numérisation dite OCR', '', '', 'boolean', '', '*', '', '', '', 64, '', 'importable', '', 0, '', 32, 9, '2005-06-19 16:00:22', ''),
(24, 'documentcliquable', 16, 'textes', 'Document cliquable dans les sommaires', '', '', 'boolean', '', '*', 'true', '', '', 64, '', 'editable', '', 0, '', 32, 10, '2005-06-19 16:00:22', ''),
(25, 'nom', 0, 'indexes', 'Dénomination de l\'entrée d\'index', '', '', 'text', 'index key', '*', 'Tous droits réservés', '', '', 16, '', 'editable', '', 4, '', 32, 25, '2006-06-19 12:43:13', ''),
(26, 'motsclesfr', 15, 'textes', 'Index de mots-clés', '', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', 0, '', 32, 2, '2008-01-23 12:06:56', ''),
(27, 'definition', 0, 'indexes', 'Définition', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', 16, '', 'fckeditor', 'Basic', 1, '', 32, 27, '2006-07-10 17:15:19', ''),
(28, 'nomfamille', 0, 'auteurs', 'Nom de famille', '', '', 'tinytext', 'familyname', '*', '', '', '', 32, '', 'editable', '', 4, '', 32, 28, '2006-12-18 11:35:36', ''),
(29, 'prenom', 0, 'auteurs', 'Prénom', '', '', 'tinytext', 'firstname', '*', '', '', '', 32, '', 'editable', '', 4, '', 32, 29, '2006-12-18 11:39:26', ''),
(30, 'prefix', 0, 'entities_auteurs', 'Préfixe', '', 'prefixe, .prefixe', 'tinytext', '', '*', '', '', '', 64, '', 'editable', '', 0, '', 1, 2, '2007-01-15 13:03:35', ''),
(31, 'affiliation', 0, 'entities_auteurs', 'Affiliation', '', 'affiliation, .affiliation', 'tinytext', '', '*', '', '', '', 32, '', 'editable', '', 4, '', 1, 3, '2007-01-15 13:03:33', ''),
(32, 'fonction', 0, 'entities_auteurs', 'Fonction', '', 'fonction, .fonction', 'tinytext', '', '*', '', '', '', 32, '', 'editable', '', 0, '', 1, 4, '2007-01-15 13:05:00', ''),
(33, 'description', 0, 'entities_auteurs', 'Description de l\'auteur', '', 'descriptionauteur', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Lien', 16, '', 'fckeditor', '5', 4, '', 1, 1, '2007-09-13 14:43:38', ''),
(34, 'courriel', 0, 'entities_auteurs', 'Courriel', '', 'courriel, .courriel', 'email', '', '*', '', '', '', 32, '', 'editable', '', 4, '', 1, 5, '2007-01-15 13:05:15', ''),
(35, 'auteur', 14, 'textes', 'Auteur du document', '', '', 'persons', '', '', '', '', '', 64, '', 'editable', '', 0, '', 32, 11, '2005-06-19 16:00:22', ''),
(36, 'traducteur', 14, 'textes', 'Traducteur du document', '', '', 'persons', '', '', '', '', '', 64, '', 'editable', '', 0, '', 32, 12, '2006-03-01 18:51:45', ''),
(142, 'alias', 16, 'textes', 'Alias', '', '', 'entities', '', '*', '', '', '', 64, '', 'editable', '', 0, '', 1, 119, '2006-12-18 12:50:12', ''),
(117, 'date', 19, 'textessimples', 'Date de publication en ligne', '', '', 'datetime', '', '*', 'now', '', '', 16, '', 'editable', '', 0, '', 1, 100, '2006-06-27 23:51:45', ''),
(116, 'url', 19, 'textessimples', 'Lien', '', '', 'url', '', '*', '', '', '', 16, '', 'editable', '', 2, '', 1, 99, '2006-06-27 23:50:37', ''),
(140, 'licence', 24, 'fichiers', 'Licence', '', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', 0, '', 1, 118, '2006-03-07 17:09:58', ''),
(43, 'titre', 35, 'liens', 'Titre du site', '', '', 'text', 'dc.title', '*', 'Site sans titre', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', 16, '', 'editable', '', 8, '', 32, 43, '2006-06-22 17:54:35', ''),
(44, 'url', 36, 'liens', 'URL du site', '', '', 'url', '', '*', '', '', '', 16, '', 'editable', '', 0, '', 32, 1, '2006-06-22 17:57:52', ''),
(45, 'urlfil', 36, 'liens', 'URL du fil de syndication du site', '', '', 'url', '', '*', '', '', '', 16, '', 'editable', '', 0, '', 32, 4, '2006-06-22 17:55:41', ''),
(46, 'texte', 36, 'liens', 'Description du site', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 16, '', 'fckeditor', 'Simple', 2, '', 32, 2, '2006-07-10 17:16:44', ''),
(47, 'titre', 37, 'fichiers', 'Titre', '', '', 'text', 'dc.title', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', 16, '', 'editable', '', 4, '', 32, 47, '2006-06-22 22:53:15', ''),
(48, 'document', 38, 'fichiers', 'Document', '', '', 'file', '', '*', '', '', '', 16, '', 'editable', '', 0, '', 32, 1, '2006-06-22 22:53:31', ''),
(74, 'altertitre', 31, 'textes', 'Titre alternatif du document (dans une autre langue)', '', 'titretraduitfr:fr,titrefr:fr,titretraduiten:en,titleen:en,titreen:en,titretraduites:es,tituloes:es,titrees:es,titretraduitit:it,titoloit:it,titreit:it,titretraduitde:de,titelde:de,titrede:de,titretraduitpt:pt,titrept:pt,titretraduitru:ru,titreru:ru', 'mltext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Lien;Appel de Note', 16, '', 'editable', '', 8, '', 32, 4, '2008-02-20 14:07:08', ''),
(50, 'resume', 39, 'textes', 'Résumé', '', 'rsum:fr,resume:fr,resumefr:fr,abstract:en,resumeen:en,extracto:es,resumen:es, resumees:es,resumo:pt,resumept:pt,riassunto:it,resumeit:it,zusammenfassung:de,resumede:de,resumeru:ru', 'mltext', 'dc.description', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 16, '', 'display', '5', 8, '', 32, 50, '2008-04-08 14:29:18', ''),
(51, 'titre', 40, 'publications', 'Titre de la publication', '', 'title, titre, titleuser, heading', 'text', 'dc.title', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', 16, '', 'editable', '', 8, '', 32, 2, '2006-07-05 18:07:28', ''),
(52, 'surtitre', 40, 'publications', 'Surtitre de la publication', '', 'surtitre', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', 16, '', 'importable', '', 8, '', 32, 1, '2006-07-10 16:08:07', ''),
(53, 'soustitre', 40, 'publications', 'Sous-titre de la publication', '', 'soustitre', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', 16, '', 'editable', '', 8, '', 32, 3, '2006-07-10 16:08:22', ''),
(54, 'commentaireinterne', 11, 'publications', 'Commentaire interne sur la publication', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', 64, '', 'editable', '4', 0, '', 32, 54, '2006-07-10 16:17:37', ''),
(55, 'prioritaire', 11, 'publications', 'Cette publication est-elle prioritaire ?', '', '', 'boolean', '', '*', '', '', '', 16, '', 'editable', '', 0, '', 32, 55, '2006-07-10 16:17:49', ''),
(57, 'datepubli', 12, 'publications', 'Date de publication électronique', '', '', 'date', 'dc.date', '*', 'today', '', '', 16, '', 'editable', '', 0, '', 32, 2, '2006-07-10 16:16:10', ''),
(58, 'datepublipapier', 12, 'publications', 'Date de publication papier', '', '', 'date', '', '*', '', '', '', 16, '', 'editable', '', 0, '', 32, 3, '2006-07-10 16:16:18', ''),
(59, 'noticebiblio', 12, 'publications', 'Notice bibliographique décrivant la publication', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special', 64, '', 'importable', '', 0, '', 32, 4, '2007-10-18 17:03:43', ''),
(60, 'introduction', 13, 'publications', 'Introduction de la publication', '<r2r:ml lang="fr">Introduction de la publication</r2r:ml>', 'texte, standard, normal', 'mltext', 'dc.description', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 16, '', 'fckeditor', 'Simple,550,400', 8, '', 32, 60, '2008-01-30 12:24:49', ''),
(131, 'geographie', 15, 'textes', 'Index géographique', '', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', 0, '', 1, 110, '2006-03-02 02:00:04', ''),
(132, 'chrono', 15, 'textes', 'Index chronologique', '', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', 0, '', 1, 111, '2006-03-02 02:00:25', ''),
(62, 'ndlr', 13, 'publications', 'Note de la rédaction au sujet de la publication', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 64, '', 'fckeditor', '', 2, '', 32, 62, '2006-07-10 16:15:06', ''),
(63, 'historique', 13, 'publications', 'Historique de la publication', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 64, '', 'importable', '', 0, '', 32, 63, '2007-05-04 06:59:30', ''),
(64, 'periode', 12, 'publications', 'Période de publication', '', '', 'tinytext', '', '*', '', '', '', 16, '', 'importable', '', 0, '', 1, 5, '2007-10-11 10:35:59', ''),
(65, 'isbn', 12, 'publications', 'ISBN', '', '', 'tinytext', '', '*', '', '', '', 16, '', 'editable', '', 0, '', 1, 7, '2007-10-15 14:47:17', ''),
(66, 'paraitre', 11, 'publications', 'Cette publication est-elle à paraitre ?', '', '', 'boolean', '', '*', '', '', '', 32, '', 'editable', '', 0, '', 32, 66, '2006-07-10 16:18:03', ''),
(67, 'integralite', 11, 'publications', 'Cette publication en ligne est-elle intégrale ?', '', '', 'boolean', '', '*', '', '', '', 32, '', 'editable', '', 0, '', 32, 67, '2006-07-10 16:18:15', ''),
(68, 'numero', 12, 'publications', 'Numéro de la publication', '', '', 'tinytext', '', '*', '', '', '', 16, '', 'editable', '', 0, '', 32, 6, '2006-07-10 16:16:47', ''),
(69, 'motsclesen', 15, 'textes', 'Keywords index', '', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', 0, '', 32, 3, '2006-07-13 14:57:59', ''),
(70, 'role', 0, 'entities_auteurs', 'Role dans l\'élaboration du document', '', 'role,.role', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special', 64, '', 'editable', '', 0, '', 1, 7, '2007-11-23 10:24:41', ''),
(119, 'email', 30, 'individus', 'Courriel', '', '', 'email', '', '*', '', '', '', 16, '', 'editable', '', 4, '', 1, 3, '2006-06-22 18:11:49', ''),
(120, 'siteweb', 30, 'individus', 'Site web', '', '', 'url', '', '*', '', '', '', 16, '', 'editable', '', 0, '', 1, 4, '2006-07-13 14:09:52', ''),
(121, 'description', 30, 'individus', 'Description', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 16, '', 'fckeditor', 'Simple', 4, '', 1, 2, '2006-07-10 16:34:39', ''),
(76, 'titreoeuvre', 17, 'textes', 'Titre de l\'oeuvre commentée', '', 'titreoeuvre', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', 64, '', 'display', '', 4, '', 32, 2, '2007-10-05 16:51:39', ''),
(77, 'noticebibliooeuvre', 17, 'textes', 'Notice bibliographique de l\'oeuvre commentée', '', 'noticebibliooeuvre', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Appel de Note', 64, '', 'display', '', 4, '', 32, 1, '2007-10-05 16:52:02', ''),
(78, 'datepublicationoeuvre', 17, 'textes', 'Date de publication de l\'oeuvre commentée', '', 'datepublioeuvre', 'tinytext', '', '*', '', '', '', 64, '', 'display', '', 4, '', 32, 70, '2007-10-05 16:52:13', ''),
(79, 'auteuroeuvre', 17, 'textes', 'Auteur de l\'oeuvre commentée', '', '', 'persons', '', '', '', '', '', 64, '', 'editable', '', 0, '', 32, 71, '2007-11-23 11:03:26', ''),
(81, 'titre', 18, 'textessimples', 'Titre', '', '', 'tinytext', 'dc.title', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 16, '', 'editable', '', 4, '', 32, 72, '2006-06-27 23:50:07', ''),
(82, 'texte', 19, 'textessimples', 'Texte', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 16, '', 'fckeditor', 'Simple', 4, '', 1, 73, '2006-11-09 10:24:32', ''),
(83, 'ndla', 34, 'textes', 'Note de l\'auteur', '', 'ndla', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 64, '', 'importable', '', 2, '', 32, 2, '2006-03-08 17:48:24', ''),
(96, 'icone', 12, 'publications', 'Icône de la publication', '', '', 'image', '', '*', '', '', '', 16, '', 'none', '', 0, '', 32, 1, '2007-10-11 12:03:48', ''),
(97, 'icone', 33, 'textes', 'Icône du document', '', '', 'image', '', '*', '', '', '', 64, '', 'none', '', 0, '', 32, 88, '2007-10-11 12:04:21', ''),
(98, 'description', 38, 'fichiers', 'Description', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 16, '', 'fckeditor', 'Simple', 4, '', 32, 2, '2006-07-10 16:35:55', ''),
(99, 'alterfichier', 32, 'textes', 'Texte au format PDF', '', '', 'file', '', '*', '', '', '', 32, '', 'editable', '', 0, '', 32, 6, '2006-07-13 11:52:01', ''),
(104, 'langue', 12, 'publications', 'Langue de la publication', '', '', 'lang', 'dc.language', '*', 'fr', '', '', 64, '', 'editable', '', 0, '', 32, 8, '2006-03-06 11:52:49', ''),
(100, 'auteur', 24, 'fichiers', 'Auteur', '', '', 'persons', '', '', '', '', '', 64, '', 'editable', '', 0, '', 32, 91, '2006-03-07 17:09:58', ''),
(101, 'auteur', 25, 'liens', 'Auteur de la notice décrivant ce site', '', '', 'persons', '', '', '', '', '', 64, '', 'editable', '', 0, '', 32, 92, '2005-06-16 12:01:32', ''),
(102, 'capturedecran', 36, 'liens', 'Capture d\'écran du site', '', '', 'image', '', '*', '', '', '', 16, '', 'editable', '', 0, '', 32, 3, '2006-06-22 17:57:46', ''),
(103, 'auteur', 26, 'textessimples', 'Auteur', '', '', 'persons', '', '', '', '', '', 64, '', 'editable', '', 0, '', 32, 93, '2006-02-21 23:58:53', ''),
(105, 'numerodocument', 31, 'textes', 'Numéro du document', '', 'numerodocument,numrodudocument', 'number', '', '*', '', '', '', 64, '', 'editable', '', 0, '', 32, 1, '2006-12-05 16:09:34', ''),
(112, 'nom', 28, 'individus', 'Nom', '', '', 'tinytext', 'dc.title', '*', '', '', '', 16, '', 'editable', '', 4, '', 1, 1, '2006-06-22 18:00:21', ''),
(113, 'prenom', 28, 'individus', 'Prénom', '', '', 'tinytext', '', '*', '', '', '', 16, '', 'editable', '', 4, '', 1, 2, '2006-06-22 18:00:32', ''),
(122, 'accroche', 28, 'individus', 'Accroche', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 16, '', 'fckeditor', 'Simple', 4, '', 1, 3, '2006-07-10 16:34:23', ''),
(123, 'adresse', 30, 'individus', 'Adresse', '', '', 'text', '', '*', '', '', '', 16, '', 'editable', '3', 4, '', 1, 102, '2006-07-10 16:35:02', ''),
(124, 'telephone', 30, 'individus', 'Téléphone', '', '', 'tinytext', '', '*', '', '', '', 16, '', 'editable', '', 4, '', 1, 103, '2006-07-10 16:35:10', ''),
(125, 'photographie', 28, 'individus', 'Photographie', '', '', 'image', '', '*', '', '', '', 16, '', 'editable', '', 0, '', 1, 104, '2006-06-22 18:00:58', ''),
(141, 'vignette', 38, 'fichiers', 'Vignette', '', '', 'image', '', '*', '', '', '', 16, '', 'editable', '', 0, '', 32, 3, '2006-06-22 22:53:54', ''),
(127, 'directeurdelapublication', 12, 'publications', 'Directeur de la publication', '', '', 'persons', '', '', '', '', '', 64, '', 'editable', '', 0, '', 1, 10, '2006-03-06 11:52:49', ''),
(128, 'legende', 38, 'fichiers', 'Légende', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', 16, '', 'fckeditor', 'Basic', 4, '', 1, 4, '2007-10-18 17:12:43', ''),
(129, 'credits', 24, 'fichiers', 'Crédits', '', '', 'tinytext', '', '*', '', '', '', 16, '', 'editable', '', 4, '', 1, 108, '2006-06-22 22:54:27', ''),
(133, 'theme', 15, 'textes', 'Index thématique', '', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', 0, '', 1, 112, '2006-03-02 02:00:43', ''),
(139, 'licence', 12, 'publications', 'Licence portant sur la publication', '', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', 0, '', 1, 9, '2006-03-06 11:52:49', ''),
(134, 'nom', 0, 'indexavances', 'Dénomination de l\'entrée d\'index', '', '', 'tinytext', 'index key', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block', 16, '', 'editable', '', 4, '', 1, 113, '2006-07-10 17:19:09', ''),
(135, 'description', 0, 'indexavances', 'Description de l\'entrée d\'index', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 16, '', 'fckeditor', 'Basic', 4, '', 1, 114, '2006-07-10 17:17:29', ''),
(136, 'url', 0, 'indexavances', 'URL', '', '', 'url', '', '*', '', '', '', 16, '', 'editable', '', 0, '', 1, 115, '2006-07-10 17:17:43', ''),
(137, 'icone', 0, 'indexavances', 'Icône', '', '', 'image', '', '*', '', '', '', 16, '', 'editable', '', 0, '', 1, 116, '2006-07-10 17:17:52', ''),
(138, 'licence', 33, 'textes', 'Licence portant sur le document', '', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', 0, '', 1, 117, '2006-03-06 11:37:12', ''),
(143, 'notefin', 32, 'textes', 'Notes de fin de document', '', 'notefin', 'longtext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', 32, '', 'importable', '', 4, '', 32, 3, '2007-12-13 12:18:54', ''),
(144, 'altertitre', 40, 'publications', 'Titre alternatif de la publication (dans une autre langue)', '', 'titretraduitfr:fr,titretraduiten:en,titretraduites:es,titretraduitpt:pt,titretraduitit:it,titretraduitde:de,titretraduitru:ru,titleen:en', 'mltext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Appel de Note', 32, '', 'editable', '', 4, '', 1, 120, '2006-12-05 16:38:54', ''),
(147, 'motscleses', 15, 'textes', 'Palabras claves', '', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', 0, '', 1, 121, '2007-09-28 11:43:37', ''),
(148, 'motsclesde', 15, 'textes', 'Schlagwortindex', '', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', 0, '', 1, 122, '2008-01-28 10:01:28', ''),
(149, 'urlpublicationediteur', 13, 'publications', 'Voir sur le site de l\'éditeur', '', '', 'url', '', '*', '', '', '', 32, '', 'editable', '', 0, '', 1, 123, '2007-10-11 11:00:55', ''),
(150, 'nombremaxitems', 36, 'liens', 'Nombre maximum d\'items du flux', '', '', 'int', '', '*', '', '', '', 16, '', 'editable', '', 0, '', 32, 124, '2007-10-11 11:14:13', ''),
(151, 'descriptionouvrage', 12, 'publications', 'Description physique de l\'ouvrage', '', '', 'text', '', '*', '', '', '', 64, '', 'editable', '', 0, '', 32, 125, '2007-10-18 17:05:20', ''),
(152, 'site', 0, 'entities_auteurs', 'Site', '', 'site, .site', 'url', '', '*', '', '', '', 32, '', 'editable', '', 4, '', 1, 6, '2007-11-23 10:24:41', ''),
(153, 'erratum', 13, 'publications', 'Erratum au sujet de la publication', '', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note;texte Lodel;Sections', 64, '', '', '', 0, '', 32, 2, '2009-07-06 17:09:42', ''),
(154, 'racinemets', 11, 'publications', 'Racine METS', '', '', 'boolean', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note;texte Lodel;Sections;0', 64, '', 'editable', '', 0, '', 32, 6, '2009-07-06 17:09:42', ''),
(155, 'oaireferenced', 11, 'publications', 'Référencé par l\'OAI', '', '', 'boolean', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note;texte Lodel;Sections;0', 64, '', 'editable', '', 0, '', 1, 5, '2009-07-06 17:09:42', ''),
(156, 'droitsauteur', 33, 'textes', 'Droits d\'auteur', '', 'droitsauteur', 'tinytext', '', '*', 'Propriété intellectuelle', '', '', 64, '', 'text', '', 0, 'Droits relatifs au document.', 32, 6, '2009-07-06 17:09:42', ''),
(157, 'erratum', 34, 'textes', 'Erratum', '', 'erratum', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note;texte Lodel;Sections', 64, '', '', '', 0, '', 32, 9, '2009-07-06 17:09:42', ''),
(158, 'historique', 16, 'textes', 'Historique', '', 'historique', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note;texte Lodel;Sections', 64, '', '', '', 0, '', 32, 11, '2009-07-06 17:09:42', ''),
(159, 'fichiersassocies', 16, 'textes', 'Fichiers associés au document', '', '', 'file', '', '*', '', '', '', 64, '', '', '', 0, 'Ce champ est un champ utilisé en interne par Lodel. Ne pas le modifier.', 32, 1, '2009-07-06 17:09:42', ''),
(160, 'fichiersource', 16, 'textes', 'Fichier source', '', '', 'file', '', '*', '', '', '', 64, '', '', '', 0, '', 32, 5, '2009-07-06 17:09:42', ''),
(161, 'importversion', 16, 'textes', 'Version de l\'importation', '', '', 'tinytext', '', '*', '', '', '', 64, '', '', '', 0, '', 32, 6, '2009-07-06 17:09:42', ''),
(162, 'lien', 16, 'textes', 'Lien pour les documents annexes', '', '', 'tinytext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note;texte Lodel;Sections;0', 64, '', '', '', 0, 'Lien pour les documents annexes', 1, 8, '2009-07-06 17:09:42', ''),
(163, 'oaireferenced', 16, 'textes', 'Référencé par l\'OAI', '', '', 'boolean', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note;texte Lodel;Sections', 64, '', 'editable', '', 0, '', 1, 9, '2009-07-06 17:09:42', '');

#
# Dumping data for table 'tablefieldgroups'
#

INSERT INTO #_TP_tablefieldgroups (id, name, class, title, altertitle, comment, status, rank, upd) VALUES (31, 'grtitre', 'textes', 'Titres', '', '', 1, 1, '2006-03-01 19:12:59'),
(32, 'grtexte', 'textes', 'Texte', '', '', 1, 3, '2006-03-01 19:13:36'),
(33, 'grmeta', 'textes', 'Métadonnées', '', '', 1, 4, '2006-03-01 19:15:52'),
(34, 'graddenda', 'textes', 'Addenda', '', '', 1, 5, '2006-03-01 19:16:00'),
(35, 'grtitre', 'liens', 'Titre', '', '', 1, 5, '2006-02-21 22:33:20'),
(36, 'grsite', 'liens', 'Définition du site', '', '', 1, 6, '2006-02-21 22:40:34'),
(37, 'grtitre', 'fichiers', 'Titre', '', '', 1, 7, '2006-03-07 17:09:58'),
(38, 'grmultimedia', 'fichiers', 'Définition', '', '', 1, 8, '2006-03-07 17:09:58'),
(39, 'grresumes', 'textes', 'Résumés', '', '', 1, 2, '2006-03-01 19:12:46'),
(40, 'grtitre', 'publications', 'Groupe de titre', '', '', 32, 1, '2005-06-16 11:50:10'),
(11, 'grgestion', 'publications', 'Gestion des publications', '', '', 1, 4, '2006-02-27 22:47:22'),
(12, 'grmetadonnees', 'publications', 'Groupe des métadonnées', '', '', 32, 3, '2006-02-27 22:47:22'),
(13, 'graddenda', 'publications', 'Groupe des addenda', '', '', 32, 2, '2006-02-27 22:47:17'),
(14, 'grpersonnes', 'textes', 'Auteurs', '', '', 1, 7, '2006-03-01 19:16:28'),
(15, 'grindex', 'textes', 'Index', '', '', 1, 6, '2006-03-01 19:16:09'),
(16, 'grgestion', 'textes', 'Gestion du document', '', '', 1, 9, '2006-03-01 19:16:42'),
(17, 'grrecension', 'textes', 'Oeuvre commentée (si ce document est un compte-rendu d\'oeuvre ou d\'ouvrage...)', '', '', 1, 8, '2005-06-19 16:00:22'),
(18, 'grtitre', 'textessimples', 'Titre', '', '', 1, 10, '2006-02-21 23:58:18'),
(19, 'grtexte', 'textessimples', 'Texte', '', '', 1, 11, '2006-02-21 23:58:18'),
(24, 'grdroits', 'fichiers', 'Droits', '', '', 32, 16, '2006-03-07 17:09:58'),
(25, 'grauteurs', 'liens', 'Auteurs', '', '', 32, 17, '2006-02-21 22:33:36'),
(26, 'grauteurs', 'textessimples', 'Auteurs', '', '', 32, 18, '2006-02-21 23:58:18'),
(28, 'grtitre', 'individus', 'Titre', '', '', 1, 20, '2006-02-22 09:54:12'),
(30, 'grdescription', 'individus', 'Description', '', '', 1, 21, '2006-02-22 09:54:12');

#
# Dumping data for table 'types'
#

INSERT INTO #_TP_types (id, icon, type, title, altertitle, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, public, gui_user_complexity, oaireferenced, rank, status, upd) VALUES (7209, '', 'editorial', 'Editorial', '', 'textes', 'article', 'entities', '', 1, '', -1, 1, 0, 32, 1, 1, 32, '2009-07-06 17:08:48'),
(7210, '', 'article', 'Article', '', 'textes', 'article', 'entities', '', 1, '', -1, 1, 0, 16, 1, 2, 1, '2009-07-06 17:08:48'),
(7211, '', 'actualite', 'Annonce et actualité', '', 'textes', 'article', 'entities', '', 1, '', -1, 1, 0, 32, 0, 3, 32, '2009-07-06 17:08:48'),
(7212, '', 'compterendu', 'Compte-rendu', '', 'textes', 'article', 'entities', '', 1, '', -1, 1, 0, 32, 1, 5, 32, '2009-07-06 17:08:48'),
(7213, '', 'notedelecture', 'Note de lecture', '', 'textes', 'article', 'entities', '', 1, '', -1, 1, 0, 64, 1, 6, 32, '2009-07-06 17:08:48'),
(7214, '', 'informations', 'Informations pratiques', '', 'textes', 'article', 'entities', '', 1, '', -1, 1, 0, 32, 0, 7, 32, '2009-07-06 17:08:48'),
(7215, '', 'chronique', 'Chronique', '', 'textes', 'article', 'entities', '', 1, '', -1, 1, 0, 64, 0, 8, 32, '2009-07-06 17:08:48'),
(7216, '', 'collection', 'Collection', '', 'publications', 'sommaire', 'entities', 'edition', 0, '', -1, 1, 0, 16, 0, 1, 32, '2009-07-06 17:08:48'),
(7217, 'lodel/icons/volume.gif', 'numero', 'Numéro de revue', '', 'publications', 'sommaire', 'entities', 'edition', 0, '', -1, 1, 0, 32, 0, 3, 32, '2009-07-06 17:08:48'),
(7218, 'lodel/icons/rubrique.gif', 'rubrique', 'Rubrique', '', 'publications', 'sommaire', 'entities', 'edition', 0, '', -1, 1, 0, 16, 0, 5, 32, '2009-07-06 17:08:48'),
(7219, 'lodel/icons/rubrique_plat.gif', 'souspartie', 'Sous-partie', '', 'publications', '', 'entities', 'edition', 0, 'unfolded', -1, 1, 0, 16, 0, 6, 1, '2009-07-15 14:38:30'),
(7220, '', 'image', 'Image', '', 'fichiers', 'image', 'entities', '', 0, '', -1, 1, 0, 64, 1, 1, 1, '2009-07-06 17:08:48'),
(7221, '', 'noticedesite', 'Notice de site', '', 'liens', 'lien', 'entities', '', 0, '', -1, 1, 0, 64, 0, 16, 1, '2009-07-06 17:08:48'),
(7222, 'lodel/icons/commentaire.gif', 'commentaire', 'Commentaire du document', '', 'textessimples', '', 'entities', '', 0, 'advanced', -1, 1, 1, 16, 0, 2, 1, '2009-07-06 17:08:48'),
(7233, '', 'videoannexe', 'Vidéo placée en annexe', '', 'fichiers', '', 'entities', 'edition', 0, 'advanced', -1, 1, 0, 64, 0, 4, 1, '2009-07-06 17:08:48'),
(7228, '', 'annuairedequipe', 'Équipe', '', 'publications', 'sommaire', 'entities', 'edition', 0, '', -1, 1, 0, 16, 0, 8, 32, '2009-07-06 17:08:48'),
(7229, '', 'annuairemedias', 'Médiathèque', '', 'publications', 'sommaire', 'entities', 'edition', 0, '', -1, 1, 0, 16, 0, 9, 32, '2009-07-06 17:08:48'),
(7223, '', 'image_annexe', 'Image placée en annexe', '', 'fichiers', '', 'entities', '', 0, 'advanced', -1, 1, 0, 64, 0, 2, 1, '2009-07-06 17:08:48'),
(7224, '', 'lienannexe', 'Lien placé en annexe', '', 'liens', 'lien', 'entities', '', 0, 'advanced', -1, 1, 0, 64, 0, 24, 1, '2009-07-06 17:08:48'),
(7225, '', 'individu', 'Notice biographique de membre', '', 'individus', 'individu', 'entities', '', 0, '', -1, 1, 0, 16, 0, 25, 1, '2009-07-06 17:08:48'),
(7226, '', 'billet', 'Billet', '', 'textessimples', 'article', 'entities', '', 0, '', -1, 1, 0, 16, 0, 1, 1, '2009-07-06 17:08:48'),
(7227, '', 'annuairedesites', 'Annuaire de sites', '', 'publications', 'sommaire', 'entities', 'edition', 0, '', -1, 1, 0, 16, 0, 7, 32, '2009-07-06 17:08:48'),
(7230, 'lodel/icons/rss.gif', 'fluxdesyndication', 'Flux de syndication', '', 'liens', 'lien', 'entities', '', 0, '', -1, 1, 0, 64, 0, 30, 1, '2009-07-06 17:08:48'),
(7231, '', 'video', 'Vidéo', '', 'fichiers', '', 'entities', '', 0, '', -1, 1, 0, 64, 0, 3, 1, '2009-07-06 17:08:48'),
(7232, '', 'son', 'Document sonore', '', 'fichiers', '', 'entities', '', 0, '', -1, 1, 0, 32, 0, 5, 1, '2009-07-06 17:08:48'),
(7234, '', 'fichierannexe', 'Fichier placé en annexe', '', 'fichiers', 'image', 'entities', '', 0, 'advanced', -1, 1, 0, 32, 0, 7, 1, '2009-07-06 17:08:48'),
(7235, '', 'sonannexe', 'Document sonore placé en annexe', '', 'fichiers', '', 'entities', '', 0, 'advanced', -1, 1, 0, 32, 0, 6, 1, '2009-07-06 17:08:48'),
(7237, '', 'imageaccroche', 'Image d\'accroche', '', 'fichiers', 'image', 'entities', '', 0, 'advanced', -1, 1, 0, 16, 0, 31, 32, '2009-07-06 17:08:48'),
(7238, 'lodel/icons/rubrique.gif', 'rubriqueannuaire', 'Rubrique (d\'annuaire de site)', '', 'publications', 'sommaire', 'entities', 'edition', 0, '', -1, 1, 0, 16, 0, 32, 32, '2009-07-06 17:08:48'),
(7239, '', 'rubriquemediatheque', 'Rubrique (de médiathèque)', '', 'publications', 'sommaire', 'entities', 'edition', 0, '', -1, 1, 0, 16, 0, 33, 32, '2009-07-06 17:08:48'),
(7240, 'lodel/icons/rubrique.gif', 'rubriqueequipe', 'Rubrique (d\'équipe)', '', 'publications', 'sommaire', 'entities', 'edition', 0, 'unfolded', -1, 1, 0, 16, 0, 34, 32, '2009-07-06 17:08:48'),
(7236, 'lodel/icons/rubrique.gif', 'rubriqueactualites', 'Rubrique (d\'actualités)', '', 'publications', 'sommaire', 'entities', 'edition', 0, '', -1, 1, 0, 16, 0, 35, 32, '2009-07-06 17:08:48'),
(7207, '', 'regroupement-documentsannexes', 'Regroupement de documents annexes', '', 'publications', '', 'creation-regroupement', '', 0, '', -1, 1, 0, 64, 0, 7, 1, '2009-07-02 15:45:21'),
(7208, '', 'objetdelarecension', 'Objet de la recension', '', 'textes', 'article', 'document', '', 1, '', -1, 1, 0, 64, 0, 21, 1, '2009-07-06 17:05:12');

#
# Dumping data for table 'persontypes'
#

INSERT INTO #_TP_persontypes (id, icon, type, title, altertitle, class, style, g_type, tpl, tplindex, gui_user_complexity, rank, status, upd) VALUES (7249, 'lodel/icons/auteur.gif', 'auteur', 'Auteur', '', 'auteurs', 'auteur', 'dc.creator', 'personne', 'personnes', 32, 1, 1, '2009-07-06 17:08:48'),
(7250, '', 'traducteur', 'Traducteur', '', 'auteurs', 'traducteur', 'dc.contributor', 'personne', 'personnes', 64, 2, 1, '2009-07-06 17:08:48'),
(7251, '', 'directeurdelapublication', 'Directeur de la publication', '', 'auteurs', 'directeur', '', 'personne', 'personnes', 32, 3, 32, '2009-07-06 17:08:48'),
(7252, '', 'auteuroeuvre', 'Auteur d\'une oeuvre commentée', '', 'auteurs', 'auteuroeuvre', '', 'personne', 'personnes', 64, 4, 32, '2009-07-06 17:08:48'),
(7253, '', 'editeurscientifique', 'Éditeur scientifique', '', 'auteurs', 'editeurscientifique', '', 'personne', 'personnes', 64, 5, 1, '2009-07-06 17:08:48');

#
# Dumping data for table 'entrytypes'
#

INSERT INTO #_TP_entrytypes (id, icon, type, class, title, altertitle, style, g_type, tpl, tplindex, gui_user_complexity, rank, status, flat, newbyimportallowed, edition, sort, upd, lang) VALUES (7241, '', 'motsclesfr', 'indexes', 'Index de mots-clés', '', 'motscles, .motcles,motscls,motsclesfr', 'dc.subject', 'entree', 'entrees', 32, 1, 1, 1, 1, 'pool', 'sortkey', '2009-07-06 17:08:48', 'fr'),
(7242, '', 'motsclesen', 'indexes', 'Index by keyword', '', 'keywords,motclesen', '', 'entree', 'entrees', 64, 2, 1, 1, 1, 'pool', 'sortkey', '2009-07-06 17:09:42', 'en'),
(7244, '', 'chrono', 'indexes', 'Index chronologique', '', 'periode, .periode, priode', '', 'entree', 'entrees', 64, 5, 1, 0, 1, 'pool', 'sortkey', '2009-07-06 17:08:48', 'fr'),
(7245, '', 'theme', 'indexes', 'Index thématique', '', 'themes,thmes,.themes', '', 'entree', 'entrees', 16, 6, 1, 0, 1, 'pool', 'sortkey', '2009-07-06 17:08:48', 'fr'),
(7243, '', 'geographie', 'indexes', 'Index géographique', '', 'geographie, gographie,.geographie', '', 'entree', 'entrees', 64, 4, 1, 0, 1, 'pool', 'sortkey', '2009-07-06 17:08:48', 'fr'),
(7248, '', 'motscleses', 'indexes', 'Indice de palabras clave', '', 'palabrasclaves, .palabrasclaves, motscleses', '', 'entree', 'entrees', 64, 9, 1, 1, 1, 'pool', 'sortkey', '2009-07-06 17:09:42', 'es'),
(7246, '', 'licence', 'indexavances', 'Licence portant sur le document', '', 'licence, droitsauteur', 'dc.rights', 'entree', 'entrees', 16, 7, 1, 1, 1, 'select', 'rank', '2009-07-06 17:08:48', 'fr'),
(7247, '', 'motsclesde', 'indexes', 'Schlagwortindex', '', 'schlusselworter, .schlusselworter, motsclesde, schlagworter, .schlagworter', '', 'entree', 'entrees', 32, 8, 1, 1, 1, 'pool', 'sortkey', '2009-07-06 17:09:42', 'de');

#
# Dumping data for table 'entitytypes_entitytypes'
#

INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES (7216, 0, '*'),
(7219, 7218, '*'),
(7219, 7217, '*'),
(7209, 7218, '*'),
(7210, 7238, '*'),
(7210, 7218, '*'),
(7211, 7239, '*'),
(7228, 7216, '*'),
(7211, 7219, '*'),
(7211, 7238, '*'),
(7211, 7236, '*'),
(7211, 7218, '*'),
(7229, 7218, '*'),
(7212, 7219, '*'),
(7212, 7239, '*'),
(7212, 7238, '*'),
(7213, 7219, '*'),
(7214, 7216, '*'),
(7214, 7229, '*'),
(7214, 7227, '*'),
(7214, 7228, '*'),
(7215, 7217, '*'),
(7215, 7216, '*'),
(7215, 7229, '*'),
(7215, 7227, '*'),
(7234, 7214, '*'),
(7222, 7213, '*'),
(7221, 7219, '*'),
(7221, 7238, '*'),
(7221, 7218, '*'),
(7228, 0, '*'),
(7222, 7214, '*'),
(7222, 7209, '*'),
(7222, 7212, '*'),
(7222, 7215, '*'),
(7234, 7209, '*'),
(7209, 7217, '*'),
(7217, 7216, '*'),
(7209, 7216, '*'),
(7209, 7229, '*'),
(7210, 7217, '*'),
(7222, 7210, '*'),
(7222, 7211, '*'),
(7222, 7221, '*'),
(7220, 7219, '*'),
(7220, 7218, '*'),
(7227, 7218, '*'),
(7227, 7216, '*'),
(7222, 7220, '*'),
(7234, 7212, '*'),
(7233, 7226, '*'),
(7233, 7214, '*'),
(7233, 7213, '*'),
(7233, 7209, '*'),
(7233, 7212, '*'),
(7233, 7215, '*'),
(7233, 7210, '*'),
(7233, 7211, '*'),
(7210, 7216, '*'),
(7213, 7239, '*'),
(7227, 0, '*'),
(7220, 7217, '*'),
(7221, 7217, '*'),
(7223, 7213, '*'),
(7223, 7214, '*'),
(7223, 7209, '*'),
(7223, 7212, '*'),
(7223, 7215, '*'),
(7223, 7210, '*'),
(7223, 7211, '*'),
(7224, 7214, '*'),
(7224, 7209, '*'),
(7224, 7212, '*'),
(7224, 7215, '*'),
(7224, 7210, '*'),
(7224, 7211, '*'),
(7224, 7219, '*'),
(7229, 7216, '*'),
(7226, 7239, '*'),
(7229, 0, '*'),
(7230, 7219, '*'),
(7230, 7238, '*'),
(7230, 7218, '*'),
(7230, 7217, '*'),
(7230, 7216, '*'),
(7225, 7218, '*'),
(7231, 7219, '*'),
(7231, 7218, '*'),
(7232, 7219, '*'),
(7232, 7218, '*'),
(7232, 7217, '*'),
(7234, 7215, '*'),
(7234, 7210, '*'),
(7234, 7211, '*'),
(7234, 7218, '*'),
(7234, 7217, '*'),
(7235, 7226, '*'),
(7235, 7213, '*'),
(7235, 7214, '*'),
(7235, 7209, '*'),
(7235, 7212, '*'),
(7235, 7215, '*'),
(7235, 7210, '*'),
(7235, 7211, '*'),
(7225, 7228, '*'),
(7230, 7239, '*'),
(7221, 7239, '*'),
(7232, 7239, '*'),
(7218, 7218, '*'),
(7218, 7216, '*'),
(7226, 7238, '*'),
(7231, 7217, '*'),
(7231, 7229, '*'),
(7232, 7229, '*'),
(7220, 7216, '*'),
(7220, 7229, '*'),
(7226, 7218, '*'),
(7226, 7217, '*'),
(7221, 7216, '*'),
(7221, 7229, '*'),
(7230, 7229, '*'),
(7230, 7227, '*'),
(7226, 7216, '*'),
(7226, 7229, '*'),
(7226, 7227, '*'),
(7212, 7218, '*'),
(7213, 7238, '*'),
(7224, 7218, '*'),
(7224, 7217, '*'),
(7234, 7213, '*'),
(7234, 7226, '*'),
(7237, 7214, '*'),
(7237, 7209, '*'),
(7237, 7212, '*'),
(7237, 7215, '*'),
(7237, 7210, '*'),
(7237, 7211, '*'),
(7237, 7239, '*'),
(7237, 7240, '*'),
(7237, 7219, '*'),
(7237, 7238, '*'),
(7237, 7218, '*'),
(7237, 7217, '*'),
(7237, 7216, '*'),
(7237, 7229, '*'),
(7237, 7227, '*'),
(7237, 7228, '*'),
(7237, 7221, '*'),
(7237, 7230, '*'),
(7230, 7228, '*'),
(7238, 7227, '*'),
(7238, 7238, '*'),
(7239, 7239, '*'),
(7239, 7229, '*'),
(7240, 7228, '*'),
(7240, 7240, '*'),
(7221, 7227, '*'),
(7230, 0, '*'),
(7209, 7227, '*'),
(7210, 7229, '*'),
(7210, 7227, '*'),
(7211, 7217, '*'),
(7211, 7216, '*'),
(7211, 7229, '*'),
(7211, 7227, '*'),
(7209, 7238, '*'),
(7209, 7219, '*'),
(7209, 7239, '*'),
(7210, 7219, '*'),
(7210, 7239, '*'),
(7212, 7217, '*'),
(7212, 7216, '*'),
(7212, 7229, '*'),
(7212, 7227, '*'),
(7213, 7218, '*'),
(7213, 7217, '*'),
(7213, 7216, '*'),
(7213, 7229, '*'),
(7213, 7227, '*'),
(7215, 7218, '*'),
(7215, 7238, '*'),
(7215, 7219, '*'),
(7215, 7239, '*'),
(7220, 7239, '*'),
(7231, 7239, '*'),
(7226, 7228, '*'),
(7226, 0, '*'),
(7225, 7240, '*'),
(7237, 7213, '*'),
(7237, 7226, '*'),
(7237, 7222, '*'),
(7236, 7216, '*'),
(7226, 7219, '*'),
(7224, 7213, '*'),
(7207, 7214, '*'),
(7207, 7213, '*'),
(7207, 7212, '*'),
(7207, 7215, '*'),
(7207, 7210, '*'),
(7234, 7207, '*'),
(7224, 7207, '*'),
(7208, 7210, '*'),
(7219, 7219, '*');

#
# Dumping data for table 'characterstyles'
#


#
# Dumping data for table 'internalstyles'
#

INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES (1, 'citation', '*-', '<blockquote>', 0, 1, 1, '2005-09-01 15:12:36'),
(2, 'quotations', '*-', '<blockquote>', 0, 2, 1, '2005-09-01 15:12:41'),
(3, 'citationbis', '*-', '<blockquote class="citationbis">', 0, 3, 1, '2005-03-10 18:49:50'),
(4, 'citationter', '*-', '<blockquote class="citationter">', 0, 4, 1, '2005-03-10 18:50:12'),
(5, 'titreillustration', '*-', '', 0, 5, 1, '2005-03-10 18:51:50'),
(6, 'legendeillustration', '*-', '', 0, 6, 1, '2005-03-10 18:52:07'),
(7, 'titredoc', '*-', '', 0, 7, 1, '2005-03-10 18:52:25'),
(8, 'legendedoc', '*-', '', 0, 8, 1, '2005-03-10 18:52:34'),
(9, 'puces', '*-', '<ul><li>', 0, 9, 1, '2005-03-10 18:53:04'),
(10, 'code', '*-', '', 0, 10, 1, '2005-03-10 18:53:41'),
(11, 'question', '*-', '', 0, 11, 1, '2005-03-10 18:54:17'),
(12, 'reponse', '*-', '', 0, 12, 1, '2005-04-29 17:12:51'),
(20, 'separateur', '*-', '<hr style="style">', 0, 19, 1, '2005-09-01 15:13:07'),
(19, 'section1', '-*', '<h1>', 0, 13, 1, '2006-03-02 09:51:26'),
(15, 'section3', '*-', '<h3>', 0, 15, 1, '2005-04-29 17:13:02'),
(16, 'section4', '*-', '<h4>', 0, 16, 1, '2005-04-29 17:13:00'),
(17, 'section5', '*-', '<h5>', 0, 17, 1, '2005-04-29 17:12:42'),
(18, 'section6', '*-', '<h6>', 0, 18, 1, '2005-04-29 17:12:37'),
(21, 'paragraphesansretrait', '*-', '', 0, 20, 1, '2005-05-24 22:24:39'),
(22, 'epigraphe', '*-', '', 0, 21, 1, '2005-05-24 22:24:28'),
(23, 'section2', '-*', '<h2>', 0, 14, 1, '2006-03-02 09:51:32'),
(24, 'pigraphe', '-*', '', 0, 22, 1, '2005-05-24 22:24:50'),
(25, 'sparateur', '-*', '', 0, 23, 1, '2005-05-24 22:25:07'),
(26, 'quotation', '-*', '<blockquote>', 0, 24, 1, '2005-09-01 15:12:53'),
(27, 'terme', '-*', '', 0, 25, 1, '2006-03-02 09:52:27'),
(28, 'definitiondeterme', '-*', '', 0, 26, 1, '2006-03-02 09:52:37'),
(29, 'bibliographieannee', '-*', '', 0, 27, 1, '2006-03-05 14:50:25'),
(30, 'bibliographieauteur', 'bibliographie', '', 0, 28, 1, '2006-03-02 09:55:15'),
(31, 'bibliographiereference', 'bibliographie', '', 0, 29, 1, '2006-03-02 09:55:37'),
(32, 'creditillustration,crditillustration,creditsillustration,crditsillustration', '-*', '', 0, 30, 1, '2006-12-05 16:36:15'),
(33, 'remerciements', '-*', '', 0, 31, 1, '2006-12-05 16:14:33');
DELETE FROM #_TP_optiongroups;
# # Database: 'lodelmignot09_test-maquette-bleue'# 
#
# Dumping data for table 'optiongroups'
#

INSERT INTO #_TP_optiongroups (id, idparent, name, title, altertitle, comment, logic, exportpolicy, rank, status, upd) VALUES (1, 0, 'servoo', 'Servoo', '', '', 'servooconf', 1, 1, 32, '2006-12-08 09:50:17'),
(2, 0, 'metadonneessite', 'Métadonnées du site', '', '', '', 1, 2, 1, '2005-03-12 11:28:15'),
(5, 0, 'oai', 'OAI', '', '', '', 1, 5, 1, '2006-12-08 09:50:40');
DELETE FROM #_TP_options;
# # Database: 'lodelmignot09_test-maquette-bleue'# 
#
# Dumping data for table 'options'
#

INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status, upd, edition, editionparams) VALUES (1, 1, 'url', 'url', 'tinytext', '', '', 40, 1, 32, '2007-10-16 15:00:08', 'editable', ''),
(2, 1, 'username', 'username', 'username', '', '', 40, 2, 32, '2007-10-16 14:51:20', 'editable', ''),
(3, 1, 'passwd', 'password', 'passwd', '', '', 40, 3, 32, '2007-10-16 15:00:18', '', ''),
(4, 2, 'titresite', 'Titre du site', 'tinytext', 'Titresite', '', 40, 1, 1, '2009-07-16 09:17:41', '', ''),
(5, 2, 'titresiteabrege', 'Titre abrégé du site', 'tinytext', 'Titre abrégé du site', '', 40, 3, 1, '2009-07-16 09:17:41', '', ''),
(6, 2, 'descriptionsite', 'Description du site', 'text', '', '', 40, 4, 1, '2009-07-15 16:32:05', 'textarea', ''),
(7, 2, 'urldusite', 'URL officielle du site', 'url', '', '', 40, 5, 1, '2009-07-15 16:24:20', 'editable', ''),
(9, 2, 'issn', 'ISSN', 'tinytext', '', '', 30, 6, 1, '2007-11-13 12:43:12', 'editable', ''),
(10, 2, 'editeur', 'Nom de l\'éditeur du site', 'tinytext', '', '', 30, 8, 1, '2009-07-15 16:24:20', '', ''),
(11, 2, 'adresseediteur', 'Adresse postale de l\'éditeur', 'text', '', '', 30, 9, 1, '2009-07-16 09:17:41', '', ''),
(12, 2, 'producteursite', 'Nom du producteur du site', 'tinytext', '', '', 30, 10, 1, '2009-07-15 16:24:20', '', ''),
(13, 2, 'diffuseursite', 'Nom du diffuseur du site', 'tinytext', '', '', 30, 11, 1, '2009-07-16 09:17:41', '', ''),
(14, 2, 'droitsauteur', 'Droits d\'auteur par défaut', 'tinytext', '', '', 30, 12, 1, '2009-07-15 16:32:05', '', ''),
(15, 2, 'directeurpublication', 'Nom du directeur de la publication', 'tinytext', '', '', 30, 13, 1, '2009-07-16 09:17:41', '', ''),
(16, 2, 'redacteurenchef', 'Nom du Rédacteur en chef', 'tinytext', '', '', 30, 14, 1, '2009-09-17 15:48:00', '', ''),
(17, 2, 'courrielwebmaster', 'Courriel du webmaster', 'email', '', '', 30, 15, 1, '2009-09-17 15:48:00', '', ''),
(18, 2, 'courrielabuse', 'Courriel abuse', 'tinytext', '', '', 40, 16, 1, '2009-07-16 09:17:41', 'editable', ''),
(19, 2, 'motsclesdusite', 'Mots clés décrivant le site (entre virgules)', 'text', '', '', 30, 17, 1, '2007-11-13 12:42:26', '', ''),
(23, 5, 'oai_allow', 'oai_allow', 'tinytext', '*', '', 40, 23, 1, '2006-07-13 15:29:01', 'editable', ''),
(24, 5, 'oai_deny', 'oai_deny', 'tinytext', '', '', 40, 24, 1, '2006-07-13 15:29:35', 'editable', ''),
(25, 5, 'oai_email', 'Email de l\'administrateur du dépôt', 'email', '', '', 40, 25, 32, '2006-12-08 10:02:06', 'editable', ''),
(26, 2, 'issn_electronique', 'ISSN électronique', 'tinytext', '', '', 30, 7, 32, '2008-01-10 15:37:09', 'editable', ''),
(27, 2, 'langueprincipale', 'Langue principale du site', 'lang', 'fr', '', 40, 18, 1, '2009-07-15 15:40:07', 'editable', ''),
(28, 2, 'soustitresite', 'Sous titre du site', 'tinytext', '', '', 40, 2, 1, '2007-11-13 12:43:18', 'editable', ''),
(14184, 2, 'typepublication', 'Type de publication', 'list', 'Revue', '', 40, 26, 1, '2009-10-13 23:01:12', 'select', 'Revue, Cahier, Monographies');
# # Database: 'lodelmignot09_test-maquette-bleue'# 
# --------------------------------------------------------

#
# Table structure for table 'textes'
#

DROP TABLE IF EXISTS #_TP_textes;
CREATE TABLE #_TP_textes (
  identity int(10) unsigned default NULL,
  surtitre text,
  titre text,
  soustitre text,
  langue char(5) default NULL,
  datepubli date default NULL,
  texte longtext,
  notesbaspage longtext,
  notefin longtext,
  bibliographie text,
  annexe text,
  droitsauteur tinytext,
  erratum text,
  ndlr text,
  historique text,
  pagination tinytext,
  noticebiblio text,
  commentaireinterne text,
  fichiersassocies tinytext,
  `resume` text,
  fichiersource tinytext,
  importversion tinytext,
  datepublipapier date default NULL,
  prioritaire tinyint(4) default NULL,
  icone tinytext,
  lien tinytext,
  URLessai tinytext,
  oaireferenced tinyint(1) default NULL,
  alterfichier tinytext,
  addendum text,
  ocr tinyint(4) default NULL,
  altertitre text,
  ndla text,
  numerodocument double default NULL,
  titreoeuvre text,
  noticebibliooeuvre text,
  dedicace text,
  documentcliquable tinyint(4) default NULL,
  datepublicationoeuvre tinytext,
  UNIQUE KEY identity (identity)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'publications'
#

DROP TABLE IF EXISTS #_TP_publications;
CREATE TABLE #_TP_publications (
  identity int(10) unsigned default NULL,
  titre text,
  soustitre text,
  texte text,
  meta text,
  `date` date default NULL,
  surtitre text,
  icone tinytext,
  introduction text,
  datepubli date default NULL,
  datepublipapier date default NULL,
  noticebiblio text,
  commentaireinterne text,
  erratum text,
  ndlr text,
  historique text,
  prioritaire tinyint(4) default NULL,
  racinemets tinyint(4) default NULL,
  oaireferenced tinyint(1) default NULL,
  paraitre tinyint(4) default NULL,
  integralite tinyint(4) default NULL,
  numero tinytext,
  langue varchar(5) default NULL,
  altertitre text,
  urlpublicationediteur text,
  descriptionouvrage text,
  isbn tinytext,
  periode tinytext,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'fichiers'
#

DROP TABLE IF EXISTS #_TP_fichiers;
CREATE TABLE #_TP_fichiers (
  identity int(10) unsigned default NULL,
  titre text,
  document tinytext,
  description text,
  legende text,
  credits tinytext,
  vignette tinytext,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'liens'
#

DROP TABLE IF EXISTS #_TP_liens;
CREATE TABLE #_TP_liens (
  identity int(10) unsigned default NULL,
  titre text,
  url text,
  urlfil text,
  texte text,
  capturedecran tinytext,
  nombremaxitems int(11) default NULL,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'textessimples'
#

DROP TABLE IF EXISTS #_TP_textessimples;
CREATE TABLE #_TP_textessimples (
  identity int(10) unsigned default NULL,
  titre tinytext,
  texte text,
  url text,
  `date` datetime default NULL,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'auteurs'
#

DROP TABLE IF EXISTS #_TP_auteurs;
CREATE TABLE #_TP_auteurs (
  idperson int(10) unsigned default NULL,
  nomfamille tinytext,
  prenom tinytext,
  UNIQUE KEY idperson (idperson),
  KEY index_idperson (idperson)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'entities_auteurs'
#

DROP TABLE IF EXISTS #_TP_entities_auteurs;
CREATE TABLE #_TP_entities_auteurs (
  idrelation int(10) unsigned default NULL,
  prefix tinytext,
  affiliation tinytext,
  fonction tinytext,
  description text,
  courriel text,
  role text,
  site text,
  UNIQUE KEY idrelation (idrelation),
  KEY index_idrelation (idrelation)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'indexes'
#

DROP TABLE IF EXISTS #_TP_indexes;
CREATE TABLE #_TP_indexes (
  identry int(10) unsigned default NULL,
  nom text,
  definition text,
  UNIQUE KEY identry (identry),
  KEY index_identry (identry)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'individus'
#

DROP TABLE IF EXISTS #_TP_individus;
CREATE TABLE #_TP_individus (
  identity int(10) unsigned default NULL,
  nom tinytext,
  prenom tinytext,
  email text,
  siteweb text,
  description text,
  accroche text,
  adresse text,
  telephone tinytext,
  photographie tinytext,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'indexavances'
#

DROP TABLE IF EXISTS #_TP_indexavances;
CREATE TABLE #_TP_indexavances (
  identry int(10) unsigned default NULL,
  nom tinytext,
  description text,
  url text,
  icone tinytext,
  UNIQUE KEY identry (identry),
  KEY index_identry (identry)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
