# <model>
# <lodelversion>0.8</lodelversion>
# <date>2005-05-12</date>
# <title>
# Modèle editorial de Revues.org
# </title>
# <description>
# Le modèle éditorial de Revues.org est destiné à la mise en ligne de revues en sciences humaines et sociales. La complexité de ce modèle lui permet de couvrir d'autres besoins, comme la mise en ligne de colloques par exemple. Le modèle distingue notamment le texte, la bibliographie, les annexes, les notes de bas de page (six niveaux différents), les résumés (six langues disponibles pour l'instant). Le modèle repose sur le stylage de documents Word qui sont importés par Lodel. Il faut donc utiliser un modèle de document word. L'ensemble des styles est décrit ici : http://www.lodel.org/document126.html. Ce modèle est compatible avec la version 0.8 de Lodel.
# </description>
# <author>
# Revues.org
# </author>
# <modelversion>
# 1.2
# </modelversion>
# </model>
#  
#------------

DELETE FROM #_TP_classes;
DELETE FROM #_TP_tablefields;
DELETE FROM #_TP_tablefieldgroups;
DELETE FROM #_TP_types;
DELETE FROM #_TP_persontypes;
DELETE FROM #_TP_entrytypes;
DELETE FROM #_TP_entitytypes_entitytypes;
DELETE FROM #_TP_characterstyles;
DELETE FROM #_TP_internalstyles;
# # Database: 'lodeldevelunstable_revorg08'# 
#
# Dumping data for table 'classes'
#

INSERT INTO #_TP_classes (id, class, title, classtype, comment, rank, status, upd) VALUES ('1', 'documents', 'Documents', 'entities', '', '1', '32', '20050310175807');
INSERT INTO #_TP_classes (id, class, title, classtype, comment, rank, status, upd) VALUES ('2', 'publications', 'Publications', 'entities', '', '2', '32', '20050310175900');
INSERT INTO #_TP_classes (id, class, title, classtype, comment, rank, status, upd) VALUES ('3', 'images', 'Images', 'entities', '', '3', '32', '20050310175855');
INSERT INTO #_TP_classes (id, class, title, classtype, comment, rank, status, upd) VALUES ('4', 'liens', 'Liens', 'entities', '', '4', '32', '20050310175849');
INSERT INTO #_TP_classes (id, class, title, classtype, comment, rank, status, upd) VALUES ('5', 'commentaires', 'Commentaires en ligne', 'entities', '', '5', '1', '20050320113631');
INSERT INTO #_TP_classes (id, class, title, classtype, comment, rank, status, upd) VALUES ('6', 'personnes', 'Personnes', 'persons', '', '6', '32', '20050310180047');
INSERT INTO #_TP_classes (id, class, title, classtype, comment, rank, status, upd) VALUES ('7', 'motcle', 'Index de mots-clés', 'entries', '', '7', '32', '20050504174934');
INSERT INTO #_TP_classes (id, class, title, classtype, comment, rank, status, upd) VALUES ('8', 'periode', 'Index chronologique', 'entries', '', '8', '1', '20050504174934');
INSERT INTO #_TP_classes (id, class, title, classtype, comment, rank, status, upd) VALUES ('9', 'theme', 'Index thématique', 'entries', '', '9', '1', '20050310180348');
INSERT INTO #_TP_classes (id, class, title, classtype, comment, rank, status, upd) VALUES ('10', 'geographie', 'Index géographique', 'entries', '', '10', '1', '20050310180418');
INSERT INTO #_TP_classes (id, class, title, classtype, comment, rank, status, upd) VALUES ('116', 'docannexe_image', 'Document annexe : image', 'entities', '', '11', '32', '20050324150419');
INSERT INTO #_TP_classes (id, class, title, classtype, comment, rank, status, upd) VALUES ('117', 'docannexe_fichier', 'Document annexe : fichier', 'entities', '', '12', '1', '20050324150516');
INSERT INTO #_TP_classes (id, class, title, classtype, comment, rank, status, upd) VALUES ('118', 'docannexe_entite', 'Document annexe : entité', 'entities', '', '13', '32', '20050324150538');
INSERT INTO #_TP_classes (id, class, title, classtype, comment, rank, status, upd) VALUES ('119', 'docannexe_lienexterne', 'Document annexe : lien externe', 'entities', '', '14', '32', '20050324150554');

#
# Dumping data for table 'tablefields'
#

INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('1', 'titre', '1', 'documents', 'Titre du document', 'title, titre, titleuser, heading', 'text', 'dc.title', '+', 'Document sans titre', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Lien;Appel de Note', '', 'editable', '', '8', '', '32', '2', '20050502145103');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('2', 'surtitre', '1', 'documents', 'Surtitre du document', 'surtitre', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Lien;Appel de Note', '', 'importable', '', '8', '', '1', '1', '20050504174747');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('3', 'soustitre', '1', 'documents', 'Sous-titre du document', 'subtitle', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Lien;Appel de Note', '', 'editable', '', '8', '', '1', '4', '20050325180002');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('4', 'texte', '2', 'documents', 'Texte du document', 'texte, standard, normal', 'longtext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'importable', '', '4', '', '1', '4', '20050325175938');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('5', 'notebaspage', '2', 'documents', 'Notes de bas de page', 'notebaspage, footnote, footnotetext', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', '', 'importable', '', '4', '', '1', '5', '20050319151140');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('7', 'annexe', '2', 'documents', 'Annexes du document', 'annexe', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'importable', '', '4', '', '1', '7', '20050319151157');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('8', 'bibliographie', '2', 'documents', 'Bibliographie du document', 'bibliographie', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'importable', '', '4', '', '1', '8', '20050319151205');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('9', 'datepubli', '3', 'documents', 'Date de la publication électronique', 'datepubli', 'date', 'dc.date', '*', 'today', '', '', '', 'text', '', '0', '', '1', '1', '20050315090627');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('10', 'datepublipapier', '3', 'documents', 'Date de la publication sur papier', 'datepublipapier', 'date', '', '*', '', '', '', '', 'editable', '', '0', '', '1', '2', '20050319152321');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('11', 'noticebiblio', '3', 'documents', 'Notice bibliographique du document', 'noticebiblio', 'tinytext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special', '', 'importable', '', '0', '', '1', '3', '20050319152343');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('12', 'pagination', '3', 'documents', 'Pagination du document sur le papier', 'pagination', 'tinytext', '', '*', '', '', '', '', 'text', '', '0', '', '1', '4', '20050315090627');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('13', 'droitsauteur', '3', 'documents', 'Droits d\'auteur', 'droitsauteur', 'tinytext', 'dc.rights', '*', 'Propriété intellectuelle', '', '', '', 'text', '', '0', '', '1', '5', '20050315090627');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('14', 'langue', '3', 'documents', 'Langue du document', 'langue', 'lang', 'dc.language', '*', '', '', '', '', 'text', '', '0', '', '1', '6', '20050315090627');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('15', 'prioritaire', '16', 'documents', 'Document prioritaire', '', 'boolean', '', '*', '', '', '', '', 'editable', '', '0', '', '1', '7', '20050319152711');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('17', 'erratum', '4', 'documents', 'Erratum', 'erratum', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'importable', '', '2', '', '1', '1', '20050314182513');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('18', 'ndlr', '4', 'documents', 'Note de la rédaction', 'ndlr', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'importable', '', '2', '', '1', '2', '20050319160348');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('19', 'historique', '4', 'documents', 'Historique du document', 'historique', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', '', 'importable', '', '0', '', '1', '3', '20050314182513');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('20', 'commentaireinterne', '16', 'documents', 'Commentaire interne sur le document', 'commentaire', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', '', 'importable', '', '0', '', '1', '4', '20050320121955');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('21', 'dedicace', '4', 'documents', 'Dédicace', 'dedicace', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'importable', '', '2', '', '1', '5', '20050319160500');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('22', 'remerciements', '4', 'documents', 'Remerciements', 'remerciements', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'importable', '', '2', '', '1', '22', '20050319160510');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('23', 'ocr', '16', 'documents', 'Document issu d\'une numérisation dite OCR', '', 'boolean', '', '*', '', '', '', '', 'importable', '', '0', '', '1', '9', '20050319152721');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('24', 'documentcliquable', '16', 'documents', 'Document cliquable dans les sommaires', '', 'boolean', '', '*', 'true', '', '', '', 'editable', '', '0', '', '1', '10', '20050323165335');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('25', 'nom', '0', 'motcle', 'Dénomination de l\'entrée d\'index', '', 'text', 'index key', '*', '', '', '', '', 'editable', '', '4', '', '1', '25', '20050325173050');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('26', 'motcle', '15', 'documents', 'Index de mots-clés', '', 'entries', '', '', '', '', '', '', 'editable', '', '0', '', '1', '2', '20050503104640');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('27', 'definition', '0', 'motcle', 'Définition', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', '', 'editable', '', '1', '', '1', '27', '20050325173320');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('28', 'nomfamille', '0', 'personnes', 'Nom de famille', '', 'tinytext', 'familyname', '*', '', '', '', '', 'editable', '', '4', '', '1', '28', '20050325172750');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('29', 'prenom', '0', 'personnes', 'Prénom', '', 'tinytext', 'firstname', '*', '', '', '', '', 'editable', '', '4', '', '1', '29', '20050325172743');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('30', 'prefix', '0', 'entities_personnes', 'Préfixe', 'prefixe, .prefixe', 'tinytext', '', '*', '', '', '', '', 'editable', '', '0', '', '1', '30', '20050320113011');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('31', 'affiliation', '0', 'entities_personnes', 'Affiliation', 'affiliation, .affiliation', 'tinytext', '', '*', '', '', '', '', 'editable', '', '4', '', '1', '31', '20050325172923');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('32', 'fonction', '0', 'entities_personnes', 'Fonction', 'fonction, .fonction', 'tinytext', '', '*', '', '', '', '', 'editable', '', '0', '', '1', '32', '20050311173133');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('33', 'description', '0', 'entities_personnes', 'Description', 'descriptionauteur, description', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Lien', '', 'editable', '5', '4', '', '1', '33', '20050325172933');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('34', 'courriel', '0', 'entities_personnes', 'Courriel', 'courriel, .courriel', 'email', '', '*', '', '', '', '', 'editable', '', '4', '', '1', '34', '20050325172943');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('35', 'auteur', '14', 'documents', 'Auteur du document', '', 'persons', '', '', '', '', '', '', 'editable', '', '0', '', '1', '11', '20050319152205');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('36', 'traducteur', '14', 'documents', 'Traducteur du document', '', 'persons', '', '', '', '', '', '', 'importable', '', '0', '', '1', '12', '20050319195427');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('37', 'nom', '0', 'periode', 'Dénomination de l\'entrée d\'index', '', 'text', 'index key', '*', '', '', '', '', 'editable', '', '4', '', '1', '37', '20050325173253');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('38', 'definition', '0', 'periode', 'Définition', '', 'text', '', '*', '', '', '', '', 'editable', '', '1', '', '1', '38', '20050325173304');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('39', 'nom', '0', 'theme', 'Dénomination de l\'entrée d\'index', '', 'text', 'index key', '*', '', '', '', '', 'editable', '', '4', '', '1', '39', '20050325173642');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('40', 'definition', '0', 'theme', 'Définition', '', 'text', '', '*', '', '', '', '', 'editable', '', '1', '', '1', '40', '20050325173647');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('41', 'nom', '0', 'geographie', 'Dénomination de l\'entrée d\'index', '', 'text', 'index key', '*', '', '', '', '', 'editable', '', '4', '', '1', '41', '20050325173710');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('42', 'definition', '0', 'geographie', 'Définition', '', 'text', '', '*', '', '', '', '', 'editable', '', '1', '', '1', '42', '20050325173716');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('43', 'titre', '5', 'liens', 'Titre du site', '', 'text', 'dc.title', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', '', 'editable', '', '8', '', '1', '43', '20050314181819');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('44', 'url', '6', 'liens', 'URL du site', '', 'url', '', '*', '', '', '', '', 'editable', '', '0', '', '1', '44', '20050320141428');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('45', 'urlfil', '6', 'liens', 'URL du fil de syndication du site', '', 'url', '', '*', '', '', '', '', 'editable', '', '0', '', '1', '45', '20050320152511');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('46', 'texte', '6', 'liens', 'Description du site', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'fckeditor', '', '2', '', '1', '46', '20050314182014');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('47', 'titre', '7', 'images', 'Titre de l\'image', '', 'text', 'dc.title', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', '', 'editable', '', '4', '', '1', '47', '20050509175033');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('48', 'image', '8', 'images', 'Image', '', 'image', '', '*', '', '', '', '', 'editable', '', '0', '', '1', '48', '20050314182135');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('74', 'altertitre', '1', 'documents', 'Titre alternatif du document (dans une autre langue)', 'englishtitle:en, titolo:it, titulo:es,titel:de', 'mltext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Lien;Appel de Note', '', 'editable', '', '8', '', '1', '3', '20050503104618');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('50', 'resume', '9', 'documents', 'Résumé', 'rsum,resume:fr, abstract:en, riassunto:it, extracto:es, zusammenfassung:de', 'mltext', 'dc.description', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'textarea', '5', '8', '', '1', '50', '20050325172249');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('51', 'titre', '10', 'publications', 'Titre de la publication', 'title, titre, titleuser, heading', 'text', 'dc.title', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', '', 'editable', '', '8', '', '1', '51', '20050320122739');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('52', 'surtitre', '10', 'publications', 'Surtitre de la publication', 'surtitre', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', '', 'editable', '', '8', '', '1', '52', '20050320122746');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('53', 'soustitre', '10', 'publications', 'Sous titre de la publication', 'soustitre', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', '', 'editable', '', '8', '', '1', '53', '20050320122753');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('54', 'commentaireinterne', '11', 'publications', 'Commentaire interne sur la publication', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', '', 'importable', '', '0', '', '1', '54', '20050320121750');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('55', 'prioritaire', '11', 'publications', 'Publication prioritaire ?', '', 'boolean', '', '*', '', '', '', '', 'editable', '', '0', '', '1', '55', '20050314184950');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('57', 'datepubli', '12', 'publications', 'Date de publication électronique', '', 'date', 'dc.date', '*', 'today', '', '', '', 'editable', '', '0', '', '1', '2', '20050315090818');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('58', 'datepublipapier', '12', 'publications', 'Date de publication papier', '', 'date', '', '*', '', '', '', '', 'editable', '', '0', '', '1', '3', '20050315090818');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('59', 'noticebiblio', '12', 'publications', 'Notice bibliographique décrivant la publication', '', 'tinytext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special', '', 'editable', '', '0', '', '1', '4', '20050315090818');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('60', 'introduction', '13', 'publications', 'Introduction de la publication', 'texte, standard, normal', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'fckeditor', '10,200', '8', '', '1', '60', '20050429171453');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('61', 'erratum', '13', 'publications', 'Erratum au sujet de la publication', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'textarea', '1,200', '2', '', '1', '61', '20050429171443');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('62', 'ndlr', '13', 'publications', 'Note de la rédaction au sujet de la publication', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'editable', '', '2', '', '1', '62', '20050314185506');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('63', 'historique', '13', 'publications', 'Historique de la publication', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'editable', '', '0', '', '1', '63', '20050314185547');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('64', 'periode', '12', 'publications', 'Période de publication', '', 'tinytext', '', '*', '', '', '', '', 'editable', '', '0', '', '1', '5', '20050315090818');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('65', 'isbn', '12', 'publications', 'ISBN', '', 'tinytext', '', '*', '', '', '', '', 'text', '', '0', '', '1', '7', '20050315090818');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('66', 'paraitre', '11', 'publications', 'A paraitre ?', '', 'boolean', '', '*', '', '', '', '', 'editable', '', '0', '', '1', '66', '20050314185827');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('67', 'texteintegral', '11', 'publications', 'Texte intégral ?', '', 'boolean', '', '*', '', '', '', '', 'editable', '', '0', '', '1', '67', '20050314185852');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('68', 'numero', '12', 'publications', 'Numéro de la publication', '', 'tinytext', '', '*', '', '', '', '', 'editable', '', '0', '', '1', '6', '20050315090818');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('69', 'keywords', '15', 'documents', 'Keywords index', '', 'entries', '', '', '', '', '', '', 'importable', '', '0', '', '1', '3', '20050319155713');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('70', 'role', '0', 'entities_personnes', 'Role dans l\'élaboration du document', 'role,.role', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special', '', 'editable', '', '0', '', '1', '68', '20050320113031');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('71', 'theme', '12', 'publications', 'Index thématique', '', 'entries', '', '', '', '', '', '', 'editable', '', '0', '', '1', '69', '20050315091331');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('72', 'chrono', '15', 'documents', 'Index chronologique', '', 'entries', '', '', '', '', '', '', 'importable', '', '0', '', '1', '4', '20050319155721');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('73', 'geographie', '15', 'documents', 'Index géographique', '', 'entries', '', '', '', '', '', '', 'importable', '', '0', '', '1', '5', '20050319155732');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('75', 'theme', '15', 'documents', 'Index thématique', '', 'entries', '', '', '', '', '', '', 'editable', '', '0', '', '1', '1', '20050503112915');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('76', 'titreoeuvre', '17', 'documents', 'Titre de l\'oeuvre commentée', 'titreoeuvre', 'tinytext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', '', 'editable', '', '4', '', '1', '2', '20050320104738');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('77', 'noticebibliooeuvre', '17', 'documents', 'Notice bibliographique de l\'oeuvre commentée', 'noticebibliooeuvre', 'tinytext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Appel de Note', '', 'editable', '', '4', '', '1', '1', '20050319200742');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('78', 'datepublicationoeuvre', '17', 'documents', 'Date de publication de l\'oeuvre commentée', 'datepublioeuvre', 'tinytext', '', '*', '', '', '', '', 'editable', '', '4', '', '1', '70', '20050319200700');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('79', 'auteuroeuvre', '17', 'documents', 'Auteur de l\'oeuvre commentée', '', 'persons', '', '', '', '', '', '', 'display', '', '0', '', '1', '71', '20050320110343');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('81', 'titre', '18', 'commentaires', 'Titre du commentaire', '', 'tinytext', 'dc.title', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'editable', '', '4', '', '1', '72', '20050320152802');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('82', 'texte', '19', 'commentaires', 'Commentaire', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'fckeditor', '6', '4', '', '1', '73', '20050324155709');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('83', 'ndla', '4', 'documents', 'Note de l\'auteur', 'ndla', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', '', 'importable', '', '2', '', '1', '74', '20050323102101');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('84', 'titre', '20', 'docannexe_image', 'Titre de l\'image', '', 'text', 'dc.title', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special', '', 'editable', '', '2', '', '1', '75', '20050408091301');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('85', 'lien', '20', 'docannexe_image', 'Image à charger', '', 'image', '', '*', '', '', '', '', 'editable', '', '0', '', '1', '76', '20050324151303');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('86', 'commentaire', '20', 'docannexe_image', 'Commentaire', '', 'text', 'dc.description', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', '', 'textarea', '', '2', '', '1', '77', '20050408091310');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('87', 'title', '21', 'docannexe_fichier', 'Titre du document annexe', '', 'text', 'dc.title', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special', '', 'editable', '', '2', '', '1', '78', '20050408091340');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('88', 'lien', '21', 'docannexe_fichier', 'Fichier à charger', '', 'file', '', '*', '', '', '', '', 'editable', '', '0', '', '1', '79', '20050324151656');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('89', 'commentaire', '21', 'docannexe_fichier', 'Commentaire', '', 'text', 'dc.description', '*', '', '', '', '', 'textarea', '', '2', '', '1', '80', '20050408091346');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('90', 'title', '22', 'docannexe_entite', 'Titre du document annexe', '', 'text', 'dc.title', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special', '', 'editable', '', '2', '', '1', '81', '20050508095700');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('91', 'lien', '22', 'docannexe_entite', 'Lien vers une entité (document ou publication)', '', 'entities', '', '*', '', '', '', '', 'editable', '', '0', '', '1', '82', '20050407172105');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('92', 'commentaire', '22', 'docannexe_entite', 'Commentaire', '', 'text', 'dc.description', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block', '', 'textarea', '', '2', '', '1', '83', '20050408091406');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('93', 'title', '23', 'docannexe_lienexterne', 'Titre du lien', '', 'text', 'dc.title', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special', '', 'editable', '', '2', '', '1', '84', '20050408091421');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('94', 'lien', '23', 'docannexe_lienexterne', 'Lien externe', '', 'url', '', '*', '', '', '', '', 'editable', '', '0', '', '1', '85', '20050324152506');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('95', 'commentaire', '23', 'docannexe_lienexterne', 'Commentaire', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block', '', 'textarea', '', '2', '', '1', '86', '20050408091428');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('96', 'icone', '12', 'publications', 'Icône de la publication', '', 'image', '', '*', '', '', '', '', 'editable', '', '0', '', '1', '87', '20050329163836');
INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, style, type, g_name, condition, defaultvalue, processing, allowedtags, filtering, edition, editionparams, weight, comment, status, rank, upd) VALUES ('97', 'icone', '3', 'documents', 'Icône du document', '', 'image', '', '*', '', '', '', '', 'editable', '', '0', '', '1', '88', '20050329164019');

#
# Dumping data for table 'tablefieldgroups'
#

INSERT INTO #_TP_tablefieldgroups (id, name, class, title, comment, status, rank, upd) VALUES ('1', 'grtitre', 'documents', 'Groupe du titre', '', '1', '1', '20050310180550');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, comment, status, rank, upd) VALUES ('2', 'grtexte', 'documents', 'Groupe du texte', '', '1', '3', '20050315180730');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, comment, status, rank, upd) VALUES ('3', 'grmeta', 'documents', 'Groupe des métadonnées', '', '1', '4', '20050503112731');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, comment, status, rank, upd) VALUES ('4', 'graddenda', 'documents', 'Groupe des addenda', '', '1', '5', '20050503112803');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, comment, status, rank, upd) VALUES ('5', 'grtitre', 'liens', 'Groupe de titre', '', '1', '5', '20050311182324');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, comment, status, rank, upd) VALUES ('6', 'grliens', 'liens', 'Groupe de définition des liens', '', '1', '6', '20050314181846');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, comment, status, rank, upd) VALUES ('7', 'grtitre', 'images', 'Groupe du titre', '', '1', '7', '20050314182042');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, comment, status, rank, upd) VALUES ('8', 'grimage', 'images', 'Groupe de définition des images', '', '1', '8', '20050314182120');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, comment, status, rank, upd) VALUES ('9', 'grresumes', 'documents', 'Groupe des résumés', '', '1', '2', '20050503112549');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, comment, status, rank, upd) VALUES ('10', 'grtitre', 'publications', 'Groupe de titre', '', '1', '1', '20050320122212');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, comment, status, rank, upd) VALUES ('11', 'grgestion', 'publications', 'Gestion des publications', '', '1', '2', '20050320122212');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, comment, status, rank, upd) VALUES ('12', 'grmetadonnees', 'publications', 'Groupe des métadonnées', '', '1', '4', '20050320122212');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, comment, status, rank, upd) VALUES ('13', 'graddenda', 'publications', 'Groupe des addenda', '', '1', '3', '20050503114928');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, comment, status, rank, upd) VALUES ('14', 'grpersonnes', 'documents', 'Groupe des personnes', '', '1', '7', '20050319152818');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, comment, status, rank, upd) VALUES ('15', 'grindex', 'documents', 'Groupe des index', '', '1', '6', '20050319152809');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, comment, status, rank, upd) VALUES ('16', 'grgestion', 'documents', 'Groupe de gestion du document', '', '1', '9', '20050320122139');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, comment, status, rank, upd) VALUES ('17', 'grrecension', 'documents', 'Oeuvre commentée (si ce document est un compte-rendu d\'oeuvre ou d\'ouvrage...)', '', '1', '8', '20050319201008');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, comment, status, rank, upd) VALUES ('18', 'grtitre', 'commentaires', 'Groupe du titre', '', '1', '10', '20050320152550');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, comment, status, rank, upd) VALUES ('19', 'grtexte', 'commentaires', 'Groupe du texte', '', '1', '11', '20050320152711');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, comment, status, rank, upd) VALUES ('20', 'grdocannexeimage', 'docannexe_image', 'Groupe pour les documents annexes : Image', '', '1', '12', '20050324151058');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, comment, status, rank, upd) VALUES ('21', 'grdocannexefichier', 'docannexe_fichier', 'Groupe pour les documents annexes : fichier', '', '1', '13', '20050324151520');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, comment, status, rank, upd) VALUES ('22', 'grdocannexelienentite', 'docannexe_entite', 'Groupe pour les documents annexes : lien vers une entité', '', '1', '14', '20050324151942');
INSERT INTO #_TP_tablefieldgroups (id, name, class, title, comment, status, rank, upd) VALUES ('23', 'grdocannexelienexterne', 'docannexe_lienexterne', 'Groupe pour les documents annexes : lien externe', '', '1', '15', '20050324152349');

#
# Dumping data for table 'types'
#

INSERT INTO #_TP_types (id, type, title, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, rank, status, upd, public) VALUES ('16', 'editorial', 'Editorial', 'documents', 'editorial', 'entities', 'edition', '1', '', '-1', '1', '1', '1', '20050311180041', '0');
INSERT INTO #_TP_types (id, type, title, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, rank, status, upd, public) VALUES ('17', 'article', 'Article', 'documents', 'article', 'entities', 'edition', '1', '', '-1', '1', '2', '1', '20050311175131', '0');
INSERT INTO #_TP_types (id, type, title, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, rank, status, upd, public) VALUES ('18', 'actualite', 'Annonce et actualité', 'documents', 'actualite', 'entities', 'edition', '1', '', '-1', '1', '3', '1', '20050311180049', '0');
INSERT INTO #_TP_types (id, type, title, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, rank, status, upd, public) VALUES ('19', 'breve', 'Brève', 'documents', 'breve', 'entities', 'edition', '1', '', '-1', '1', '4', '1', '20050503113500', '0');
INSERT INTO #_TP_types (id, type, title, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, rank, status, upd, public) VALUES ('20', 'compte rendu', 'Compte-rendu', 'documents', 'compterendu', 'entities', 'edition', '1', '', '-1', '1', '5', '1', '20050325175827', '0');
INSERT INTO #_TP_types (id, type, title, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, rank, status, upd, public) VALUES ('21', 'note de lecture', 'Note de lecture', 'documents', 'notedelecture', 'entities', 'edition', '1', '', '-1', '1', '6', '1', '20050311181429', '0');
INSERT INTO #_TP_types (id, type, title, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, rank, status, upd, public) VALUES ('22', 'presentation', 'Présentation', 'documents', 'presentation', 'entities', 'edition', '1', '', '-1', '1', '7', '1', '20050311181439', '0');
INSERT INTO #_TP_types (id, type, title, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, rank, status, upd, public) VALUES ('23', 'chronique', 'Chronique', 'documents', 'article', 'entities', 'edition', '1', '', '-1', '1', '8', '1', '20050311175531', '0');
INSERT INTO #_TP_types (id, type, title, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, rank, status, upd, public) VALUES ('24', 'collection', 'Collection', 'publications', 'sommaire', 'entities', 'edition', '0', '', '-1', '1', '9', '1', '20050428171133', '0');
INSERT INTO #_TP_types (id, type, title, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, rank, status, upd, public) VALUES ('25', 'volume', 'Volume', 'publications', 'sommaire', 'entities', 'edition', '0', '', '-1', '1', '10', '1', '20050315174909', '0');
INSERT INTO #_TP_types (id, type, title, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, rank, status, upd, public) VALUES ('26', 'numero', 'Numéro', 'publications', 'sommaire', 'entities', 'edition', '0', '', '-1', '1', '11', '1', '20050428171235', '0');
INSERT INTO #_TP_types (id, type, title, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, rank, status, upd, public) VALUES ('27', 'rubrique', 'Rubrique', 'publications', 'sommaire', 'entities', 'edition', '0', '', '-1', '1', '12', '1', '20050315174930', '0');
INSERT INTO #_TP_types (id, type, title, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, rank, status, upd, public) VALUES ('29', 'regroupement', 'Regroupement', 'publications', '', 'entities', 'edition', '0', '', '-1', '1', '14', '1', '20050311181859', '0');
INSERT INTO #_TP_types (id, type, title, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, rank, status, upd, public) VALUES ('30', 'images', 'Images', 'images', 'image', 'entities', 'edition', '0', '', '-1', '1', '15', '1', '20050311182156', '0');
INSERT INTO #_TP_types (id, type, title, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, rank, status, upd, public) VALUES ('31', 'liens', 'Liens', 'liens', 'lien', 'entities', 'edition', '0', '', '-1', '1', '16', '1', '20050311182228', '0');
INSERT INTO #_TP_types (id, type, title, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, rank, status, upd, public) VALUES ('121', 'commentaire', 'Commentaire du document', 'commentaires', '', 'entities', 'edition', '0', '', '-1', '1', '17', '1', '20050324155913', '0');
INSERT INTO #_TP_types (id, type, title, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, rank, status, upd, public) VALUES ('122', 'docannexe_image', 'Document Annexe : Image', 'docannexe_image', '', 'entities', 'edition', '0', 'advanced', '-1', '1', '18', '1', '20050324151001', '0');
INSERT INTO #_TP_types (id, type, title, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, rank, status, upd, public) VALUES ('123', 'docannexe_fichier', 'Document annexe : fichier', 'docannexe_fichier', '', 'entities', 'edition', '0', 'advanced', '-1', '1', '19', '1', '20050324151454', '0');
INSERT INTO #_TP_types (id, type, title, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, rank, status, upd, public) VALUES ('124', 'docannexe_entite', 'Document annexe : entité', 'docannexe_entite', '', 'entities', 'edition', '0', 'advanced', '-1', '1', '20', '1', '20050324151851', '0');
INSERT INTO #_TP_types (id, type, title, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, rank, status, upd, public) VALUES ('125', 'docannexe_lienexterne', 'Document annexe : lien externe', 'docannexe_lienexterne', '', 'entities', 'edition', '0', 'advanced', '-1', '1', '21', '1', '20050324152256', '0');

#
# Dumping data for table 'persontypes'
#

INSERT INTO #_TP_persontypes (id, type, title, class, style, g_type, tpl, tplindex, rank, status, upd) VALUES ('13', 'auteur', 'Auteur', 'personnes', 'auteur', 'dc.creator', 'personne', 'personnes', '1', '1', '20050317140944');
INSERT INTO #_TP_persontypes (id, type, title, class, style, g_type, tpl, tplindex, rank, status, upd) VALUES ('14', 'traducteur', 'Traducteur', 'personnes', 'traducteur', 'dc.contributor', 'personne', 'personnes', '2', '1', '20050317140935');
INSERT INTO #_TP_persontypes (id, type, title, class, style, g_type, tpl, tplindex, rank, status, upd) VALUES ('15', 'directeur de publication', 'Directeur de la publication', 'personnes', 'directeurdepublication', '', 'personne', 'personnes', '3', '1', '20050317141000');
INSERT INTO #_TP_persontypes (id, type, title, class, style, g_type, tpl, tplindex, rank, status, upd) VALUES ('64', 'auteuroeuvre', 'Auteur d\'une oeuvre commentée', 'personnes', 'auteuroeuvre', '', 'personne', 'personnes', '4', '1', '20050319201245');

#
# Dumping data for table 'entrytypes'
#

INSERT INTO #_TP_entrytypes (id, type, class, title, style, g_type, tpl, tplindex, rank, status, flat, newbyimportallowed, edition, sort, upd) VALUES ('11', 'motcle', 'motcle', 'Index de mots-clés', 'motscles, .motcles,motscls', 'dc.subject', 'entree', 'entrees', '1', '1', '0', '1', 'pool', 'sortkey', '20050502162227');
INSERT INTO #_TP_entrytypes (id, type, class, title, style, g_type, tpl, tplindex, rank, status, flat, newbyimportallowed, edition, sort, upd) VALUES ('12', 'keywords', 'motcle', 'Keywords index', 'keywords', '', 'entree', 'entrees', '2', '1', '0', '1', 'pool', 'sortkey', '20050318142317');
INSERT INTO #_TP_entrytypes (id, type, class, title, style, g_type, tpl, tplindex, rank, status, flat, newbyimportallowed, edition, sort, upd) VALUES ('32', 'chrono', 'periode', 'Index chronologique', 'periode, .periode, priode', '', 'entree', 'entrees', '3', '1', '0', '1', 'pool', 'sortkey', '20050323163340');
INSERT INTO #_TP_entrytypes (id, type, class, title, style, g_type, tpl, tplindex, rank, status, flat, newbyimportallowed, edition, sort, upd) VALUES ('33', 'theme', 'theme', 'Index thématique', 'themes,thmes,.themes', '', 'entree', 'entrees', '4', '1', '0', '1', 'pool', 'sortkey', '20050323163439');
INSERT INTO #_TP_entrytypes (id, type, class, title, style, g_type, tpl, tplindex, rank, status, flat, newbyimportallowed, edition, sort, upd) VALUES ('34', 'geographie', 'geographie', 'Index géographique', 'geographie, gographie,.geographie', '', 'entree', 'entrees', '5', '1', '0', '1', 'pool', 'sortkey', '20050323163502');

#
# Dumping data for table 'entitytypes_entitytypes'
#

INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('24', '0', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('25', '24', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('26', '24', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('27', '27', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('27', '24', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('29', '25', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('29', '27', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('29', '26', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('29', '24', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('16', '25', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('16', '27', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('16', '29', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('16', '26', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('17', '24', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('17', '26', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('17', '29', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('17', '27', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('17', '25', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('18', '0', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('18', '24', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('18', '26', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('18', '29', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('18', '27', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('18', '25', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('19', '27', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('19', '29', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('19', '26', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('19', '24', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('19', '0', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('20', '25', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('20', '27', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('20', '29', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('20', '26', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('21', '26', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('21', '29', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('21', '25', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('22', '24', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('22', '26', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('22', '29', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('22', '27', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('22', '25', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('23', '24', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('23', '26', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('23', '29', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('23', '27', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('23', '25', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('30', '26', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('30', '24', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('31', '0', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('31', '24', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('31', '26', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('31', '29', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('31', '27', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('31', '25', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('121', '22', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('121', '21', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('121', '16', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('121', '20', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('121', '23', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('122', '0', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('122', '17', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('122', '24', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('122', '27', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('122', '25', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('123', '25', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('123', '26', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('123', '24', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('123', '17', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('124', '27', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('124', '29', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('124', '26', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('124', '24', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('124', '31', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('124', '17', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('124', '0', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('125', '27', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('125', '29', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('125', '26', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('125', '24', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('125', '31', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('125', '17', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('123', '0', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('124', '25', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('125', '25', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('121', '19', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('121', '17', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('121', '0', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('30', '29', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('30', '27', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('30', '25', '*');
INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, condition) VALUES ('16', '24', '*');

#
# Dumping data for table 'characterstyles'
#

INSERT INTO #_TP_characterstyles (id, style, conversion, rank, status, upd) VALUES ('1', 'essai', '', '1', '1', '20050508182708');

#
# Dumping data for table 'internalstyles'
#

INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('1', 'citation', '*-', '', '0', '1', '1', '20050507011300');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('2', 'quotation', '*-', '<blockquote>', '0', '2', '1', '20050310184927');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('3', 'citationbis', '*-', '<blockquote class="citationbis">', '0', '3', '1', '20050310184950');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('4', 'citationter', '*-', '<blockquote class="citationter">', '0', '4', '1', '20050310185012');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('5', 'titreillustration', '*-', '', '0', '5', '1', '20050310185150');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('6', 'legendeillustration', '*-', '', '0', '6', '1', '20050310185207');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('7', 'titredoc', '*-', '', '0', '7', '1', '20050310185225');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('8', 'legendedoc', '*-', '', '0', '8', '1', '20050310185234');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('9', 'puces', '*-', '<ul><li>', '0', '9', '1', '20050310185304');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('10', 'code', '*-', '', '0', '10', '1', '20050310185341');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('11', 'question', '*-', '', '0', '11', '1', '20050310185417');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('12', 'reponse', '*-', '', '0', '12', '1', '20050429171251');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('20', 'separateur,sparateur', '*-', '<HR style=', '0', '19', '1', '20050429171227');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('19', 'section1', '-*', '', '0', '13', '1', '20050429171303');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('15', 'section3', '*-', '<h3>', '0', '15', '1', '20050429171302');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('16', 'section4', '*-', '<h4>', '0', '16', '1', '20050429171300');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('17', 'section5', '*-', '<h5>', '0', '17', '1', '20050429171242');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('18', 'section6', '*-', '<h6>', '0', '18', '1', '20050429171237');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('21', 'paragraphesansretrait', '*-', 'paragraphesansretrait', '0', '20', '1', '20050429171224');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('22', 'epigraphe,pigraphe', '*-', 'epigraphe', '0', '21', '1', '20050429171223');
INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES ('23', 'section2', '-*', '', '0', '14', '1', '20050429171303');
DELETE FROM #_TP_optiongroups;
# # Database: 'lodeldevelunstable_revorg08'# 
#
# Dumping data for table 'optiongroups'
#

INSERT INTO #_TP_optiongroups (id, idparent, name, title, comment, logic, exportpolicy, rank, status, upd) VALUES ('1', '0', 'servoo', 'servoo', '', 'servooconf', '1', '1', '32', '20050511150438');
INSERT INTO #_TP_optiongroups (id, idparent, name, title, comment, logic, exportpolicy, rank, status, upd) VALUES ('2', '0', 'metadonneessite', 'Métadonnées du site', '', '', '1', '2', '1', '20050312112815');
DELETE FROM #_TP_options;
# # Database: 'lodeldevelunstable_revorg08'# 
#
# Dumping data for table 'options'
#

INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status) VALUES ('1', '1', 'url', 'url', 'tinytext', '', '', '40', '1', '32');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status) VALUES ('2', '1', 'username', 'username', 'tinytext', '', '', '40', '2', '32');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status) VALUES ('3', '1', 'passwd', 'password', 'passwd', '', '', '40', '3', '32');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status) VALUES ('4', '2', 'titresite', 'Titre du site', 'tinytext', 'Titresite', '', '40', '4', '1');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status) VALUES ('5', '2', 'titresiteabrege', 'Titre abrégé du site', 'tinytext', 'Titre abrégé du site', '', '40', '5', '1');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status) VALUES ('6', '2', 'descriptionsite', 'Description du site', 'text', '', '', '10', '6', '1');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status) VALUES ('7', '2', 'urldusite', 'URL officielle du site', 'url', '', '', '30', '7', '1');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status) VALUES ('8', '2', 'urlcomlementaire', 'URL en lien avec le site', 'url', '', '', '30', '8', '1');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status) VALUES ('9', '2', 'ISSN', 'ISSN', 'tinytext', '', '', '30', '9', '1');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status) VALUES ('10', '2', 'editeur', 'Nom de l\'éditeur du site', 'tinytext', '', '', '30', '10', '1');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status) VALUES ('11', '2', 'adresseediteur', 'Adresse postale de l\'éditeur', 'text', '', '', '30', '11', '1');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status) VALUES ('12', '2', 'producteursite', 'Nom du producteur du site', 'tinytext', '', '', '30', '12', '1');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status) VALUES ('13', '2', 'diffuseursite', 'Nom du diffuseur du site', 'tinytext', '', '', '30', '13', '1');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status) VALUES ('14', '2', 'droitsauteur', 'Droits d\'auteur par défaut', 'tinytext', '', '', '30', '14', '1');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status) VALUES ('15', '2', 'directeurpublication', 'Nom du directeur de la publication', 'tinytext', '', '', '30', '15', '1');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status) VALUES ('16', '2', 'redacteurenchef', 'Nom du Rédacteur en chef', 'tinytext', '', '', '30', '16', '1');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status) VALUES ('17', '2', 'courrielwebmaster', 'Courriel du webmaster', 'email', '', '', '30', '17', '1');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status) VALUES ('18', '2', 'courrielabuse', 'Courriel abuse', 'tinytext', '', '', '30', '18', '1');
INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status) VALUES ('19', '2', 'motsclesdusite', 'Mots clés décrivant le site (entre virgules)', 'text', '', '', '30', '19', '1');
# # Database: 'lodeldevelunstable_revorg08'# 
# --------------------------------------------------------

#
# Table structure for table 'documents'
#

DROP TABLE IF EXISTS #_TP_documents;
CREATE TABLE #_TP_documents (
  identity int(10) unsigned default NULL,
  titre text,
  surtitre text,
  soustitre text,
  texte longtext,
  notebaspage text,
  annexe text,
  bibliographie text,
  datepubli date default NULL,
  datepublipapier date default NULL,
  noticebiblio tinytext,
  pagination tinytext,
  droitsauteur tinytext,
  langue varchar(5) default NULL,
  prioritaire tinyint(4) default NULL,
  erratum text,
  ndlr text,
  historique text,
  commentaireinterne text,
  dedicace text,
  remerciements text,
  ocr tinyint(4) default NULL,
  documentcliquable tinyint(4) default NULL,
  resume text,
  altertitre text,
  titreoeuvre tinytext,
  noticebibliooeuvre tinytext,
  datepublicationoeuvre tinytext,
  ndla text,
  icone tinytext,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table 'publications'
#

DROP TABLE IF EXISTS #_TP_publications;
CREATE TABLE #_TP_publications (
  identity int(10) unsigned default NULL,
  titre text,
  surtitre text,
  soustitre text,
  commentaireinterne text,
  prioritaire tinyint(4) default NULL,
  datepubli date default NULL,
  datepublipapier date default NULL,
  noticebiblio tinytext,
  introduction text,
  erratum text,
  ndlr text,
  historique text,
  periode tinytext,
  isbn tinytext,
  paraitre tinyint(4) default NULL,
  texteintegral tinyint(4) default NULL,
  numero tinytext,
  icone tinytext,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table 'images'
#

DROP TABLE IF EXISTS #_TP_images;
CREATE TABLE #_TP_images (
  identity int(10) unsigned default NULL,
  titre text,
  image tinytext,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table 'liens'
#

DROP TABLE IF EXISTS #_TP_liens;
CREATE TABLE #_TP_liens (
  identity int(10) unsigned default NULL,
  titre text,
  url text,
  urlfil text,
  texte text,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table 'commentaires'
#

DROP TABLE IF EXISTS #_TP_commentaires;
CREATE TABLE #_TP_commentaires (
  identity int(10) unsigned default NULL,
  titre tinytext,
  texte text,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table 'personnes'
#

DROP TABLE IF EXISTS #_TP_personnes;
CREATE TABLE #_TP_personnes (
  idperson int(10) unsigned default NULL,
  nomfamille tinytext,
  prenom tinytext,
  UNIQUE KEY idperson (idperson),
  KEY index_idperson (idperson)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table 'entities_personnes'
#

DROP TABLE IF EXISTS #_TP_entities_personnes;
CREATE TABLE #_TP_entities_personnes (
  idrelation int(10) unsigned default NULL,
  prefix tinytext,
  affiliation tinytext,
  fonction tinytext,
  description text,
  courriel text,
  role text,
  UNIQUE KEY idrelation (idrelation),
  KEY index_idrelation (idrelation)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table 'motcle'
#

DROP TABLE IF EXISTS #_TP_motcle;
CREATE TABLE #_TP_motcle (
  identry int(10) unsigned default NULL,
  nom text,
  definition text,
  UNIQUE KEY identry (identry),
  KEY index_identry (identry)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table 'periode'
#

DROP TABLE IF EXISTS #_TP_periode;
CREATE TABLE #_TP_periode (
  identry int(10) unsigned default NULL,
  nom text,
  definition text,
  UNIQUE KEY identry (identry),
  KEY index_identry (identry)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table 'theme'
#

DROP TABLE IF EXISTS #_TP_theme;
CREATE TABLE #_TP_theme (
  identry int(10) unsigned default NULL,
  nom text,
  definition text,
  UNIQUE KEY identry (identry),
  KEY index_identry (identry)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table 'geographie'
#

DROP TABLE IF EXISTS #_TP_geographie;
CREATE TABLE #_TP_geographie (
  identry int(10) unsigned default NULL,
  nom text,
  definition text,
  UNIQUE KEY identry (identry),
  KEY index_identry (identry)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table 'docannexe_image'
#

DROP TABLE IF EXISTS #_TP_docannexe_image;
CREATE TABLE #_TP_docannexe_image (
  identity int(10) unsigned default NULL,
  titre text,
  lien tinytext,
  commentaire text,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table 'docannexe_fichier'
#

DROP TABLE IF EXISTS #_TP_docannexe_fichier;
CREATE TABLE #_TP_docannexe_fichier (
  identity int(10) unsigned default NULL,
  title text,
  lien tinytext,
  commentaire text,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table 'docannexe_entite'
#

DROP TABLE IF EXISTS #_TP_docannexe_entite;
CREATE TABLE #_TP_docannexe_entite (
  identity int(10) unsigned default NULL,
  title text,
  commentaire text,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table 'docannexe_lienexterne'
#

DROP TABLE IF EXISTS #_TP_docannexe_lienexterne;
CREATE TABLE #_TP_docannexe_lienexterne (
  identity int(10) unsigned default NULL,
  title text,
  lien text,
  commentaire text,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) TYPE=MyISAM;
