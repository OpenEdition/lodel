# <model>
# 			<lodelversion>0.9</lodelversion>
# 			<date>2010-09-09</date>
# 			<title>
# 			a
# 			</title>
# 			<description>
# 			a
# 			</description>
# 			<author>
# 			a
# 			</author>
# 			<modelversion>
# 			a
# 			</modelversion>
# 			</model>
# 			
#------------

DELETE FROM #_TP_classes;
DELETE FROM #_TP_tablefields;
DELETE FROM #_TP_tablefieldgroups;
DELETE FROM #_TP_types;
DELETE FROM #_TP_persontypes;
DELETE FROM #_TP_entrytypes;
DELETE FROM #_TP_entitytypes_entitytypes;
DELETE FROM #_TP_characterstyles;
DELETE FROM #_TP_internalstyles;
# # Database: 'lodel09_me-revorg'# 
#
# Dumping data for table 'classes'
#

INSERT INTO #_TP_classes (id, icon, class, title, altertitle, classtype, comment, rank, status, upd) VALUES (266, 'lodel/icons/texte.gif', 'textes', 'Textes', '<r2r:ml lang="en">Texts</r2r:ml>', 'entities', '', 2, 32, '2010-06-11 14:47:18'),
(267, 'lodel/icons/collection.gif', 'publications', 'Publications', '<r2r:ml lang="en">Folders</r2r:ml>', 'entities', '', 1, 1, '2010-06-11 14:47:18'),
(268, 'lodel/icons/doc_annexe.gif', 'fichiers', 'Fichiers', '<r2r:ml lang="en">Files</r2r:ml>', 'entities', '', 5, 32, '2010-06-11 14:47:18'),
(269, 'lodel/icons/lien.gif', 'liens', 'Sites', '<r2r:ml lang="en">Websites</r2r:ml>', 'entities', '', 6, 32, '2010-06-11 14:47:18'),
(270, 'lodel/icons/texte_simple.gif', 'textessimples', 'Textes simples', '<r2r:ml lang="en">Simple texts</r2r:ml>', 'entities', '', 3, 32, '2010-06-11 14:47:18'),
(271, 'lodel/icons/personne.gif', 'auteurs', 'Auteurs', '<r2r:ml lang="en">Authors</r2r:ml>', 'persons', '', 8, 32, '2010-06-11 14:47:18'),
(272, 'lodel/icons/index.gif', 'indexes', 'Index', '<r2r:ml lang="en">Indexes</r2r:ml>', 'entries', '', 9, 1, '2010-06-11 14:47:18'),
(273, 'lodel/icons/individu.gif', 'individus', 'Personnes', '<r2r:ml lang="en">Persons</r2r:ml>', 'entities', '', 4, 1, '2010-06-11 14:47:18'),
(274, 'lodel/icons/index_avance.gif', 'indexavances', 'Index avancés', '<r2r:ml lang="en">Advanced indexes</r2r:ml>', 'entries', '', 10, 1, '2010-06-11 14:47:18');

#
# Dumping data for table 'tablefields'
#

INSERT INTO #_TP_tablefields (id, name, idgroup, class, title, altertitle, style, type, g_name, cond, defaultvalue, processing, allowedtags, gui_user_complexity, filtering, edition, editionparams, weight, comment, mask, status, rank, upd) VALUES (1, 'titre', 31, 'textes', 'Titre du document', '<r2r:ml lang="en">Document title</r2r:ml>', 'title, titre, titleuser, heading', 'text', 'dc.title', '+', 'Document sans titre', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Lien;Appel de Note', 16, '', 'editable', '', 8, '', 'a:0:{}', 32, 3, '2010-05-26 17:22:25'),
(2, 'surtitre', 31, 'textes', 'Surtitre du document', '<r2r:ml lang="en">Document heading (additional title)</r2r:ml>', 'surtitre', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Lien;Appel de Note', 32, '', 'importable', '', 8, '', 'a:0:{}', 32, 2, '2010-05-28 16:04:22'),
(3, 'soustitre', 31, 'textes', 'Sous-titre du document', '<r2r:ml lang="en">Document subtitle (secondary title)</r2r:ml>', 'subtitle, soustitre', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Lien;Appel de Note', 32, '', 'editable', '', 8, '', 'a:0:{}', 32, 5, '2010-05-26 10:53:13'),
(4, 'texte', 32, 'textes', 'Texte du document', '<r2r:ml lang="en">Standard text</r2r:ml>', 'texte, standard, normal, textbody', 'longtext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 16, '', 'display', '', 4, '', 'a:0:{}', 32, 1, '2010-05-25 16:08:22'),
(5, 'notesbaspage', 32, 'textes', 'Notes de bas de page', '<r2r:ml lang="en">Footnotes</r2r:ml>', 'notebaspage, footnote, footnotetext', 'longtext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', 32, '', 'importable', '', 4, '', 'a:0:{}', 32, 2, '2010-05-25 16:08:40'),
(7, 'annexe', 32, 'textes', 'Annexes du document', '<r2r:ml lang="en">Appendixes</r2r:ml>', 'annexe', 'longtext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 32, '', 'importable', '', 4, '', '', 32, 4, '2010-09-08 15:50:36'),
(8, 'bibliographie', 32, 'textes', 'Bibliographie du document', '<r2r:ml lang="en">Bibliography</r2r:ml>', 'bibliographie', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 32, '', 'importable', '', 4, '', 'a:0:{}', 32, 5, '2010-05-25 16:10:07'),
(9, 'datepubli', 33, 'textes', 'Date de la publication électronique', '<r2r:ml lang="en">Date of online publication (electronic edition)</r2r:ml>', 'datepubli', 'date', 'dc.date', '*', 'today', '', '', 16, '', 'editable', '', 0, '', 'a:0:{}', 32, 1, '2010-05-26 10:54:26'),
(10, 'datepublipapier', 33, 'textes', 'Date de la publication sur papier', '<r2r:ml lang="en">Date of publication (print edition)</r2r:ml>', 'datepublipapier', 'date', '', '*', '', '', '', 32, '', 'editable', '', 0, '', 'a:0:{}', 32, 2, '2010-05-26 10:54:41'),
(11, 'noticebiblio', 33, 'textes', 'Notice bibliographique du document', '<r2r:ml lang="en">Bibliographical reference describing the document</r2r:ml>', 'noticebiblio', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special', 64, '', 'importable', '', 0, '', 'a:0:{}', 32, 3, '2010-05-26 10:55:21'),
(12, 'pagination', 33, 'textes', 'Pagination du document sur le papier', '<r2r:ml lang="en">Pagination</r2r:ml>', 'pagination', 'tinytext', '', '*', '', '', '', 64, '', 'editable', '', 0, '', 'a:0:{}', 32, 4, '2010-05-26 15:16:08'),
(130, 'editeurscientifique', 14, 'textes', 'Éditeur scientifique', '<r2r:ml lang="en">Academic editor</r2r:ml>', '', 'persons', '', '', '', '', '', 64, '', 'editable', '', 0, '', '', 1, 109, '2010-05-26 15:19:32'),
(14, 'langue', 33, 'textes', 'Langue du document', '<r2r:ml lang="en">Language of document</r2r:ml>', 'langue', 'lang', 'dc.language', '*', 'fr', '', '', 32, '', 'editable', '', 0, '', 'a:0:{}', 1, 6, '2010-05-26 15:18:09'),
(15, 'prioritaire', 16, 'textes', 'Document prioritaire', '<r2r:ml lang="en">Document priority</r2r:ml>', '', 'boolean', '', '*', '', '', '', 64, '', 'editable', '', 0, '', 'a:0:{}', 32, 7, '2010-05-26 15:22:10'),
(17, 'addendum', 34, 'textes', 'Addendum', '<r2r:ml lang="en">Addendum</r2r:ml>', 'erratum, addendum', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 64, '', 'importable', '', 2, '', 'a:0:{}', 32, 3, '2010-05-26 11:28:20'),
(18, 'ndlr', 34, 'textes', 'Note de la rédaction', '<r2r:ml lang="en">Editor\'s note</r2r:ml>', 'ndlr', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 64, '', 'importable', '', 2, '', 'a:0:{}', 32, 1, '2010-05-26 11:29:27'),
(20, 'commentaireinterne', 16, 'textes', 'Commentaire interne sur le document', '<r2r:ml lang="en">Internal comment about the document</r2r:ml>', 'commentaire', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', 64, '', 'importable', '', 0, '', 'a:0:{}', 32, 4, '2010-05-26 15:21:20'),
(21, 'dedicace', 34, 'textes', 'Dédicace', '<r2r:ml lang="en">Dedication</r2r:ml>', 'dedicace', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 64, '', 'importable', '', 2, '', 'a:0:{}', 32, 4, '2010-05-26 11:27:26'),
(23, 'ocr', 16, 'textes', 'Document issu d\'une numérisation dite OCR', '<r2r:ml lang="en">The document is a transcript from an OCR</r2r:ml>', '', 'boolean', '', '*', '', '', '', 64, '', 'importable', '', 0, '', 'a:0:{}', 32, 9, '2010-05-26 15:23:43'),
(24, 'documentcliquable', 16, 'textes', 'Document cliquable dans les sommaires', '<r2r:ml lang="en">The document is clickable in the contents of the folder</r2r:ml>', '', 'boolean', '', '*', 'true', '', '', 64, '', 'editable', '', 0, '', 'a:0:{}', 32, 10, '2010-05-26 15:28:54'),
(25, 'nom', 0, 'indexes', 'Dénomination de l\'entrée d\'index', '<r2r:ml lang="en">Entry name</r2r:ml>', '', 'text', 'index key', '*', 'Tous droits réservés', '', '', 16, '', 'editable', '', 4, '', '', 32, 25, '2010-05-25 12:21:48'),
(26, 'motsclesfr', 15, 'textes', 'Index de mots-clés', '<r2r:ml lang="en">Index de mots-clés</r2r:ml>', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', 0, '', '', 32, 2, '2010-05-26 10:55:51'),
(27, 'definition', 0, 'indexes', 'Définition', '<r2r:ml lang="en">Entry definition</r2r:ml>', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', 16, '', 'fckeditor', 'Basic', 1, '', '', 32, 27, '2010-05-25 12:21:59'),
(28, 'nomfamille', 0, 'auteurs', 'Nom de famille', '<r2r:ml lang="en">Surname</r2r:ml>', '', 'tinytext', 'familyname', '*', '', '', '', 32, '', 'editable', '', 4, '', '', 32, 28, '2010-05-25 12:33:12'),
(29, 'prenom', 0, 'auteurs', 'Prénom', '<r2r:ml lang="en">Name</r2r:ml>', '', 'tinytext', 'firstname', '*', '', '', '', 32, '', 'editable', '', 4, '', '', 32, 29, '2010-05-25 12:45:59'),
(30, 'prefix', 0, 'entities_auteurs', 'Préfixe', '<r2r:ml lang="en">Prefix</r2r:ml>', 'prefixe, .prefixe', 'tinytext', '', '*', '', '', '', 64, '', 'editable', '', 0, '', '', 1, 2, '2010-05-25 12:35:37'),
(31, 'affiliation', 0, 'entities_auteurs', 'Affiliation', '<r2r:ml lang="en">Affiliation</r2r:ml>', 'affiliation, .affiliation', 'tinytext', '', '*', '', '', '', 32, '', 'editable', '', 4, '', '', 1, 3, '2010-05-25 12:41:13'),
(32, 'fonction', 0, 'entities_auteurs', 'Fonction', '<r2r:ml lang="en">Function</r2r:ml>', 'fonction, .fonction', 'tinytext', '', '*', '', '', '', 32, '', 'editable', '', 0, '', '', 1, 4, '2010-05-25 12:45:05'),
(33, 'description', 0, 'entities_auteurs', 'Description de l\'auteur', '<r2r:ml lang="en">Author description</r2r:ml>', 'descriptionauteur', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', 16, '', 'fckeditor', '5', 4, '', '', 1, 1, '2010-09-08 10:12:12'),
(34, 'courriel', 0, 'entities_auteurs', 'Courriel', '<r2r:ml lang="en">Email</r2r:ml>', 'courriel, .courriel', 'email', '', '*', '', '', '', 32, '', 'editable', '', 4, '', '', 1, 5, '2010-05-25 12:36:15'),
(35, 'auteur', 14, 'textes', 'Auteur du document', '<r2r:ml lang="en">Author</r2r:ml>', '', 'persons', '', '', '', '', '', 64, '', 'editable', '', 0, '', '', 32, 11, '2010-05-26 11:29:56'),
(36, 'traducteur', 14, 'textes', 'Traducteur du document', '<r2r:ml lang="en">Translator</r2r:ml>', '', 'persons', '', '', '', '', '', 64, '', 'editable', '', 0, '', '', 32, 12, '2010-05-26 11:30:14'),
(142, 'alias', 16, 'textes', 'Alias', '<r2r:ml lang="en">Alias</r2r:ml>', '', 'entities', '', '*', '', '', '', 64, '', 'editable', '', 0, '', 'a:0:{}', 1, 119, '2010-05-26 10:57:55'),
(117, 'date', 19, 'textessimples', 'Date de publication en ligne', '<r2r:ml lang="en">Date of online publication</r2r:ml>', '', 'datetime', '', '*', 'now', '', '', 16, '', 'editable', '', 0, '', 'a:0:{}', 1, 100, '2010-05-25 12:02:47'),
(116, 'url', 19, 'textessimples', 'Lien', '<r2r:ml lang="en">Link</r2r:ml>', '', 'url', '', '*', '', '', '', 16, '', 'editable', '', 2, '', 'a:0:{}', 1, 99, '2010-05-25 12:01:09'),
(140, 'licence', 24, 'fichiers', 'Licence', '<r2r:ml lang="en">Document license</r2r:ml>', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', 0, '', '', 1, 118, '2010-05-25 16:55:47'),
(43, 'titre', 35, 'liens', 'Titre du site', '<r2r:ml lang="en">Website title</r2r:ml>', '', 'text', 'dc.title', '*', 'Site sans titre', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', 16, '', 'editable', '', 8, '', 'a:0:{}', 32, 43, '2010-05-25 16:46:00'),
(44, 'url', 36, 'liens', 'URL du site', '<r2r:ml lang="en">Website URL</r2r:ml>', '', 'url', '', '*', '', '', '', 16, '', 'editable', '', 0, '', 'a:0:{}', 32, 1, '2010-05-25 16:47:01'),
(45, 'urlfil', 36, 'liens', 'URL du fil de syndication du site', '<r2r:ml lang="en">RSS feed URL</r2r:ml>', '', 'url', '', '*', '', '', '', 16, '', 'editable', '', 0, '', 'a:0:{}', 32, 4, '2010-05-25 16:48:10'),
(46, 'texte', 36, 'liens', 'Description du site', '<r2r:ml lang="en">Website synopsis</r2r:ml>', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 16, '', 'fckeditor', 'Simple', 2, '', 'a:0:{}', 32, 2, '2010-05-25 16:47:25'),
(47, 'titre', 37, 'fichiers', 'Titre', '', '', 'text', 'dc.title', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', 16, '', 'editable', '', 4, '', '', 32, 47, '2006-06-22 22:53:15'),
(48, 'document', 38, 'fichiers', 'Document', '<r2r:ml lang="en">Document</r2r:ml>', '', 'file', '', '*', '', '', '', 16, '', 'editable', '', 0, '', 'a:0:{}', 32, 1, '2010-05-25 16:52:38'),
(74, 'altertitre', 31, 'textes', 'Titre alternatif du document (dans une autre langue)', '<r2r:ml lang="en">Document translated title (alternative title)</r2r:ml>', 'titretraduitfr:fr,titrefr:fr,titretraduiten:en,titleen:en,titreen:en,titretraduites:es,tituloes:es,titrees:es,titretraduitit:it,titoloit:it,titreit:it,titretraduitde:de,titelde:de,titrede:de,titretraduitpt:pt,titrept:pt,titretraduitru:ru,titreru:ru', 'mltext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Lien;Appel de Note', 16, '', 'editable', '', 8, '', 'a:0:{}', 32, 4, '2010-05-26 10:53:44'),
(50, 'resume', 39, 'textes', 'Résumé', '<r2r:ml lang="en">Abstract</r2r:ml>', 'rsum:fr,resume:fr,resumefr:fr,abstract:en,resumeen:en,extracto:es,resumen:es, resumees:es,resumo:pt,resumept:pt,riassunto:it,resumeit:it,zusammenfassung:de,resumede:de,resumeru:ru', 'mltext', 'dc.description', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 16, '', 'display', '5', 8, '', 'a:0:{}', 32, 50, '2010-05-25 16:04:11'),
(51, 'titre', 40, 'publications', 'Titre de la publication', '<r2r:ml lang="en">Folder title</r2r:ml>', 'title, titre, titleuser, heading', 'text', 'dc.title', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', 16, '', 'editable', '', 8, '', 'a:0:{}', 32, 2, '2010-05-25 16:17:46'),
(52, 'surtitre', 40, 'publications', 'Surtitre de la publication', '<r2r:ml lang="en">Folder heading (additional title)</r2r:ml>', 'surtitre', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', 16, '', 'importable', '', 8, '', 'a:0:{}', 32, 1, '2010-05-28 15:14:54'),
(53, 'soustitre', 40, 'publications', 'Sous-titre de la publication', '<r2r:ml lang="en">Folfer subtitle (secondary title)</r2r:ml>', 'soustitre', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', 16, '', 'editable', '', 8, '', 'a:0:{}', 32, 3, '2010-05-25 16:18:33'),
(54, 'commentaireinterne', 11, 'publications', 'Commentaire interne sur la publication', '<r2r:ml lang="en">Internal comment about the folder</r2r:ml>', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', 64, '', 'editable', '4', 0, '', 'a:0:{}', 32, 54, '2010-05-26 17:18:02'),
(55, 'prioritaire', 11, 'publications', 'Cette publication est-elle prioritaire ?', '<r2r:ml lang="en">The publication of the folder is having priority</r2r:ml>', '', 'boolean', '', '*', '', '', '', 16, '', 'editable', '', 0, '', 'a:0:{}', 32, 55, '2010-05-28 16:02:55'),
(57, 'datepubli', 12, 'publications', 'Date de publication électronique', '<r2r:ml lang="en">Date of online publication (electronic edition)</r2r:ml>', '', 'date', 'dc.date', '*', 'today', '', '', 16, '', 'editable', '', 0, '', 'a:0:{}', 32, 2, '2010-05-26 10:35:33'),
(58, 'datepublipapier', 12, 'publications', 'Date de publication papier', '<r2r:ml lang="en">Date of publication (print edition)</r2r:ml>', '', 'date', '', '*', '', '', '', 16, '', 'editable', '', 0, '', 'a:0:{}', 32, 3, '2010-05-26 10:35:19'),
(59, 'noticebiblio', 12, 'publications', 'Notice bibliographique décrivant la publication', '<r2r:ml lang="en">Bibliographical reference</r2r:ml>', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special', 64, '', 'importable', '', 0, '', 'a:0:{}', 32, 4, '2010-05-26 10:36:16'),
(60, 'introduction', 13, 'publications', 'Introduction de la publication', '<r2r:ml lang="en">Folder introduction</r2r:ml>', 'texte, standard, normal', 'mltext', 'dc.description', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 16, '', 'fckeditor', 'Simple,550,400', 8, '', 'a:0:{}', 32, 60, '2010-05-26 10:12:30'),
(131, 'geographie', 15, 'textes', 'Index géographique', '<r2r:ml lang="en">Geographical index</r2r:ml>', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', 0, '', '', 1, 110, '2010-05-26 10:56:17'),
(132, 'chrono', 15, 'textes', 'Index chronologique', '<r2r:ml lang="en">Chronological index</r2r:ml>', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', 0, '', '', 1, 111, '2010-05-26 10:56:45'),
(62, 'ndlr', 13, 'publications', 'Note de la rédaction au sujet de la publication', '<r2r:ml lang="en">Editor\'s note about the folder</r2r:ml>', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 64, '', 'fckeditor', '', 2, '', 'a:0:{}', 32, 62, '2010-05-26 10:26:58'),
(63, 'historique', 13, 'publications', 'Historique de la publication', '<r2r:ml lang="en">Folder history</r2r:ml>', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 64, '', 'importable', '', 0, '', 'a:0:{}', 32, 63, '2010-05-26 10:27:23'),
(64, 'periode', 12, 'publications', 'Période de publication', '<r2r:ml lang="en">Period of publication</r2r:ml>', '', 'tinytext', '', '*', '', '', '', 16, '', 'importable', '', 0, '', 'a:0:{}', 1, 5, '2010-05-26 17:16:28'),
(65, 'isbn', 12, 'publications', 'ISBN', '<r2r:ml lang="en">ISBN</r2r:ml>', '', 'tinytext', '', '*', '', '', '', 16, '', 'editable', '', 0, '', 'a:0:{}', 1, 7, '2010-06-11 15:04:48'),
(66, 'paraitre', 11, 'publications', 'Cette publication est-elle à paraitre ?', '<r2r:ml lang="en">The publication of the folder is forthcoming</r2r:ml>', '', 'boolean', '', '*', '', '', '', 32, '', 'editable', '', 0, '', 'a:0:{}', 32, 66, '2010-05-28 16:03:19'),
(67, 'integralite', 11, 'publications', 'Cette publication en ligne est-elle intégrale ?', '<r2r:ml lang="en">The folfer is published in full open access</r2r:ml>', '', 'boolean', '', '*', '', '', '', 32, '', 'editable', '', 0, '', 'a:0:{}', 32, 67, '2010-05-26 10:29:57'),
(68, 'numero', 12, 'publications', 'Numéro de la publication', '<r2r:ml lang="en">Volume number</r2r:ml>', '', 'tinytext', '', '*', '', '', '', 16, '', 'editable', '', 0, '', 'a:0:{}', 32, 6, '2010-05-26 17:16:53'),
(69, 'motsclesen', 15, 'textes', 'Keywords index', '<r2r:ml lang="en">Keywords index</r2r:ml>', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', 0, '', '', 32, 3, '2010-05-26 10:56:02'),
(168, 'racinemets', 11, 'publications', 'Racine Mets', '', '', 'boolean', '', '*', '', '', '', 64, '', 'editable', '', 0, '', '', 1, 130, '2010-09-09 10:55:36'),
(119, 'email', 30, 'individus', 'Courriel', '<r2r:ml lang="en">Email</r2r:ml>', '', 'email', '', '*', '', '', '', 16, '', 'editable', '', 4, '', 'a:0:{}', 1, 3, '2010-05-25 17:03:45'),
(120, 'siteweb', 30, 'individus', 'Site web', '<r2r:ml lang="en">Website</r2r:ml>', '', 'url', '', '*', '', '', '', 16, '', 'editable', '', 0, '', 'a:0:{}', 1, 4, '2010-05-25 17:04:00'),
(121, 'description', 30, 'individus', 'Description', '<r2r:ml lang="en">Full description</r2r:ml>', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 16, '', 'fckeditor', 'Simple', 4, '', 'a:0:{}', 1, 2, '2010-05-28 16:07:57'),
(76, 'titreoeuvre', 17, 'textes', 'Titre de l\'oeuvre commentée', '<r2r:ml lang="en">Title of the reviewed document</r2r:ml>', 'titreoeuvre', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Appel de Note', 64, '', 'display', '', 4, '', 'a:0:{}', 32, 2, '2010-05-26 17:23:45'),
(77, 'noticebibliooeuvre', 17, 'textes', 'Notice bibliographique de l\'oeuvre commentée', '<r2r:ml lang="en">Bibliographical reference describing the reviewed document</r2r:ml>', 'noticebibliooeuvre', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Appel de Note', 64, '', 'display', '', 4, '', 'a:0:{}', 32, 1, '2010-05-26 17:23:17'),
(78, 'datepublicationoeuvre', 17, 'textes', 'Date de publication de l\'oeuvre commentée', '<r2r:ml lang="en">Date of publication of the reviewed document</r2r:ml>', 'datepublioeuvre', 'tinytext', '', '*', '', '', '', 64, '', 'display', '', 4, '', 'a:0:{}', 32, 70, '2010-05-26 17:24:18'),
(79, 'auteuroeuvre', 17, 'textes', 'Auteur de l\'oeuvre commentée', '<r2r:ml lang="en">Author of the reviewed document</r2r:ml>', '', 'persons', '', '', '', '', '', 64, '', 'editable', '', 0, '', '', 32, 71, '2010-05-26 17:24:46'),
(81, 'titre', 18, 'textessimples', 'Titre', '<r2r:ml lang="en">Title</r2r:ml>', '', 'tinytext', 'dc.title', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 16, '', 'editable', '', 4, '', 'a:0:{}', 32, 72, '2010-05-25 11:59:51'),
(82, 'texte', 19, 'textessimples', 'Texte', '<r2r:ml lang="en">Text</r2r:ml>', '', 'mltext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 16, '', 'fckeditor', 'Simple', 4, '', 'a:0:{}', 1, 73, '2010-05-25 12:00:51'),
(83, 'ndla', 34, 'textes', 'Note de l\'auteur', '<r2r:ml lang="en">Author\'s note</r2r:ml>', 'ndla', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 64, '', 'importable', '', 2, '', 'a:0:{}', 32, 2, '2010-05-26 11:28:57'),
(96, 'icone', 12, 'publications', 'Icône de la publication', '<r2r:ml lang="en">Folder icon</r2r:ml>', '', 'image', '', '*', '', '', '', 16, '', 'none', '', 0, '', 'a:0:{}', 32, 1, '2010-05-26 10:26:25'),
(97, 'icone', 33, 'textes', 'Icône du document', '<r2r:ml lang="en">Icon of document</r2r:ml>', '', 'image', '', '*', '', '', '', 64, '', 'none', '', 0, '', 'a:0:{}', 32, 88, '2010-05-26 15:18:44'),
(98, 'description', 38, 'fichiers', 'Description', '<r2r:ml lang="en">Description</r2r:ml>', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 16, '', 'fckeditor', 'Simple', 4, '', 'a:0:{}', 32, 2, '2010-05-25 16:52:58'),
(99, 'alterfichier', 32, 'textes', 'Texte au format PDF', '<r2r:ml lang="en">PDF version of the document (facsimile)</r2r:ml>', '', 'file', '', '*', '', '', '', 32, '', 'editable', '', 0, '', 'a:0:{}', 32, 6, '2010-05-25 16:10:51'),
(104, 'langue', 12, 'publications', 'Langue de la publication', '<r2r:ml lang="en">Language of publication</r2r:ml>', '', 'lang', 'dc.language', '*', 'fr', '', '', 64, '', 'editable', '', 0, '', 'a:0:{}', 32, 8, '2010-05-26 10:40:00'),
(100, 'auteur', 24, 'fichiers', 'Auteur', '<r2r:ml lang="en">Authors</r2r:ml>', '', 'persons', '', '', '', '', '', 64, '', 'editable', '', 0, '', '', 32, 91, '2010-05-25 16:55:12'),
(101, 'auteur', 25, 'liens', 'Auteur de la notice décrivant ce site', '<r2r:ml lang="en">Author of website description</r2r:ml>', '', 'persons', '', '', '', '', '', 64, '', 'editable', '', 0, '', '', 32, 92, '2010-05-25 16:49:27'),
(102, 'capturedecran', 36, 'liens', 'Capture d\'écran du site', '<r2r:ml lang="en">Website screenshot</r2r:ml>', '', 'image', '', '*', '', '', '', 16, '', 'editable', '', 0, '', 'a:0:{}', 32, 3, '2010-05-25 16:47:50'),
(103, 'auteur', 26, 'textessimples', 'Auteur', '<r2r:ml lang="en">Author</r2r:ml>', '', 'persons', '', '', '', '', '', 64, '', 'editable', '', 0, '', '', 32, 93, '2010-05-25 12:03:28'),
(105, 'numerodocument', 31, 'textes', 'Numéro du document', '<r2r:ml lang="en">Document number</r2r:ml>', 'numerodocument,numrodudocument', 'number', '', '*', '', '', '', 64, '', 'editable', '', 0, '', 'a:0:{}', 32, 1, '2010-05-25 16:03:37'),
(112, 'nom', 28, 'individus', 'Nom', '<r2r:ml lang="en">Surname</r2r:ml>', '', 'tinytext', 'dc.title', '*', '', '', '', 16, '', 'editable', '', 4, '', 'a:0:{}', 1, 1, '2010-05-25 16:59:25'),
(113, 'prenom', 28, 'individus', 'Prénom', '<r2r:ml lang="en">Name</r2r:ml>', '', 'tinytext', '', '*', '', '', '', 16, '', 'editable', '', 4, '', 'a:0:{}', 1, 2, '2010-05-25 16:59:36'),
(122, 'accroche', 28, 'individus', 'Accroche', '<r2r:ml lang="en">Brief introduction</r2r:ml>', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 16, '', 'fckeditor', 'Simple', 4, '', 'a:0:{}', 1, 3, '2010-05-28 16:07:11'),
(123, 'adresse', 30, 'individus', 'Adresse', '<r2r:ml lang="en">Address</r2r:ml>', '', 'text', '', '*', '', '', '', 16, '', 'editable', '3', 4, '', 'a:0:{}', 1, 102, '2010-05-25 17:04:14'),
(124, 'telephone', 30, 'individus', 'Téléphone', '<r2r:ml lang="en">Phone number</r2r:ml>', '', 'tinytext', '', '*', '', '', '', 16, '', 'editable', '', 4, '', 'a:0:{}', 1, 103, '2010-05-25 17:04:29'),
(125, 'photographie', 28, 'individus', 'Photographie', '<r2r:ml lang="en">Illustration</r2r:ml>', '', 'image', '', '*', '', '', '', 16, '', 'editable', '', 0, '', 'a:0:{}', 1, 104, '2010-05-28 16:09:05'),
(141, 'vignette', 38, 'fichiers', 'Vignette', '<r2r:ml lang="en">Small image</r2r:ml>', '', 'image', '', '*', '', '', '', 16, '', 'editable', '', 0, '', 'a:0:{}', 32, 3, '2010-05-25 16:54:09'),
(127, 'directeurdelapublication', 12, 'publications', 'Directeur de la publication', '<r2r:ml lang="en">Academic editor</r2r:ml>', '', 'persons', '', '', '', '', '', 64, '', 'editable', '', 0, '', '', 1, 10, '2010-05-26 10:41:05'),
(128, 'legende', 38, 'fichiers', 'Légende', '<r2r:ml lang="en">Caption</r2r:ml>', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', 16, '', 'fckeditor', 'Basic', 4, '', 'a:0:{}', 1, 4, '2010-05-25 16:54:48'),
(129, 'credits', 24, 'fichiers', 'Crédits', '<r2r:ml lang="de">Credits</r2r:ml>', '', 'tinytext', '', '*', '', '', '', 16, '', 'editable', '', 4, '', 'a:0:{}', 1, 108, '2010-05-25 16:55:27'),
(133, 'theme', 15, 'textes', 'Index thématique', '<r2r:ml lang="en">Subject index</r2r:ml>', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', 0, '', '', 1, 112, '2010-05-26 10:56:59'),
(139, 'licence', 12, 'publications', 'Licence portant sur la publication', '<r2r:ml lang="en">License</r2r:ml>', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', 0, '', '', 1, 9, '2010-05-26 10:40:46'),
(134, 'nom', 0, 'indexavances', 'Dénomination de l\'entrée d\'index', '<r2r:ml lang="en">Entry name</r2r:ml>', '', 'tinytext', 'index key', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block', 16, '', 'editable', '', 4, '', '', 1, 113, '2010-05-25 12:24:28'),
(135, 'description', 0, 'indexavances', 'Description de l\'entrée d\'index', '<r2r:ml lang="en">Entry definition</r2r:ml>', '', 'text', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien;Appel de Note', 16, '', 'fckeditor', 'Basic', 4, '', '', 1, 114, '2010-05-25 12:24:44'),
(136, 'url', 0, 'indexavances', 'URL', '<r2r:ml lang="en">URL</r2r:ml>', '', 'url', '', '*', '', '', '', 16, '', 'editable', '', 0, '', '', 1, 115, '2010-05-25 12:24:57'),
(137, 'icone', 0, 'indexavances', 'Icône', '<r2r:ml lang="en">Icon</r2r:ml>', '', 'image', '', '*', '', '', '', 16, '', 'editable', '', 0, '', '', 1, 116, '2010-05-25 12:25:11'),
(138, 'licence', 33, 'textes', 'Licence portant sur le document', '<r2r:ml lang="en">Document license</r2r:ml>', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', 0, '', '', 1, 117, '2010-05-26 15:19:07'),
(143, 'notefin', 32, 'textes', 'Notes de fin de document', '<r2r:ml lang="en">Endnotes</r2r:ml>', 'notefin', 'longtext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Lien', 32, '', 'importable', '', 4, '', 'a:0:{}', 32, 3, '2010-05-25 16:08:58'),
(144, 'altertitre', 40, 'publications', 'Titre alternatif de la publication (dans une autre langue)', '<r2r:ml lang="en">Folder translated title (alternative title)</r2r:ml>', 'titretraduitfr:fr,titretraduiten:en,titretraduites:es,titretraduitpt:pt,titretraduitit:it,titretraduitde:de,titretraduitru:ru,titleen:en', 'mltext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;xhtml:block;Appel de Note', 32, '', 'editable', '', 4, '', 'a:0:{}', 1, 120, '2010-05-27 10:07:01'),
(147, 'motscleses', 15, 'textes', 'Palabras claves', '<r2r:ml lang="en">Palabras claves</r2r:ml>', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', 0, '', '', 1, 121, '2010-05-26 10:57:12'),
(148, 'motsclesde', 15, 'textes', 'Schlagwortindex', '<r2r:ml lang="en">Schlagwortindex</r2r:ml>', '', 'entries', '', '', '', '', '', 64, '', 'editable', '', 0, '', '', 1, 122, '2010-05-26 10:57:25'),
(149, 'urlpublicationediteur', 13, 'publications', 'Voir sur le site de l\'éditeur', '<r2r:ml lang="en">Publisher\'s website</r2r:ml>', '', 'url', '', '*', '', '', '', 32, '', 'editable', '', 0, '', 'a:0:{}', 1, 123, '2010-05-26 10:10:46'),
(150, 'nombremaxitems', 36, 'liens', 'Nombre maximum d\'items du flux', '<r2r:ml lang="en">Maximum number of feed items</r2r:ml>', '', 'int', '', '*', '', '', '', 16, '', 'editable', '', 0, '', 'a:0:{}', 32, 124, '2010-05-25 16:48:51'),
(151, 'descriptionouvrage', 12, 'publications', 'Description physique de l\'ouvrage', '<r2r:ml lang="en">Physical description</r2r:ml>', '', 'text', '', '*', '', '', '', 64, '', 'editable', '', 0, '', 'a:0:{}', 32, 125, '2010-05-26 17:18:53'),
(152, 'site', 0, 'entities_auteurs', 'Site', '<r2r:ml lang="en">Website</r2r:ml>', 'site, .site', 'url', '', '*', '', '', '', 32, '', 'editable', '', 4, '', '', 1, 6, '2010-05-25 12:36:29'),
(167, 'imagehabillee', 16, 'textes', 'Habillage des images', '', '', 'boolean', '', '*', '1', '', '', 64, '', 'editable', '', 0, '', 'a:0:{}', 1, 129, '2010-06-11 10:59:08'),
(164, 'traduction', 16, 'textes', 'Ce document est une traduction de :', '<r2r:ml lang="en">The document is a translation of:</r2r:ml>', '', 'entities', '', '*', '', '', '', 64, '', 'editable', '', 0, '', 'a:0:{}', 1, 126, '2010-05-26 10:58:37'),
(165, 'altertitre', 18, 'textessimples', 'Titre alternatif du document (dans une autre langue)', '<r2r:ml lang="en">Translated title (alternative title)</r2r:ml>', '', 'mltext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Lien;Appel de Note', 16, '', 'editable', '', 0, '', 'a:0:{}', 1, 127, '2010-05-26 17:32:58'),
(166, 'altertitre', 35, 'liens', 'Titre alternatif (dans une autre langue)', '<r2r:ml lang="en">Translated title (alternative title)</r2r:ml>', '', 'mltext', '', '*', '', '', 'xhtml:fontstyle;xhtml:phrase;xhtml:special;Lien;Appel de Note', 16, '', 'editable', '', 0, '', 'a:0:{}', 1, 128, '2010-05-28 16:16:00');

#
# Dumping data for table 'tablefieldgroups'
#

INSERT INTO #_TP_tablefieldgroups (id, name, class, title, altertitle, comment, status, rank, upd) VALUES (31, 'grtitre', 'textes', 'Titres', '<r2r:ml lang="en">Titles</r2r:ml>', '', 1, 1, '2010-05-25 16:04:22'),
(32, 'grtexte', 'textes', 'Texte', '<r2r:ml lang="en">Text</r2r:ml>', '', 1, 3, '2010-05-25 16:05:45'),
(33, 'grmeta', 'textes', 'Métadonnées', '<r2r:ml lang="en">Metadata</r2r:ml>', '', 1, 4, '2010-05-25 16:05:17'),
(34, 'graddenda', 'textes', 'Addenda', '<r2r:ml lang="en">Addenda</r2r:ml>', '', 1, 5, '2010-05-25 16:06:11'),
(35, 'grtitre', 'liens', 'Titre', '<r2r:ml lang="en">Title</r2r:ml>', '', 1, 5, '2010-05-25 16:45:39'),
(36, 'grsite', 'liens', 'Description', '', '', 1, 6, '2010-05-25 16:46:46'),
(37, 'grtitre', 'fichiers', 'Titre', '<r2r:ml lang="en">Title</r2r:ml>', '', 1, 7, '2010-05-25 16:52:06'),
(38, 'grmultimedia', 'fichiers', 'Définition', '<r2r:ml lang="en">Description</r2r:ml>', '', 1, 8, '2010-05-25 16:52:19'),
(39, 'grresumes', 'textes', 'Résumés', '<r2r:ml lang="en">Abstracts</r2r:ml>', '', 1, 2, '2010-05-25 16:05:32'),
(40, 'grtitre', 'publications', 'Groupe de titre', '<r2r:ml lang="en">Title section</r2r:ml>', '', 32, 1, '2010-05-26 10:43:21'),
(11, 'grgestion', 'publications', 'Gestion des publications', '<r2r:ml lang="en">Publishing options</r2r:ml>', '', 1, 4, '2010-05-26 10:45:21'),
(12, 'grmetadonnees', 'publications', 'Groupe des métadonnées', '<r2r:ml lang="en">Metadata section</r2r:ml>', '', 32, 3, '2010-05-26 10:44:12'),
(13, 'graddenda', 'publications', 'Groupe des addenda', '<r2r:ml lang="en">Addenda section</r2r:ml>', '', 32, 2, '2010-05-26 10:43:55'),
(14, 'grpersonnes', 'textes', 'Auteurs', '<r2r:ml lang="en">Authors</r2r:ml>', '', 1, 7, '2010-05-25 16:06:26'),
(15, 'grindex', 'textes', 'Index', '<r2r:ml lang="en">Indexes</r2r:ml>', '', 1, 6, '2010-05-25 16:05:57'),
(16, 'grgestion', 'textes', 'Gestion du document', '<r2r:ml lang="en">Document management</r2r:ml>', '', 1, 9, '2010-05-25 16:07:47'),
(17, 'grrecension', 'textes', 'Oeuvre commentée (si ce document est un compte-rendu d\'oeuvre ou d\'ouvrage...)', '', '', 1, 8, '2005-06-19 16:00:22'),
(18, 'grtitre', 'textessimples', 'Titre', '<r2r:ml lang="en">Title</r2r:ml>', '', 1, 10, '2010-05-25 12:10:20'),
(19, 'grtexte', 'textessimples', 'Texte', '<r2r:ml lang="en">Text</r2r:ml>', '', 1, 11, '2010-05-25 12:10:33'),
(24, 'grdroits', 'fichiers', 'Droits', '<r2r:ml lang="en">License</r2r:ml>', '', 32, 16, '2010-05-25 16:55:01'),
(25, 'grauteurs', 'liens', 'Auteurs', '<r2r:ml lang="en">Authors</r2r:ml>', '', 32, 17, '2010-05-25 16:49:05'),
(26, 'grauteurs', 'textessimples', 'Auteurs', '<r2r:ml lang="en">Authors</r2r:ml>', '', 32, 18, '2010-05-25 12:10:44'),
(28, 'grtitre', 'individus', 'Titre', '<r2r:ml lang="en">Title</r2r:ml>', '', 1, 20, '2010-05-25 16:59:14'),
(30, 'grdescription', 'individus', 'Description', '<r2r:ml lang="en">Description</r2r:ml>', '', 1, 21, '2010-05-25 17:03:19');

#
# Dumping data for table 'types'
#

INSERT INTO #_TP_types (id, icon, type, title, altertitle, class, tpl, tplcreation, tpledition, import, display, creationstatus, search, public, gui_user_complexity, oaireferenced, rank, status, upd) VALUES (221, '', 'editorial', 'Editorial', '<r2r:ml lang="en">Editorial</r2r:ml>', 'textes', 'article', 'entities', '', 1, '', -1, 1, 0, 32, 1, 1, 32, '2010-06-11 14:47:18'),
(222, '', 'article', 'Article', '<r2r:ml lang="en">Article</r2r:ml>', 'textes', 'article', 'entities', '', 1, '', -1, 1, 0, 16, 1, 2, 1, '2010-06-11 14:47:18'),
(223, '', 'actualite', 'Annonce et actualité', '<r2r:ml lang="en">Announcement</r2r:ml>', 'textes', 'article', 'entities', '', 1, '', -1, 1, 0, 32, 0, 3, 32, '2010-06-11 14:47:18'),
(224, '', 'compterendu', 'Compte-rendu', '<r2r:ml lang="en">Book review</r2r:ml>', 'textes', 'article', 'entities', '', 1, '', -1, 1, 0, 32, 1, 5, 32, '2010-06-11 14:47:18'),
(225, '', 'notedelecture', 'Note de lecture', '<r2r:ml lang="en">Critical note</r2r:ml>', 'textes', 'article', 'entities', '', 1, '', -1, 1, 0, 64, 1, 6, 32, '2010-06-11 14:47:18'),
(226, '', 'informations', 'Informations pratiques', '<r2r:ml lang="en">Information note</r2r:ml>', 'textes', 'article', 'entities', '', 1, '', -1, 1, 0, 32, 0, 7, 32, '2010-06-11 14:47:18'),
(227, '', 'chronique', 'Chronique', '<r2r:ml lang="en">Chronicle</r2r:ml>', 'textes', 'article', 'entities', '', 1, '', -1, 1, 0, 64, 0, 8, 32, '2010-06-11 14:47:18'),
(228, '', 'collection', 'Collection', '<r2r:ml lang="en">Collection</r2r:ml>', 'publications', 'sommaire', 'entities', 'edition', 0, '', -1, 1, 0, 16, 0, 1, 32, '2010-06-11 14:47:18'),
(229, 'lodel/icons/volume.gif', 'numero', 'Numéro de revue', '<r2r:ml lang="en">Issue</r2r:ml>', 'publications', 'sommaire', 'entities', 'edition', 0, '', -1, 1, 0, 32, 0, 3, 32, '2010-06-11 14:47:18'),
(230, 'lodel/icons/rubrique.gif', 'rubrique', 'Rubrique', '<r2r:ml lang="en">Section</r2r:ml>', 'publications', 'sommaire', 'entities', 'edition', 0, '', -1, 1, 0, 16, 0, 5, 32, '2010-06-11 14:47:18'),
(231, 'lodel/icons/rubrique_plat.gif', 'souspartie', 'Sous-partie', '<r2r:ml lang="en">Subsection</r2r:ml>', 'publications', '', 'entities', 'edition', 0, 'unfolded', -1, 1, 0, 16, 0, 6, 1, '2010-06-11 14:47:18'),
(232, '', 'image', 'Image', '<r2r:ml lang="en">Image file</r2r:ml>', 'fichiers', 'image', 'entities', '', 0, '', -1, 1, 0, 64, 1, 1, 1, '2010-06-11 14:47:18'),
(233, '', 'noticedesite', 'Notice de site', '<r2r:ml lang="en">Website presentation</r2r:ml>', 'liens', 'lien', 'entities', '', 0, '', -1, 1, 0, 64, 0, 16, 1, '2010-06-11 14:47:18'),
(234, 'lodel/icons/commentaire.gif', 'commentaire', 'Commentaire du document', '<r2r:ml lang="en">Comment</r2r:ml>', 'textessimples', '', 'entities', '', 0, 'advanced', -1, 1, 1, 16, 0, 2, 1, '2010-06-11 14:47:18'),
(245, '', 'videoannexe', 'Vidéo placée en annexe', '<r2r:ml lang="en">Appended video file</r2r:ml>', 'fichiers', '', 'entities', 'edition', 0, 'advanced', -1, 1, 0, 64, 0, 4, 1, '2010-06-11 14:47:18'),
(240, '', 'annuairedequipe', 'Équipe', '<r2r:ml lang="en">Directory of persons</r2r:ml>', 'publications', 'sommaire', 'entities', 'edition', 0, '', -1, 1, 0, 16, 0, 8, 32, '2010-06-11 14:47:18'),
(241, '', 'annuairemedias', 'Médiathèque', '<r2r:ml lang="en">Media library</r2r:ml>', 'publications', 'sommaire', 'entities', 'edition', 0, '', -1, 1, 0, 16, 0, 9, 32, '2010-06-11 14:47:18'),
(235, '', 'image_annexe', 'Image placée en annexe', '<r2r:ml lang="en">Appended image file</r2r:ml>', 'fichiers', '', 'entities', '', 0, 'advanced', -1, 1, 0, 64, 0, 2, 1, '2010-06-11 14:47:18'),
(236, '', 'lienannexe', 'Lien placé en annexe', '<r2r:ml lang="en">Appended link</r2r:ml>', 'liens', 'lien', 'entities', '', 0, 'advanced', -1, 1, 0, 64, 0, 24, 1, '2010-06-11 14:47:18'),
(237, '', 'individu', 'Notice biographique de membre', '<r2r:ml lang="en">Biographical presentation</r2r:ml>', 'individus', 'individu', 'entities', '', 0, '', -1, 1, 0, 16, 0, 25, 1, '2010-06-11 14:47:18'),
(238, '', 'billet', 'Billet', '<r2r:ml lang="en">Note</r2r:ml>', 'textessimples', 'article', 'entities', '', 0, '', -1, 1, 0, 16, 0, 1, 1, '2010-06-11 14:47:18'),
(239, '', 'annuairedesites', 'Annuaire de sites', '<r2r:ml lang="en">Directory of websites</r2r:ml>', 'publications', 'sommaire', 'entities', 'edition', 0, '', -1, 1, 0, 16, 0, 7, 32, '2010-06-11 14:47:18'),
(242, 'lodel/icons/rss.gif', 'fluxdesyndication', 'Flux de syndication', '<r2r:ml lang="en">RSS feed</r2r:ml>', 'liens', 'lien', 'entities', '', 0, '', -1, 1, 0, 64, 0, 30, 1, '2010-06-11 14:47:18'),
(243, '', 'video', 'Vidéo', '<r2r:ml lang="en">Video file</r2r:ml>', 'fichiers', '', 'entities', '', 0, '', -1, 1, 0, 64, 0, 3, 1, '2010-06-11 14:47:18'),
(244, '', 'son', 'Document sonore', '<r2r:ml lang="en">Audio file</r2r:ml>', 'fichiers', '', 'entities', '', 0, '', -1, 1, 0, 32, 0, 5, 1, '2010-06-11 14:47:18'),
(246, '', 'fichierannexe', 'Fichier placé en annexe', '<r2r:ml lang="en">Appended file</r2r:ml>', 'fichiers', 'image', 'entities', '', 0, 'advanced', -1, 1, 0, 32, 0, 7, 1, '2010-06-11 14:47:18'),
(247, '', 'sonannexe', 'Document sonore placé en annexe', '<r2r:ml lang="en">Appended audio file</r2r:ml>', 'fichiers', '', 'entities', '', 0, 'advanced', -1, 1, 0, 32, 0, 6, 1, '2010-06-11 14:47:18'),
(249, '', 'imageaccroche', 'Image d\'accroche', '', 'fichiers', 'image', 'entities', '', 0, 'advanced', -1, 1, 0, 16, 0, 31, 32, '2010-06-11 14:47:18'),
(250, 'lodel/icons/rubrique.gif', 'rubriqueannuaire', 'Rubrique (d\'annuaire de site)', '<r2r:ml lang="en">Section (directory of websites type)</r2r:ml>', 'publications', 'sommaire', 'entities', 'edition', 0, '', -1, 1, 0, 16, 0, 32, 32, '2010-06-11 14:47:18'),
(251, '', 'rubriquemediatheque', 'Rubrique (de médiathèque)', '<r2r:ml lang="en">Section (media library type)</r2r:ml>', 'publications', 'sommaire', 'entities', 'edition', 0, '', -1, 1, 0, 16, 0, 33, 32, '2010-06-11 14:47:18'),
(252, 'lodel/icons/rubrique.gif', 'rubriqueequipe', 'Rubrique (d\'équipe)', '<r2r:ml lang="en">Section (directory of persons type)</r2r:ml>', 'publications', 'sommaire', 'entities', 'edition', 0, 'unfolded', -1, 1, 0, 16, 0, 34, 32, '2010-06-11 14:47:18'),
(248, 'lodel/icons/rubrique.gif', 'rubriqueactualites', 'Rubrique (d\'actualités)', '<r2r:ml lang="en">Section (news collection type)</r2r:ml>', 'publications', 'sommaire', 'entities', 'edition', 0, '', -1, 1, 0, 16, 0, 35, 32, '2010-06-11 14:47:18');

#
# Dumping data for table 'persontypes'
#

INSERT INTO #_TP_persontypes (id, icon, type, title, altertitle, class, style, g_type, tpl, tplindex, gui_user_complexity, rank, status, upd) VALUES (253, 'lodel/icons/auteur.gif', 'auteur', 'Auteur', '<r2r:ml lang="en">Author</r2r:ml>', 'auteurs', 'auteur', 'dc.creator', 'personne', 'personnes', 32, 1, 32, '2010-06-11 14:47:18'),
(254, '', 'traducteur', 'Traducteur', '<r2r:ml lang="en">Translator</r2r:ml>', 'auteurs', 'traducteur', 'dc.contributor', 'personne', 'personnes', 64, 2, 1, '2010-06-11 14:47:18'),
(255, '', 'directeurdelapublication', 'Directeur de la publication', '<r2r:ml lang="en">Issue editor</r2r:ml>', 'auteurs', 'directeur', '', 'personne', 'personnes', 32, 3, 32, '2010-06-11 14:47:18'),
(256, '', 'auteuroeuvre', 'Auteur d\'une oeuvre commentée', '<r2r:ml lang="en">Reviewed book author</r2r:ml>', 'auteurs', 'auteuroeuvre', '', 'personne', 'personnes', 64, 4, 32, '2010-06-11 14:47:18'),
(257, '', 'editeurscientifique', 'Éditeur scientifique', '<r2r:ml lang="en">Academic editor</r2r:ml>', 'auteurs', 'editeurscientifique', '', 'personne', 'personnes', 64, 5, 1, '2010-06-11 14:47:18');

#
# Dumping data for table 'entrytypes'
#

INSERT INTO #_TP_entrytypes (id, icon, type, class, title, altertitle, style, g_type, tpl, tplindex, gui_user_complexity, rank, status, flat, newbyimportallowed, edition, sort, upd, lang, externalallowed) VALUES (258, '', 'motsclesfr', 'indexes', 'Index de mots-clés', '<r2r:ml lang="en">Index de mots-clés</r2r:ml>', 'motscles, .motcles,motscls,motsclesfr', 'dc.subject', 'entree', 'entrees', 32, 1, 1, 1, 1, 'pool', 'sortkey', '2010-06-11 14:47:18', 'fr', 0),
(259, '', 'motsclesen', 'indexes', 'Index by keyword', '<r2r:ml lang="en">Index by keyword</r2r:ml>', 'keywords,motclesen', '', 'entree', 'entrees', 64, 2, 1, 1, 1, 'pool', 'sortkey', '2010-06-11 14:47:18', 'en', 0),
(261, '', 'chrono', 'indexes', 'Index chronologique', '<r2r:ml lang="en">Chronological index</r2r:ml>', 'periode, .periode, priode', '', 'entree', 'entrees', 64, 5, 1, 0, 1, 'pool', 'sortkey', '2010-06-11 14:47:18', 'fr', 0),
(262, '', 'theme', 'indexes', 'Index thématique', '<r2r:ml lang="en">Subject index</r2r:ml>', 'themes,thmes,.themes', '', 'entree', 'entrees', 16, 6, 1, 0, 1, 'pool', 'sortkey', '2010-06-11 14:47:18', 'fr', 0),
(260, '', 'geographie', 'indexes', 'Index géographique', '<r2r:ml lang="en">Geographical index</r2r:ml>', 'geographie, gographie,.geographie', '', 'entree', 'entrees', 64, 4, 1, 0, 1, 'pool', 'sortkey', '2010-06-11 14:47:18', 'fr', 0),
(265, '', 'motscleses', 'indexes', 'Indice de palabras clave', '<r2r:ml lang="en">Indice de palabras clave</r2r:ml>', 'palabrasclaves, .palabrasclaves, motscleses', '', 'entree', 'entrees', 64, 9, 1, 1, 1, 'pool', 'sortkey', '2010-06-11 14:47:18', 'es', 0),
(263, '', 'licence', 'indexavances', 'Licence portant sur le document', '<r2r:ml lang="en">Document license</r2r:ml>', 'licence, droitsauteur', 'dc.rights', 'entree', 'entrees', 16, 7, 1, 1, 1, 'select', 'rank', '2010-06-11 14:47:18', 'fr', 0),
(264, '', 'motsclesde', 'indexes', 'Schlagwortindex', '<r2r:ml lang="en">Schlagwortindex</r2r:ml>', 'schlusselworter, .schlusselworter, motsclesde, schlagworter, .schlagworter', '', 'entree', 'entrees', 32, 8, 1, 1, 1, 'pool', 'sortkey', '2010-06-11 14:47:18', 'de', 0);

#
# Dumping data for table 'entitytypes_entitytypes'
#

INSERT INTO #_TP_entitytypes_entitytypes (identitytype, identitytype2, cond) VALUES (228, 0, '*'),
(231, 231, '*'),
(231, 230, '*'),
(221, 231, '*'),
(222, 231, '*'),
(222, 251, '*'),
(223, 231, '*'),
(240, 228, '*'),
(223, 251, '*'),
(223, 250, '*'),
(223, 248, '*'),
(223, 230, '*'),
(241, 230, '*'),
(224, 231, '*'),
(224, 251, '*'),
(224, 250, '*'),
(225, 231, '*'),
(226, 228, '*'),
(226, 241, '*'),
(226, 239, '*'),
(226, 240, '*'),
(227, 231, '*'),
(227, 251, '*'),
(227, 250, '*'),
(227, 230, '*'),
(246, 238, '*'),
(234, 225, '*'),
(233, 231, '*'),
(233, 251, '*'),
(233, 250, '*'),
(240, 0, '*'),
(234, 226, '*'),
(234, 221, '*'),
(234, 224, '*'),
(234, 227, '*'),
(246, 225, '*'),
(221, 251, '*'),
(229, 228, '*'),
(221, 250, '*'),
(221, 230, '*'),
(222, 250, '*'),
(234, 222, '*'),
(234, 223, '*'),
(234, 233, '*'),
(232, 231, '*'),
(232, 251, '*'),
(239, 230, '*'),
(239, 228, '*'),
(234, 232, '*'),
(246, 226, '*'),
(245, 238, '*'),
(245, 225, '*'),
(245, 226, '*'),
(245, 221, '*'),
(245, 224, '*'),
(245, 227, '*'),
(245, 222, '*'),
(245, 223, '*'),
(222, 230, '*'),
(225, 251, '*'),
(239, 0, '*'),
(232, 230, '*'),
(233, 230, '*'),
(235, 225, '*'),
(235, 226, '*'),
(235, 221, '*'),
(235, 224, '*'),
(235, 227, '*'),
(235, 222, '*'),
(235, 223, '*'),
(236, 225, '*'),
(236, 226, '*'),
(236, 221, '*'),
(236, 224, '*'),
(236, 227, '*'),
(236, 222, '*'),
(236, 223, '*'),
(241, 228, '*'),
(238, 231, '*'),
(241, 0, '*'),
(242, 231, '*'),
(242, 251, '*'),
(242, 250, '*'),
(242, 230, '*'),
(242, 229, '*'),
(237, 252, '*'),
(243, 231, '*'),
(243, 251, '*'),
(244, 231, '*'),
(244, 251, '*'),
(244, 230, '*'),
(246, 221, '*'),
(246, 224, '*'),
(246, 227, '*'),
(246, 222, '*'),
(246, 223, '*'),
(247, 238, '*'),
(247, 225, '*'),
(247, 226, '*'),
(247, 221, '*'),
(247, 224, '*'),
(247, 227, '*'),
(247, 222, '*'),
(247, 223, '*'),
(237, 230, '*'),
(242, 228, '*'),
(233, 229, '*'),
(244, 229, '*'),
(230, 230, '*'),
(230, 228, '*'),
(238, 251, '*'),
(243, 230, '*'),
(243, 229, '*'),
(244, 241, '*'),
(232, 229, '*'),
(232, 228, '*'),
(238, 250, '*'),
(238, 230, '*'),
(233, 228, '*'),
(233, 241, '*'),
(242, 241, '*'),
(242, 239, '*'),
(238, 229, '*'),
(238, 228, '*'),
(238, 241, '*'),
(224, 230, '*'),
(225, 250, '*'),
(236, 231, '*'),
(236, 230, '*'),
(246, 230, '*'),
(246, 229, '*'),
(249, 234, '*'),
(249, 238, '*'),
(249, 225, '*'),
(249, 226, '*'),
(249, 221, '*'),
(249, 224, '*'),
(249, 227, '*'),
(249, 222, '*'),
(249, 223, '*'),
(249, 231, '*'),
(249, 251, '*'),
(249, 252, '*'),
(249, 250, '*'),
(249, 230, '*'),
(249, 229, '*'),
(249, 228, '*'),
(249, 241, '*'),
(249, 239, '*'),
(242, 240, '*'),
(250, 250, '*'),
(250, 239, '*'),
(251, 251, '*'),
(251, 241, '*'),
(252, 252, '*'),
(252, 240, '*'),
(233, 239, '*'),
(242, 0, '*'),
(221, 229, '*'),
(222, 229, '*'),
(222, 228, '*'),
(223, 229, '*'),
(223, 228, '*'),
(223, 241, '*'),
(223, 239, '*'),
(221, 228, '*'),
(221, 241, '*'),
(221, 239, '*'),
(222, 241, '*'),
(222, 239, '*'),
(224, 229, '*'),
(224, 228, '*'),
(224, 241, '*'),
(224, 239, '*'),
(225, 230, '*'),
(225, 229, '*'),
(225, 228, '*'),
(225, 241, '*'),
(225, 239, '*'),
(227, 229, '*'),
(227, 228, '*'),
(227, 241, '*'),
(227, 239, '*'),
(232, 241, '*'),
(243, 241, '*'),
(238, 239, '*'),
(238, 240, '*'),
(237, 240, '*'),
(249, 240, '*'),
(249, 233, '*'),
(249, 242, '*'),
(248, 228, '*'),
(238, 0, '*'),
(236, 229, '*'),
(231, 229, '*');

#
# Dumping data for table 'characterstyles'
#


#
# Dumping data for table 'internalstyles'
#

INSERT INTO #_TP_internalstyles (id, style, surrounding, conversion, greedy, rank, status, upd) VALUES (1, 'citation', '-*', '<blockquote>', 0, 1, 1, '2010-05-31 11:25:52'),
(2, 'quotations', '-*', '<blockquote>', 0, 2, 1, '2010-05-31 11:25:55'),
(3, 'citationbis', '-*', '<blockquote class="citationbis">', 0, 3, 1, '2010-05-31 11:26:10'),
(4, 'citationter', '-*', '<blockquote class="citationter">', 0, 4, 1, '2010-05-31 11:26:13'),
(5, 'titreillustration', '*-', '', 0, 5, 1, '2005-03-10 18:51:50'),
(6, 'legendeillustration', '-*', '', 0, 6, 1, '2010-02-18 17:04:03'),
(7, 'titredoc', '*-', '', 0, 7, 1, '2005-03-10 18:52:25'),
(8, 'legendedoc', '-*', '', 0, 8, 1, '2010-02-18 17:03:45'),
(9, 'puces', '*-', '<ul><li>', 0, 9, 1, '2005-03-10 18:53:04'),
(10, 'code', '*-', '', 0, 10, 1, '2005-03-10 18:53:41'),
(11, 'question', '*-', '', 0, 11, 1, '2005-03-10 18:54:17'),
(12, 'reponse', '*-', '', 0, 12, 1, '2005-04-29 17:12:51'),
(20, 'separateur', '*-', '<hr style="style">', 0, 19, 1, '2005-09-01 15:13:07'),
(19, 'section1', '*-', '<h1>', 0, 13, 1, '2010-05-31 11:26:29'),
(15, 'section3', '*-', '<h3>', 0, 15, 1, '2005-04-29 17:13:02'),
(16, 'section4', '*-', '<h4>', 0, 16, 1, '2005-04-29 17:13:00'),
(17, 'section5', '*-', '<h5>', 0, 17, 1, '2005-04-29 17:12:42'),
(18, 'section6', '*-', '<h6>', 0, 18, 1, '2005-04-29 17:12:37'),
(21, 'paragraphesansretrait', '*-', '', 0, 20, 1, '2005-05-24 22:24:39'),
(22, 'epigraphe', '*-', '', 0, 21, 1, '2005-05-24 22:24:28'),
(23, 'section2', '*-', '<h2>', 0, 14, 1, '2010-05-31 11:26:34'),
(24, 'pigraphe', '*-', '', 0, 22, 1, '2010-02-18 17:04:28'),
(25, 'sparateur', '-*', '', 0, 23, 1, '2005-05-24 22:25:07'),
(26, 'quotation', '-*', '<blockquote>', 0, 24, 1, '2005-09-01 15:12:53'),
(27, 'terme', '-*', '', 0, 25, 1, '2006-03-02 09:52:27'),
(28, 'definitiondeterme', '-*', '', 0, 26, 1, '2006-03-02 09:52:37'),
(29, 'bibliographieannee', '-*', '', 0, 27, 1, '2006-03-05 14:50:25'),
(30, 'bibliographieauteur', 'bibliographie', '', 0, 28, 1, '2006-03-02 09:55:15'),
(31, 'bibliographiereference', 'bibliographie', '', 0, 29, 1, '2006-03-02 09:55:37'),
(32, 'creditillustration,crditillustration,creditsillustration,crditsillustration', '-*', '', 0, 30, 1, '2006-12-05 16:36:15'),
(33, 'remerciements', '*-', '', 0, 31, 1, '2010-05-31 11:10:00'),
(34, 'encadre', '-*', '', 0, 32, 1, '2010-02-26 12:22:16');
DELETE FROM #_TP_optiongroups;
# # Database: 'lodel09_me-revorg'# 
#
# Dumping data for table 'optiongroups'
#

INSERT INTO #_TP_optiongroups (id, idparent, name, title, altertitle, comment, logic, exportpolicy, rank, status, upd) VALUES (1, 0, 'servoo', 'Servoo', '<r2r:ml lang="en">Servoo</r2r:ml>', '', 'servooconf', 1, 1, 32, '2010-05-25 16:39:12'),
(2, 0, 'metadonneessite', 'Métadonnées du site', '<r2r:ml lang="en">Website metadata</r2r:ml>', '', '', 1, 2, 1, '2010-05-25 16:39:28'),
(5, 0, 'oai', 'OAI', '<r2r:ml lang="en">OAI</r2r:ml>', '', '', 1, 4, 1, '2010-06-11 10:56:30');
DELETE FROM #_TP_options;
# # Database: 'lodel09_me-revorg'# 
#
# Dumping data for table 'options'
#

INSERT INTO #_TP_options (id, idgroup, name, title, type, defaultvalue, comment, userrights, rank, status, upd, edition, editionparams) VALUES (1, 1, 'url', 'url', 'tinytext', '', '', 40, 1, 32, '2010-05-25 16:27:11', 'editable', ''),
(2, 1, 'username', 'username', 'username', '', '', 40, 2, 32, '2010-05-25 16:26:43', 'editable', ''),
(3, 1, 'passwd', 'password', 'passwd', '', '', 40, 3, 32, '2010-05-25 16:26:56', 'editable', ''),
(4, 2, 'titresite', 'Titre du site', 'tinytext', 'Titresite', '', 40, 1, 1, '2010-05-25 16:27:31', 'editable', ''),
(5, 2, 'titresiteabrege', 'Titre abrégé du site', 'tinytext', 'Titre abrégé du site', '', 40, 3, 1, '2010-05-25 16:30:21', 'editable', ''),
(6, 2, 'descriptionsite', 'Description du site', 'text', '', '', 40, 4, 1, '2010-05-25 16:30:38', 'editable', ''),
(7, 2, 'urldusite', 'URL officielle du site', 'url', '', '', 40, 5, 1, '2010-05-25 16:30:57', 'editable', ''),
(9, 2, 'issn', 'ISSN', 'tinytext', '', '', 30, 6, 1, '2010-05-25 16:31:10', 'editable', ''),
(10, 2, 'editeur', 'Nom de l\'éditeur du site', 'tinytext', '', '', 30, 8, 1, '2010-05-25 16:31:43', 'editable', ''),
(11, 2, 'adresseediteur', 'Adresse postale de l\'éditeur', 'text', '', '', 30, 9, 1, '2010-05-25 16:32:08', 'editable', ''),
(12, 2, 'producteursite', 'Nom du producteur du site', 'tinytext', '', '', 30, 10, 1, '2010-05-25 16:41:57', 'editable', ''),
(13, 2, 'diffuseursite', 'Nom du diffuseur du site', 'tinytext', '', '', 30, 11, 1, '2010-05-25 16:34:10', 'editable', ''),
(14, 2, 'droitsauteur', 'Droits d\'auteur par défaut', 'tinytext', '', '', 30, 12, 1, '2010-05-25 16:33:17', 'editable', ''),
(15, 2, 'directeurpublication', 'Nom du directeur de la publication', 'tinytext', '', '', 30, 13, 1, '2010-05-25 16:35:28', 'editable', ''),
(16, 2, 'redacteurenchef', 'Nom du Rédacteur en chef', 'tinytext', '', '', 30, 14, 1, '2010-05-25 16:36:37', 'editable', ''),
(17, 2, 'courrielwebmaster', 'Courriel du webmaster', 'email', '', '', 30, 15, 1, '2010-05-25 16:36:55', 'editable', ''),
(18, 2, 'courrielabuse', 'Courriel abuse', 'tinytext', '', '', 40, 16, 1, '2010-05-25 16:32:32', 'editable', ''),
(19, 2, 'motsclesdusite', 'Mots clés décrivant le site (entre virgules)', 'text', '', '', 30, 17, 1, '2010-05-25 16:38:30', 'editable', ''),
(23, 5, 'oai_allow', 'oai_allow', 'tinytext', '*', '', 40, 23, 1, '2010-05-25 16:40:25', 'editable', ''),
(24, 5, 'oai_deny', 'oai_deny', 'tinytext', '', '', 40, 24, 1, '2010-05-25 16:40:38', 'editable', ''),
(25, 5, 'oai_email', 'Email de l\'administrateur du dépôt', 'email', '', '', 40, 25, 32, '2010-05-25 16:41:14', 'editable', ''),
(26, 2, 'issn_electronique', 'ISSN électronique', 'tinytext', '', '', 30, 7, 32, '2010-05-25 16:31:24', 'editable', ''),
(27, 2, 'langueprincipale', 'Langue principale du site', 'lang', 'fr', '', 40, 18, 1, '2010-05-25 16:37:58', 'editable', ''),
(28, 2, 'soustitresite', 'Sous titre du site', 'tinytext', '', '', 40, 2, 1, '2010-05-25 16:27:48', 'editable', ''),
(14184, 2, 'typepublication', 'Type de publication', 'list', 'Revue', '', 40, 26, 1, '2010-09-09 10:52:05', 'select', 'Revue, Cahier, Bulletin, Monographies'),
(14191, 2, 'imagehabillee', 'Images habillées par le texte', 'boolean', '', '', 40, 29, 1, '2010-06-30 15:20:10', 'editable', ''),
(14190, 2, 'pdf_electronique', 'Pdf pour revue électronique', 'boolean', '', '', 40, 28, 1, '2010-06-30 15:19:37', 'editable', ''),
(14189, 2, 'pdf', 'Génération de fichier pdf', 'boolean', '', '', 40, 27, 1, '2010-06-30 15:18:54', 'editable', '');
# # Database: 'lodel09_me-revorg'# 
# --------------------------------------------------------

#
# Table structure for table 'textes'
#

DROP TABLE IF EXISTS #_TP_textes;
CREATE TABLE #_TP_textes (
  identity int(10) unsigned default NULL,
  surtitre text,
  titre text,
  soustitre text,
  langue char(5) default NULL,
  datepubli date default NULL,
  texte longtext,
  notesbaspage longtext,
  notefin longtext,
  bibliographie text,
  annexe longtext,
  ndlr text,
  pagination tinytext,
  noticebiblio text,
  commentaireinterne text,
  `resume` text,
  datepublipapier date default NULL,
  prioritaire tinyint(4) default NULL,
  icone tinytext,
  URLessai tinytext,
  alterfichier tinytext,
  addendum text,
  ocr tinyint(4) default NULL,
  altertitre text,
  ndla text,
  numerodocument double default NULL,
  titreoeuvre text,
  noticebibliooeuvre text,
  dedicace text,
  documentcliquable tinyint(4) default NULL,
  datepublicationoeuvre tinytext,
  imagehabillee tinyint(4) default NULL,
  UNIQUE KEY identity (identity)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'publications'
#

DROP TABLE IF EXISTS #_TP_publications;
CREATE TABLE #_TP_publications (
  identity int(10) unsigned default NULL,
  titre text,
  soustitre text,
  texte text,
  meta text,
  `date` date default NULL,
  surtitre text,
  icone tinytext,
  introduction text,
  datepubli date default NULL,
  datepublipapier date default NULL,
  noticebiblio text,
  commentaireinterne text,
  ndlr text,
  historique text,
  prioritaire tinyint(4) default NULL,
  paraitre tinyint(4) default NULL,
  integralite tinyint(4) default NULL,
  numero tinytext,
  langue char(5) default NULL,
  altertitre text,
  urlpublicationediteur text,
  descriptionouvrage text,
  isbn tinytext,
  periode tinytext,
  racinemets tinyint(4) default NULL,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'fichiers'
#

DROP TABLE IF EXISTS #_TP_fichiers;
CREATE TABLE #_TP_fichiers (
  identity int(10) unsigned default NULL,
  titre text,
  document tinytext,
  description text,
  legende text,
  credits tinytext,
  vignette tinytext,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'liens'
#

DROP TABLE IF EXISTS #_TP_liens;
CREATE TABLE #_TP_liens (
  identity int(10) unsigned default NULL,
  titre text,
  url text,
  urlfil text,
  texte text,
  capturedecran tinytext,
  nombremaxitems int(11) default NULL,
  altertitre text,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'textessimples'
#

DROP TABLE IF EXISTS #_TP_textessimples;
CREATE TABLE #_TP_textessimples (
  identity int(10) unsigned default NULL,
  titre tinytext,
  texte text,
  url text,
  `date` datetime default NULL,
  altertitre text,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'auteurs'
#

DROP TABLE IF EXISTS #_TP_auteurs;
CREATE TABLE #_TP_auteurs (
  idperson int(10) unsigned default NULL,
  nomfamille tinytext,
  prenom tinytext,
  UNIQUE KEY idperson (idperson),
  KEY index_idperson (idperson)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'entities_auteurs'
#

DROP TABLE IF EXISTS #_TP_entities_auteurs;
CREATE TABLE #_TP_entities_auteurs (
  idrelation int(10) unsigned default NULL,
  prefix tinytext,
  affiliation tinytext,
  fonction tinytext,
  description text,
  courriel text,
  site text,
  UNIQUE KEY idrelation (idrelation),
  KEY index_idrelation (idrelation)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'indexes'
#

DROP TABLE IF EXISTS #_TP_indexes;
CREATE TABLE #_TP_indexes (
  identry int(10) unsigned default NULL,
  nom text,
  definition text,
  UNIQUE KEY identry (identry),
  KEY index_identry (identry)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'individus'
#

DROP TABLE IF EXISTS #_TP_individus;
CREATE TABLE #_TP_individus (
  identity int(10) unsigned default NULL,
  nom tinytext,
  prenom tinytext,
  email text,
  siteweb text,
  description text,
  accroche text,
  adresse text,
  telephone tinytext,
  photographie tinytext,
  UNIQUE KEY identity (identity),
  KEY index_identity (identity)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

# --------------------------------------------------------

#
# Table structure for table 'indexavances'
#

DROP TABLE IF EXISTS #_TP_indexavances;
CREATE TABLE #_TP_indexavances (
  identry int(10) unsigned default NULL,
  nom tinytext,
  description text,
  url text,
  icone tinytext,
  UNIQUE KEY identry (identry),
  KEY index_identry (identry)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
