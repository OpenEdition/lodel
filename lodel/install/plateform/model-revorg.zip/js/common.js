jQuery(function($) { // DOM ready

	var main = $('#main'),
	    tabs = $('div.tabMenu', main),
	    loginBox = $('#loginbox');

	/**
	 * Affichage par onglets
	 */
	(function(){
		if (!tabs.length) { return; }

		tabs.each(function(){

			var self = $(this),
			    tabAnchor = self.find('a'),
			    tabTarget = self.nextAll('div.tabContent');

			self.delegate('a', 'click', function(event){

				event.preventDefault();

				tabAnchor.removeClass('active');
				tabTarget.addClass('hidden');

				this.className = 'active';
				$(this.hash).removeClass('hidden');
			});
		});

	})();

	/**
	 * Accès restreint
	 * Formulaire d'identification
	 */
	(function(){

		if (!loginBox.length) { return; }

		var loginError = $('#loginError'),
		    loginBlock = $('#loginBlock').addClass('fixed');

		if (!loginError.length && !loginBox.hasClass('log-out')) {
			loginBlock.addClass('hidden');
		}

		if (loginBox.hasClass('log-in')) {
			$('legend > span', loginBox).click(function(event){
				event.preventDefault();
				loginBlock.toggleClass('hidden');
			});
			$(':reset', loginBox).click(function(event){
				event.preventDefault();
				loginBlock.addClass('hidden');
				loginError.remove();
			});
		}

	})();
			
		/*Descend automatiquement sur la fenêtre de login si erreur */
			
		if ($('#loginError').length) {
			$("html, body").animate({ scrollTop: $('#loginError').offset().top }, 1000);
		}

	/**
	 * Champ Recherche
	 */
	(function(){

		var q = $('#q'),
		    qval = q.val();

		q.val(qval).focus(function(){
			if (this.value == qval) { this.value = ''; }
		}).blur(function(){
			if (this.value == '') { this.value = qval; }
		});

	})();
	
});

/**
 * Hauteur de #main en fonction de celle de #nav
 */
var hMain = $('#main').height();
var hNav = $('#nav').height();
if (hNav > hMain)
$('#main').height(hNav + 75);